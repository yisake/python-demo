# encoding=utf-8
#http://pysvn.tigris.org/docs/pysvn_prog_ref.html

import pysvn
import time
client = pysvn.Client()
LogList = client.log('https://llpsvn.lianlianpay.com/svn/MPay/Test/Code/http-mock')
TodayTime = time.strftime("%Y-%m-%d", time.localtime())
for LogInfo in LogList:
    LogTime = time.strftime("%Y-%m-%d", time.localtime(LogInfo.date))
    if LogTime == TodayTime:
        print LogInfo.revision.number,
        print LogInfo.author,
        print time.ctime(LogInfo.date),
        print LogInfo.message.decode('utf-8')
