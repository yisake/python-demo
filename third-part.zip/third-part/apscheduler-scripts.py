##内置
#内置以下几种调度器实现：
# BlockingScheduler: 
# BackgroundScheduler: 默认采用ThreadPoolExecutor池(默认10)，可以配置ProcessPoolExecutor，或同时使用
# AsyncIOScheduler: 使用asyncio模块
# GeventScheduler: 使用gevent
# TornadoScheduler: use if you’re building a Tornado application
# TwistedScheduler: use if you’re building a Twisted application
# QtScheduler: use if you’re building a Qt application

##demo脚本
def aps_test():
    print datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'), '你好'

scheduler = BlockingScheduler()
scheduler.add_job(func=aps_test, trigger='cron', second='*/5')
scheduler.start()

scheduler.add_job(func=aps_test, args=('你好',), trigger='cron', second='*/5')

##flask-apscheduler
scheduler.add_job(id='job1', func=app_job, trigger='corn', hour='0-23', minute='0-59', second='59')