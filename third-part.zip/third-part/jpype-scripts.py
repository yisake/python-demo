from jpype import *
import os
os.environ['CLASSPATH']+='C:\\Users\\huangc11\\Desktop\\sikulixapi.jar;'
os.environ['CLASSPATH']+='C:\\Users\\huangc11\\Desktop\\sikulixlibswin.jar'
os.environ['CLASSPATH']+=' C:\\Users\\huangc11\\Desktop\\jni4net-0.8.8.0-bin\\lib\\ jni4net.j-0.8.8.0.jar’
print getDefaultJVMPath()
startJVM(getDefaultJVMPath(),'-ea','-Djava.class.path=C:\\Users\\huangc11\\Desktop\\sikulixapi.jar;C:\\Users\\huangc11\\Desktop\\sikulixlibswin.jar; C:\\Users\\huangc11\\Desktop\\jni4net-0.8.8.0-bin\\lib\\jni4net.j-0.8.8.0.jar')
print isJVMStarted()
App=JClass('org.sikuli.script.App')
Screen= JClass('org.sikuli.script.Screen')
a=App('calc')
s=Screen()
s.click()
s.doubleClick()