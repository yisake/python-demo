# encoding=utf-8
import random
import xlrd
import json
import socket
from flask import Flask, request, session, g, redirect, url_for, current_app, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_marshmallow import Marshmallow
from werkzeug.routing import Rule
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
app = Flask(__name__)

#用flask时遇到了返回字符串支持中文显示的问题
app.config['JSON_AS_ASCII'] = False 
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:123@127.0.0.1:3306/test?charset=utf8'

# 日志系统配置
handler = logging.FileHandler('app.log', encoding='UTF-8')
logging_format = logging.Formatter('%(asctime)s - %(levelname)s - %(filename)s - %(funcName)s - %(lineno)s - %(message)s')
handler.setFormatter(logging_format)
app.logger.addHandler(handler)

ch_handler = logging.StreamHandler()
ch_handler.setLevel(logging.DEBUG)
logging_format = logging.Formatter('%(asctime)s - %(levelname)s - %(filename)s - %(funcName)s - %(lineno)s - %(message)s')
ch_handler.setFormatter(logging_format)
app.logger.addHandler(ch_handler)

#db配置
db = SQLAlchemy(app)

#连接数据库，建表
engine = create_engine("mysql+pymysql://root:123@127.0.0.1:3306/test",encoding="utf-8",echo=True,max_overflow=5)
Base = declarative_base()
Session = sessionmaker(bind=engine)
session=Session()
rules=session.execute("select * from test.mock_rules")
print '#keys:',rules.keys()
print '#rowcount:',rules.rowcount
for rule in rules.fetchall():
    print rule.id
session.query(MockRule).filter_by(id='2')[0].project
MockRule.metadata.create_all(engine) #创建表

#将缓存中的数据提交
session.add()
session.commit()

#使用原生的sql语句修改
# db.session.execute("insert into user values(0,'李四',456),(0,'王五',555)")
# db.session.execute("truncate table user")
# db.session.execute("update user set name='张三' where id = 2")
# db.session.execute("delete from user where id = 2")

#批量添加数据
db.session.add_all(stus_list)
db.session.commit()

#修改数据
students = Student.query.filter_by(s_id=3).first()
students.s_name = '哈哈'
db.session.commit()

Student.query.filter_by(s_id=3).update({'s_name':'娃哈哈'})
db.session.commit()

#删除数据
db.session.delete()
db.session.commit()

@app.route('/index')
def mock():
    return 'index!'

@app.route('/mock')
def mock():
    current_app.logger.debug('A value for debugging')
    current_app.logger.warning('A warning occurred (%d apples)', 42)
    current_app.logger.error('An error occurred')
    return 'mock!'    

@app.route('/xml')
def xml():
    return '''<xml></xml>''', {'Content-Type': 'text/xml'}

@app.route('/json')
def json():
    return jsonify({'a': 1, 'b': 2})

@app.route('/redirect')
def redirect():
    return redirect(url_for('ccc222'))#url_for直接对函数访问

@app.route('/ccc111')
def ccc222():
    return "我是ccc"

@app.errorhandler(403)
def error_403(e):
    return '<h1> 我要设置http的状码为403.</h1>', 403



# form
# args
# values
# cookies
# stream
# headers
# data
# files MultiDict，带有通过POST或PUT请求上传的文件。
# environ WSGI隐含的环境配置
# method
# path /page.html
# script_root /myapplication
# base_url http://www.example.com/myapplication/page.html
# url http://www.example.com/myapplication/page.html?x=y
# url_root http://www.example.com/myapplication/
# is_xhr
# blueprint
# endpoint
# get_json
# json
# max_content_length
# module

if __name__ == '__main__':
    app.debug = True
    app.run('0.0.0.0',debug=True,port=5001)
