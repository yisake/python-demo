from jenkinsapi.jenkins import Jenkins
j= Jenkins('http://ci-server-24.usd.lab.emc.com:8080/',username='', password='')
j.version
j.get_job('Precheck-in_test_suite_bc-d1010').get_last_build()
j.build_job('Install image on bc or bs',dict(swarmName='bs-d9551'))
p.is_running()
p.get_last_build()