paramiko
ssh sftp
        # setup ssh
        self.ssh_client = paramiko.SSHClient()
        self.ssh_client.load_system_host_keys()
        self.ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self.ssh_client.connect(self.remote_ip
                                , username=self.remote_usr
                                , password=self.remote_pwd)
        
       
       
        # setup sftp
        t = paramiko.Transport((self.remote_ip, 22))
        t.connect(username=self.remote_usr, password=self.remote_pwd)
        self.sftp_client = paramiko.SFTPClient.from_transport(t)
timeout
        (sin, sout, serr) = self.ssh_client.exec_command(cmd,timeout=60.0)
        out = ''.join(sout)
        err = ''.join(serr)