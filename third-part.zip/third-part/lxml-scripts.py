import lxml.etree
import lxml.html as x
import urllib

sock = urllib.urlopen("http://www.baidu.com/")
htmlSource = sock.read()
sock.close()
d = x.document_fromstring(htmlSource)

#  print the content 
#  x.tostring(d)

e = d.xpath("//text()")
for i in e:
    if i == 'hao123':
        g = i.getparent()
        tree = lxml.etree.ElementTree(g)
        print tree.getpath(g)
        #  return tree.getpath(g)
