# encoding=utf-8
# 0.8.1 启动
# python -m locust.main -f lo.py --host=http://127.0.0.1:5000 --web-host=127.0.0.1
# (env) C:\Users\Administrator\Github>locust -f locust_121.py --clients=400 --hatch-rate=400 --num-request=20000 --no-web --print-stats
# python -m locust.main --host=http://192.168.110.93:8099 -f secured_query.py --clients=1 --hatch-rate=1 --num-request=20000 --no-web --print-stats
# python -m locust.main --host=http://192.168.110.93:8099 -f secured_query2.py --clients=1 --hatch-rate=1 --num-request=20000 --no-web --print-stats
# python -m locust.main --host=http://192.168.110.93:8099 -f transfer.py --clients=1 --hatch-rate=1 --num-request=20000 --no-web --print-stats
import requests
from requests_toolbelt.multipart.encoder import MultipartEncoder
co = open('3.txt', 'rb')
coo = co.read()
co.close()
con = coo.split('\r\n')

fields = {
    "isQuery": "1",
    "upload": "1",
    "cur_code": None,
    "fileName": "null",
    "trader_no": "201802060000757007",
    "trader_name": u"汇添富测试商户",
    "biz_type": None,
    "exchange_rate": None,
    "deal_amt": None,
    "remark": None,
}


def get_num():
    global con
    num = con[0]
    con = con[1:]
    return num


cookies = {
    "JSESSIONID": "11A4BAB41C0B4031F1D06A63139CBF8F",
    "sessionId": "MNG11A4BAB41C0B4031F1D06A63139CBF8F",
    "oid_userlogin": "dd8fb8f8c0fee21c713f7aa23d0938b34cbe2d8493ae770ee8d7f01c4438208d"
}


tmp = get_num()
fields['doc'] = ("./1.txt", tmp, tmp)
m = MultipartEncoder(fields)
a = requests.post("http://192.168.110.22:8080", data=m, cookies=cookies, headers={'Content-Type': m.content_type})
print a.content.decode('utf-8')
