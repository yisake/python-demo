# encoding=utf-8
from flask import Flask, jsonify, abort
from werkzeug.routing import Rule
import random
import xlrd
import json
app = Flask(__name__)
c = {}


@app.route('/idc_list',methods=['GET','POST'])
def idc_list():
    with open('./idc_list.txt','r') as f:
        idc=f.read()
    #print idc
    return  idc, {'Content-Type': 'text/xml'}

@app.route('/idc_escode',methods=['GET','POST'])
def idc_escode():
        with open('./idc_escode.txt','r') as f:
                idc=f.read()
        #print idc
        return  idc, {'Content-Type': 'text/xml'}

@app.route('/idc_code',methods=['GET','POST'])
def idc_code():
        with open('./idc_code.txt','r') as f:
                idc=f.read()
    abort(int(idc))

@app.route('/add')
def add_route():
    global c
    wb = xlrd.open_workbook('2.xlsx')
    table = wb.sheets()[0]
    url = table.row_values(1)[0]
    data = table.row_values(1)[1]
    c[url] = data
    rule = Rule(c.keys()[0], endpoint='hellos', methods=['POST', 'GET'])
    app.url_map.add(rule)
    print app.url_map
    print app.url_map._rules
    return 'Added!'


@app.route('/')
def hello_world():
    count = random.randint(1, 99999)
    rule = Rule("/hello%d" % count, endpoint='hellos', methods=['POST', 'GET'])
    app.url_map.add(rule)
    print app.url_map
    print app.url_map._rules
    return 'Hello World!'


@app.route('/hello')
def hellos():
    global c
    return c[c.keys()[0]]


@app.route('/json')
def root():
    wb = xlrd.open_workbook('1.xlsx')
    table = wb.sheets()[0]
    url = table.row_values(1)[0]
    data = table.row_values(1)[1]
    print c[url]
    jd = jsonify(data)
    return jd


if __name__ == '__main__':
    app.debug = True
    app.run()