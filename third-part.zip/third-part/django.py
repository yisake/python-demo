#django note

####startproject
D:\django>django-admin.pyc startproject  myproject

D:\django>dir
 驱动器 D 中的卷没有标签。
 卷的序列号是 0002-BC02

 D:\django 的目录

2015/04/05  13:53    <DIR>          .
2015/04/05  13:53    <DIR>          ..
2015/04/05  13:53    <DIR>          myproject
2015/04/05  13:13               109 view.py
               1 个文件            109 字节
               3 个目录 83,160,727,552 可用字节

D:\django>
D:\django>



####startproject failed with django command
今儿创建一个django project时出现这么一个问题，执行django-admin.py startproject mybook时会报错，Note that only Django core commands are listed as settings are not properly conf
igured (error: Requested setting INSTALLED_APPS, but settings are not configured
. You must either define the environment variable DJANGO_SETTINGS_MODULE or call
settings.configure() before accessing settings.).
然而直接django-admin.pyc startproject mybook 则没问题。请教大家这是怎么回事儿啊 。



####
python manage.py makemigrations polls
python manage.py sqlmigrate polls 0001
python manage.py migrate


####django shell
python manage.py shell


####check database
cd "..\..\Program Files\MySQL\MySQL Server 6.0"\bin
mysql -hlocalhost -uroot -proot

python manage.py shell
from polls.models import Question, Choice
Question.objects.all()
Question.objects.filter(id=1)
Question.objects.filter(question_text__startswith='What')
Question.objects.get(pk=1)



#####register the python
360云盘/python/register.py