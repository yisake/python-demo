
#coding=utf-8
import time
import ctypes
import threading
import os
import pythoncom
import win32api
import sys

#Author Huangfu
#Date 2014/11/19
#Program:
#	Press F10 to pause,and Press any key except F12 to continue the script thread,F12 is used to disable the hot key.
#You can active the function just use "import hotkey" at the top of you script,
#!Note! the function only works in Windows Operation System!

try:
	import pyHook
except Exception,cs:
	print 'Please download the pyHook module from EMC svn svn://10.244.82.203/qa/python_third_module'
	sys.exit()


def onKeyboardEvent(event):
	Handle=ctypes.windll.kernel32.OpenThread(0x0002,0,tid)
	if event.Key=='F10':
		print 'Pause...'
		ctypes.windll.kernel32.SuspendThread(Handle)#Pause the thread
	elif str(event.Key)=='F12':
		win32api.PostQuitMessage()
	else :
		ctypes.windll.kernel32.ResumeThread(Handle)#Continue the thread
	return True
	

def hotKey():
	hm = pyHook.HookManager()
	hm.KeyDown=onKeyboardEvent
	hm.HookKeyboard()
	pythoncom.PumpMessages()


try:
	tid=ctypes.windll.kernel32.GetCurrentThreadId()
	thread=threading.Thread(target=hotKey)
	thread.start()
	print 'Hotkey start!'
except Exception,cs:
	print cs
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
####
#coding=gb18030
import pythoncom 
import pyHook
def onMouseEvent(event):
    # 监听鼠标事件     
    print "MessageName:",event.MessageName     
    print "Message:", event.Message     
    print "Time:", event.Time     
    print "Window:", event.Window     
    print "WindowName:", event.WindowName     
    print "Position:", event.Position     
    print "Wheel:", event.Wheel     
    print "Injected:", event.Injected           
    print"---"
   
    # 返回 True 以便将事件传给其它处理程序     
    # 注意，这儿如果返回 False ，则鼠标事件将被全部拦截     
    # 也就是说你的鼠标看起来会僵在那儿，似乎失去响应了     
    return True


def onKeyboardEvent(event):
   # 监听键盘事件
    a=event.Key
    print type(a)   
    print "MessageName:", event.MessageName         
    print "Message:", event.Message         
    print "Time:", event.Time         
    print "Window:", event.Window         
    print "WindowName:", event.WindowName         
    print "Ascii:", event.Ascii, chr(event.Ascii)         
    print "Key:", event.Key         
    print "KeyID:", event.KeyID     
    print "ScanCode:", event.ScanCode
    print "Extended:", event.Extended
    print "Injected:", event.Injected
    print "Alt", event.Alt
    print "Transition", event.Transition
    print "---"
    a=event.WindowName
    print a
    return True
    #if event.WindowName==windowName:
    # 同鼠标事件监听函数的返回值     
    

    
def main():     
    # 创建一个“钩子”管理对象  
    hm = pyHook.HookManager()
    # 监听所有键盘事件
    #hm.SubscribeKeyDown(onKeyboardEvent)
    hm.KeyDown = onKeyboardEvent     
    # 设置键盘“钩子”
    hm.HookKeyboard()      
    # 监听所有鼠标事件     
    #hm.MouseAll = onMouseEvent     
    # 设置鼠标“钩子”     
    #hm.HookMouse()      
    # 进入循环，如不手动关闭，程序将一直处于监听状态     
    pythoncom.PumpMessages() 

    
if __name__ == "__main__":     
    main()    