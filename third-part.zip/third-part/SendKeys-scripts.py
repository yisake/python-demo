# -*- coding: utf-8 -*-
# Sendkeys常用的按键键码
# 按键 键码 sendkeys使用方式
# Shift + {"+"}
# tab TAB  {“TAB”}
# ctrl ^ {"^"}
# alt  % {"%"}
# f1~fn F1 ~ Fn {"F1"} ~ {"Fn"}
# 向上键 UP  {"UP"}
# 向下键  DOWN {"DOWN"}
# 回车 ENTER {"ENTER"}
# Num键 NUM LOCK {“NUMLOCK”}

import sys
sys.path.append(sys.path[2].replace('DLLs', 'Lib\\site-packages\\win32'))
sys.path.append(sys.path[2].replace('DLLs', 'Lib\\site-packages\\win32\\lib'))
import win32gui
import win32con
import win32clipboard as w 
import SendKeys
import time
import ctypes

def set_text(content):
    w.OpenClipboard()
    w.EmptyClipboard()
    w.SetClipboardData(win32con.CF_UNICODETEXT, content)
    w.CloseClipboard()


def send_qq_message(msg, dialog):
    msg = unicode(msg, 'utf-8')
    dialog = unicode(dialog, 'utf-8')
    set_text(msg)
    qqhd = win32gui.FindWindow(None, dialog)
    ctypes.windll.user32.SwitchToThisWindow(qqhd, True)
    win32gui.SendMessage(qqhd, 258, 22, 2080193)
    win32gui.SendMessage(qqhd, 770, 0, 0)
    SendKeys.SendKeys("{ENTER}")


def send_qq_message_with_at(msg, dialog, all):
    all = unicode(all, 'utf-8')
    msg = unicode(msg, 'utf-8')
    dialog = unicode(dialog, 'utf-8')
    for someone in all.split(','):
        set_text('@'+someone)
        qqhd = win32gui.FindWindow(None, dialog)
        ctypes.windll.user32.SwitchToThisWindow(qqhd, True)
        time.sleep(0.3)
        win32gui.SendMessage(qqhd, 258, 22, 2080193)
        win32gui.SendMessage(qqhd, 770, 0, 0)
        SendKeys.SendKeys("{DOWN}")
        SendKeys.SendKeys("{ENTER}")
    set_text(unicode(msg))
    qqhd = win32gui.FindWindow(None, dialog)
    ctypes.windll.user32.SwitchToThisWindow(qqhd, True)
    win32gui.SendMessage(qqhd, 258, 22, 2080193)
    win32gui.SendMessage(qqhd, 770, 0, 0)
    SendKeys.SendKeys("{ENTER}")



#send_qq_message(u'皇甫春峰,连连QA',u'测试通知群')
send_qq_message_with_at('艾特多个人','测试通知群','皇甫春峰,连连QA')