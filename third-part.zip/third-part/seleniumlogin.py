#coding=utf-8
from selenium import webdriver
import time

while 1:
    try:
        a=webdriver.Firefox()
        a.get('http://10.12.21.63:8080/portal/')
        time.sleep(2)
        a.find_element_by_id('id_userName').send_keys('huangfuchunfeng')
        time.sleep(2)
        a.find_element_by_id('id_userPwd').send_keys('Fggtest!')
        time.sleep(2)
        a.find_element_by_id('id_lable_loginbutton_auth').click()
        time.sleep(2)
        if a.find_element_by_id('id_successfulinfo').text==u'\u4e0a\u7ebf\u6210\u529f\u3002':
            print 'Break loop...'
            break
    except:
        a.quit()