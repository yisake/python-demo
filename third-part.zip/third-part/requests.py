import requests

url="http://example.org"

proxies = {
  'http': 'http://10.0.75.1:8888',
}

params={
    "name":"hello",
    "age":23
        }

requests.get(url, proxies=proxies)
requests.get(url,params=params)
requests.post(url, data=params)


