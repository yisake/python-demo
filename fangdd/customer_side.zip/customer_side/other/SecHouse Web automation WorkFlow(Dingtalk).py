#!C:\Python27\python.exe
#encoding=utf-8
#@author:huangfu
import requests
import hashlib
import time
from jenkinsapi.jenkins import Jenkins
import os

j=Jenkins('http://10.12.12.5:8080/',username='huangfuchunfeng', password='123')
all_list=[j['SecHouse Web automation Chrome'],j['SecHouse Web automation Firefox']]
'''Get the actual job list'''
job_list=[]
if os.environ['DRIVER_TYPE']!='None':
    for i in os.environ['DRIVER_TYPE'].split(','):
        job_list.append(j['SecHouse Web automation '+i])

'''Build the job in job_list and Check the job state in job_list'''
print "\n###################Build the jobs in job_list..."
if os.environ['DRIVER_TYPE']=='all':
    print 'Start build all job in all_list...'
    for i in all_list:
        j.build_job(i)
    	time.sleep(10)        
else:
    for i in os.environ['DRIVER_TYPE'].split(','):
        print 'Start build job SecHouse Web automation '+i
        j.build_job('SecHouse Web automation '+i)
        print "Check the job's state..."
        while 1:
            time.sleep(10)
            if j['SecHouse Web automation '+i].get_last_build().is_running()==False:                
                break
       


####Generate Test Report
host="http://ddcorp.fangdd.cn"
appId="33baa7b26fb34b36"
secretKey="668d33f7e2ce36dc9a896d69a4615686"

m = hashlib.md5()

content = 'test'
current_milli_time = lambda: int(round(time.time() * 1000))
timestamp = current_milli_time() / 1000

m.update(appId + secretKey + str(timestamp))
signature = m.hexdigest()

header = {
    "appId":appId,
    "signature":signature,
    "timestamp": str(timestamp),
    "Content-Type": "application/json"
    }

    
####Query job result
'''Check all the test result'''
print '\n###################Checking android test results...'
#Set the build-result value to 0,if any of jobs is ok, result is not equal to 0. 
msg=u'''SecHouse Web automation build result:\n'''           
result=0
for item in job_list:
    last_build=item.get_last_build()
    if last_build.get_artifact_dict().has_key('power-emailable-report.html'):
        reportUrl=last_build.get_artifact_dict()['power-emailable-report.html'].url
    else:
        reportUrl='There is no test report for faltal error' 
    msg+='''
    %s
    Build Status:%s
    Build URL:%s
    Build Console:%s
    HTML Report:%s\n
    ''' % (last_build.name,last_build.get_status(),last_build.baseurl,last_build.baseurl+'/console',reportUrl)
    if item.get_last_build().get_status()=='SUCCESS':
        result+=1


msg_params = {
    "chatid" : "chatf70586c93b7e7a30beb388633ad6e2d1",
    "sender": "huangfuchunfeng",
    "msgtype" : "text",
    "text" : {
        "content":msg
    }
}

res = requests.post(host+"/chat/send", json = msg_params , headers = header)
