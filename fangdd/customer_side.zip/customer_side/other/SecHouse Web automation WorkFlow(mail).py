#!C:\Python27\python.exe
import time
import os
from jenkinsapi.jenkins import Jenkins
j=Jenkins('http://10.12.11.51:8080/',username='huangfuchunfeng', password='123')
all_list=[j['SecHouse Web automation Chrome'],j['SecHouse Web automation Firefox']]
'''Get the actual job list'''
job_list=[]
if os.environ['DRIVER_TYPE']!='None':
    for i in os.environ['DRIVER_TYPE'].split(','):
        job_list.append(j['SecHouse Web automation '+i])

'''Build the job in job_list and Check the job state in job_list'''
print "\n###################Build the jobs in job_list..."
if os.environ['DRIVER_TYPE']=='all':
    print 'Start build all job in all_list...'
    for i in all_list:
        j.build_job(i)
    	time.sleep(10)        
else:
    for i in os.environ['DRIVER_TYPE'].split(','):
        print 'Start build job SecHouse Web automation '+i
        j.build_job('SecHouse Web automation '+i)
        print "Check the job's state..."
        while 1:
            time.sleep(10)
            if j['SecHouse Web automation '+i].get_last_build().is_running()==False:                
                break
       
'''Check all the test result'''
print '\n###################Checking android test results...'
#Set the build-result value to 0,if any of jobs is ok, result is not equal to 0.            
result=0
for item in job_list:
    if item.get_last_build().get_status()=='SUCCESS':
        result+=1
print 'Jobs build status:'+str(result)+' build successfully!'
print 'Checking test results finished...\n'
        
'''Generate report'''
print '###################Generate test report mail template'                
job_dict={}
content=''
for item in job_list:
    url=item.get_last_build().get_result_url()
    url=url[:url.rfind('/test')]
    #duration=item.get_last_build().get_duration()
    status=item.get_last_build().get_status()
    duration=item.get_last_build().get_duration().__str__()[:7]
    if item.get_last_build().get_artifact_dict().has_key('overview.html'):
        reportUrl=item.get_last_build().get_artifact_dict()['overview.html'].url
    else:
        reportUrl='There is no test report for faltal error'    
    template='''
    <p class="MsoNormal" style="line-height:115%"><span style="font-size:10.5pt;line-height:115%;\
    font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Build Job Name:<o:p></o:p></span></p>\
    </td><td style="padding:3.0pt 3.0pt 3.0pt 3.0pt">\
    <p class="MsoNormal" style="line-height:115%"><a target="_blank"><span style="font-size:10.5pt\
    ;line-height:115%;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">'''+str(item)+'''</span>\
    </a><span style="font-size:10.5pt;line-height:115%;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">\
    <o:p></o:p></span></p></td></tr><tr><td style="padding:3.0pt 3.0pt 3.0pt 3.0pt">\
    <p class="MsoNormal" style="line-height:115%"><span style="font-size:10.5pt;line-height:115%;\
    font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Build Status:<o:p></o:p></span></p></td>\
    <td style="padding:3.0pt 3.0pt 3.0pt 3.0pt">\
    <p class="MsoNormal" style="line-height:115%"><a target="_blank"><span style="font-size:10.5pt;\
    line-height:115%;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Build '''+status+'''!</span>\
    </a><span style="font-size:10.5pt;line-height:115%;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;"> \
    <o:p></o:p></span></p></td></tr><tr><td style="padding:3.0pt 3.0pt 3.0pt 3.0pt">\
    <p class="MsoNormal" style="line-height:115%"><span style="font-size:10.5pt;line-height:115%;font-family\
    :&quot;Arial&quot;,&quot;sans-serif&quot;">Build URL:<o:p></o:p></span></p></td><td style="padding:\
    3.0pt 3.0pt 3.0pt 3.0pt">\
    <p class="MsoNormal" style="line-height:115%"><a href="'''+url+'''" target="_blank">\
    <span style="font-size:10.5pt;line-height:115%;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">\
    '''+url+'''</span></a><span style="font-size:10.5pt;line-height:115%;font-family:&quot;Arial&quot;\
    ,&quot;sans-serif&quot;"> <o:p></o:p></span></p></td></tr><tr><td style="padding:3.0pt 3.0pt 3.0pt 3.0pt">
    
    <p class="MsoNormal" style="line-height:115%"><span style="font-size:10.5pt;line-height:115%;font-family\
    :&quot;Arial&quot;,&quot;sans-serif&quot;">Test Report URL:<o:p></o:p></span></p></td><td style="padding:\
    3.0pt 3.0pt 3.0pt 3.0pt">\
    <p class="MsoNormal" style="line-height:115%"><a href="'''+reportUrl+'''" target="_blank">\
    <span style="font-size:10.5pt;line-height:115%;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">\
    '''+reportUrl+'''</span></a><span style="font-size:10.5pt;line-height:115%;font-family:&quot;Arial&quot;\
    ,&quot;sans-serif&quot;"> <o:p></o:p></span></p></td></tr><tr><td style="padding:3.0pt 3.0pt 3.0pt 3.0pt">    
    
    
    <p class="MsoNormal" style="line-height:115%"><span style="font-size:10.5pt;line-height:115%;font-family\
    :&quot;Arial&quot;,&quot;sans-serif&quot;">Build Duration:<o:p></o:p></span></p></td><td style="padding:\
    3.0pt 3.0pt 3.0pt 3.0pt">\
    <p class="MsoNormal" style="line-height:115%"><a target="_blank">\
    <span style="font-size:10.5pt;line-height:115%;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">\
    '''+duration+'''</span></a><span style="font-size:10.5pt;line-height:115%;font-family:&quot;Arial&quot;\
    ,&quot;sans-serif&quot;"> <o:p></o:p></span></p></td></tr><tr><td style="padding:3.0pt 3.0pt 3.0pt 3.0pt">    

    '''
    content+=template


fh=open(os.environ['WORKSPACE']+'/result.html','w')
fh.write(content)
fh.close()
print 'Generate test report mail template finished...\n'

print '###################Checking all results of each jobs'
#if result!=job_list.__len__():
if result==0:
    raise Exception('Failed Exception','Test failed on android...')            
print 'Check all results finished,build successfully!\n'








'''
<!-- #################SecHouse Web automation WorkFlow -->
<html>
<head>
</head>
<body>
<div id="contentDiv" onmouseover="getTop().stopPropagation(event);" onclick="getTop().preSwapLink(event, 'html', 'ZC2904-JRUjssitPyHIDjxpqnzhd59');" style="position:relative;font-size:14px;height:auto;padding:15px 15px 10px 15px;z-index:1;zoom:1;line-height:1.7;" class="body">    
<div id="qm_con_body">
<div id="mailContentContainer" class="qmbox qm_con_body_content">
<style></style>
<div class="WordSection1">

<p class="MsoNormal" style="line-height:30.0pt"><span style="font-size:30.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;;color:#3892D0">Jenkins - </span><span class="title-green1"><span style="font-size:30.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">二手房WEB 自动化测试 build $BUILD_STATUS!</span></span><span style="font-size:30.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;;color:#3892D0"> <o:p></o:p></span></p>
<p class="MsoNormal"><b><span style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Build Details:<o:p></o:p></span></b></p><table class="MsoNormalTable" border="0" cellspacing="0" cellpadding="0" style="border-collapse:collapse"><tbody><tr><td style="padding:3.0pt 3.0pt 3.0pt 3.0pt">

<!--p class="MsoNormal" style="line-height:115%"><span style="font-size:10.5pt;line-height:115%;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Build URL:<o:p></o:p></span></p></td><td style="padding:3.0pt 3.0pt 3.0pt 3.0pt">
<p class="MsoNormal" style="line-height:115%"><a href="$BUILD_URL" target="_blank"><span style="font-size:10.5pt;line-height:115%;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">$BUILD_URL</span></a><span style="font-size:10.5pt;line-height:115%;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;"> <o:p></o:p></span></p></td></tr><tr><td style="padding:3.0pt 3.0pt 3.0pt 3.0pt">

<p class="MsoNormal" style="line-height:115%"><span style="font-size:10.5pt;line-height:115%;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Build Console:<o:p></o:p></span></p></td><td style="padding:3.0pt 3.0pt 3.0pt 3.0pt">
<p class="MsoNormal" style="line-height:115%"><a href="${BUILD_URL}console" target="_blank"><span style="font-size:10.5pt;line-height:115%;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">${BUILD_URL}console<o:p></o:p></span></p></td></tr><tr><td style="padding:3.0pt 3.0pt 3.0pt 3.0pt">

<p class="MsoNormal" style="line-height:115%"><span style="font-size:10.5pt;line-height:115%;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Build Test Report:<o:p></o:p></span></p></td><td style="padding:3.0pt 3.0pt 3.0pt 3.0pt">
<p class="MsoNormal" style="line-height:115%"><a href="${BUILD_URL}artifact/TestReport/TestReport.html" target="_blank"><span style="font-size:10.5pt;line-height:115%;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">${BUILD_URL}artifact/fddWebAutomation/target/surefire-reports/html/overview.html<o:p></o:p></span></p></td></tr><tr><td style="padding:3.0pt 3.0pt 3.0pt 3.0pt"-->

${FILE,path="result.html"}

<p class="MsoNormal" style="line-height:115%"><span style="font-size:10.5pt;line-height:115%;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Build Machine:<o:p></o:p></span></p></td><td style="padding:3.0pt 3.0pt 3.0pt 3.0pt">
<p class="MsoNormal" style="line-height:115%"><span style="font-size:10.5pt;line-height:115%;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">$NODE_NAME<o:p></o:p></span></p></td></tr><tr><td style="padding:3.0pt 3.0pt 3.0pt 3.0pt">
<p class="MsoNormal" style="line-height:115%">

</div>
</body>
</html>
'''