#coding=utf8
'''
@Created on Nov 24, 2015
@author: 皇甫
@version: 1.0
'''
from optparse import OptionParser
'''接口测试用例'''
from testCase.FangduoduoRestfulTesting import *

'''app测试用例'''
from testCase.FangduoduoApp import *

'''接口测试base类'''
from testCase.RestTestCaseBaseClass import RestTestCaseBaseClass

###########################################
# Here are all the test suties defined here,
# as we can define some
# 增加testSuite
# 1.增加testSuite
# 2.在AllSuite增加
# 3.在process_options的choices增加相应字符串
###########################################

##生成test case
scriptPath=os.path.abspath(os.path.join(os.path.dirname(os.path.realpath(__file__)))).replace('\\','/')
if os.environ.has_key('JENKINS_HOME' ):
    test=os.environ['TEST_ENV' ]
else:
    for i in open(scriptPath+'/config/rest.cfg' ,'r' ):
        if i.count('TEST_ENV =')!=0:
            test=i[11:-1]
            break
#exec(lib.convert_json_to_test_case(scriptPath+'/config/test_case.json' ,test))

class TestSuite:
    scriptPath=os.path.abspath(os.path.join(os.path.dirname(os.path.realpath(__file__)))).replace('\\','/')
    
    def __init__(self,name,test_list=[]):
        self.test_list=test_list
        self.name = name
        
    def parse_args(self, args):
        for arg in args:
            print 'TestSuite: %s args: %s' %(self.name, arg)

    def execute(self):
        #运行全部用例
        runner = lib.HTMLTestRunner(stream='TestReport.html',title="Test Result",description='Test Suite')
        testsuite = unittest.TestSuite()
        
        for test in self.test_list:
            testsuite.addTest(test)
        runner.run(testsuite)
        #运行完成后拷贝测试报告到jenkins job workspace
        if os.environ.has_key('JENKINS_HOME'):
            import shutil
            if platform.system()=='Windows':
                shutil.copytree('.',os.environ['WORKSPACE']+'\\TestReport')
            else:
                shutil.copytree('.',os.environ['WORKSPACE']+'/TestReport')
        #根据计数器判定整体用例pass或者fail
        if ((runner.failure_count !=0) or (runner.error_count!=0)):
            raise Exception('Test Suite execute finished,Test suite failed...')
    
    #def start_genymotion(self,genymotionPath='C:/Program Files/Genymobile/Genymotion/genymotion.exe'):
    #    self.sikuli.sikuli_open('genymotion1',genymotionPath,self.scriptPath+'/utils/sikuliPictures/start.jpg')
    #    for item in self.conf.android_test_version.split(','):
    #        self.sikuli.sikuli_double_click(self.scriptPath+'/utils/sikuliPictures/'+item+'.png')
    #        self.get_UDID(item)
    #
    #        self.sikuli.sikuli_active('genymotion1')
    #
    #def get_UDID(self,androidVersion):
    #    while 1:
    #        out=lib.exec_local('adb devices')[1]
    #        time.sleep(10)
    #        if self.adbStr!=out:
    #            self.adbStr=out
    #            self.UDIDDict[androidVersion]=(out.split('\r\n')[-3][0:19])
    #            return
    #    
    #def start_appium_drivers(self):        
    #    port=4723
    #    for item in self.conf.android_test_version.split(','):
    #        self.sikuli.sikuli_open('cmd'+item,'"cmd.exe"',self.scriptPath+'/utils/sikuliPictures/cmd.png',True)
    #        self.sikuli.sikuli_type('cd '+self.conf.appium_path+'/node_modules/.bin\r')
    #        self.sikuli.sikuli_type('appium.cmd -p '+str(port)+' -bp '+str(port+1)+' --session-override -U '+self.UDIDDict[item]+' \r')
    #        self.sikuli.min_window('cmd'+item)
    #        port+=2
    #    #self.sikuli.sikuli_close('cmd',True)
    #    #self.sikuli.sikuli_close('appium')
    #    
    #def close_appium_drivers(self,win32Type=True):
    #    for item in self.conf.android_test_version.split(','):
    #        self.sikuli.sikuli_close('cmd'+item,win32Type)
        

#################################### 
# Define different kind of testsuite
####################################

preCheckInTestSuite = TestSuite(name='preCheckInTestSuite',
                                 test_list=[LoginTest('test_install_fangdd_on_android'),
                                            LoginTest('test_change_test_env'),
                                            LoginTest('test_login_in_ui'),
                                            LoginTest('test_login_in_with_wrong_string'),
                                            LoginTest('test_login_in_with_wrong_username'),
                                            LoginTest('test_kan_fang_login_page'),
                                            #SecondHandHouseTest('test_click_second_hand_house'),
                                            SecondHandHouseTest('test_reduce_price_sencond_hand_house'),
                                            SecondHandHouseTest('test_second_house_pop_window'),
                                            SecondHandHouseTest('test_second_house_search_box'),
                                            SecondHandHouseTest('test_second_house_hint'),
                                            SecondHandHouseSortTest('test_second_house_sort_by_unit_price'),
                                            SecondHandHouseSortTest('test_second_house_sort_by_total_price'),
                                            SecondHandHouseSortTest('test_second_house_sort_by_area'),
                                            SearchBoxTest('test_click_search_box'),
                                            SearchBoxTest('test_search_box_with_swipe'),
                                            SearchBoxTest('test_location_in_search_box'),
                                            SearchBoxTest('test_click_letter_location_in_search_box'),
                                            
                                            #二手房列表页位置区域筛选用例。
                                            SecondHandHouseLocationTest('test_second_house_location_area_baoshan'),
                                            #SecondHandHouseLocationTest('test_second_house_location_area_songjiang'),
                                            #SecondHandHouseLocationTest('test_second_house_location_area_yangpu'),
                                            #SecondHandHouseLocationTest('test_second_house_location_area_putuo'),
                                            #SecondHandHouseLocationTest('test_second_house_location_area_jiading'),
                                            #SecondHandHouseLocationTest('test_second_house_location_area_xuhui'),
                                            #SecondHandHouseLocationTest('test_second_house_location_area_zhabei'),
                                            #SecondHandHouseLocationTest('test_second_house_location_area_fengxian'),
                                            #SecondHandHouseLocationTest('test_second_house_location_area_hongkou'),
                                            #SecondHandHouseLocationTest('test_second_house_location_area_jinshan'),
                                            #SecondHandHouseLocationTest('test_second_house_location_area_qingpu'),
                                            #SecondHandHouseLocationTest('test_second_house_location_area_changning'),
                                            #SecondHandHouseLocationTest('test_second_house_location_area_jingan'),
                                            #SecondHandHouseLocationTest('test_second_house_location_area_chongming'),
                                            #SecondHandHouseLocationTest('test_second_house_location_area_huangpu'),                                             
                                            
                                            #二手房列表页位置地铁筛选用例。
                                            SecondHandHouseLocationTestSubWay('test_second_house_subway_line1'),
                                            #SecondHandHouseLocationTestSubWay('test_second_house_subway_line2'),                                            #SecondHandHouseLocationTest('test_second_house_location_area_minhang'),
                                            #SecondHandHouseLocationTestSubWay('test_second_house_subway_line3'),                                            #SecondHandHouseLocationTest('test_second_house_location_area_pudong'),
                                            #SecondHandHouseLocationTestSubWay('test_second_house_subway_line4'), 
                                            
                                            #地铁房测试用例集
                                            SubwayHouseTest('test_subway_house_title'),
                                            SubwayHouseTest('test_sort_by_unit_price'),
                                            SubwayHouseTest('test_sort_by_total_price'),
                                            SubwayHouseTest('test_sort_by_area'),
                                            SubwayHouseTest('test_sort_by_res_num'),
                                            SubwayHouseLocationTest('test_subway_house_subway_line1'),
                                            
                                            
                                            HomePageTest('test_click_search_box'),
                                            HomePageTest('test_search_history'),
                                            HomePageTest('test_clear_search_history'),
                                            HomePageTest('test_search_new_house'),
                                            HomePageTest('test_search_new_house_and_second_house'),
                                            HomePageTest('test_search_with_huxing'),
                                            
                                            #二手房精品类目，新上房源
                                            SecondHandHouseColumnNewHouseLocationTest('test_second_house_column_new_house_location_area_baoshan'),
                                            SecondHandHouseColumnNewHouseSortTest('test_second_house_sort_by_unit_price'),
                                            SecondHandHouseColumnNewHouseSortTest('test_second_house_sort_by_total_price'),
                                            SecondHandHouseColumnNewHouseSortTest('test_second_house_sort_by_area'),
                                            SecondHandHouseColumnNewHouseFilterTest('test_second_house_list_page_filter'),
                                            SecondHandHouseColumnNewHouseFilterTest('test_second_house_label_filter'),
                                            
                                            #二手房精品类目，降价房源
                                            SecondHandHouseColumnSaleHouseLocationTest('test_second_house_column_sale_house_location_area_baoshan'),
                                            SecondHandHouseColumnSaleHouseSortTest('test_second_house_sort_by_unit_price'),
                                            SecondHandHouseColumnSaleHouseSortTest('test_second_house_sort_by_total_price'),
                                            SecondHandHouseColumnSaleHouseSortTest('test_second_house_sort_by_area'),
                                            SecondHandHouseColumnSaleHouseFilterTest('test_second_house_list_page_filter'),
                                            SecondHandHouseColumnSaleHouseFilterTest('test_second_house_label_filter'),
                                            
                                            #二手房精品类目，全城热卖
                                            SecondHandHouseColumnHotHouseLocationTest('test_second_house_column_hot_house_location_area_baoshan'),
                                            SecondHandHouseColumnHotHouseSortTest('test_second_house_sort_by_unit_price'),
                                            SecondHandHouseColumnHotHouseSortTest('test_second_house_sort_by_total_price'),
                                            SecondHandHouseColumnHotHouseSortTest('test_second_house_sort_by_area'),
                                            SecondHandHouseColumnHotHouseFilterTest('test_second_house_list_page_filter'),
                                            SecondHandHouseColumnHotHouseFilterTest('test_second_house_label_filter'),
                                            ]
                                )

#去除安装步骤
preCheckInTestSuite2 = TestSuite(name='preCheckInTestSuite2',
                                 test_list=[#LoginTest('test_install_fangdd_on_android'),
                                            #LoginTest('test_change_test_env'),
                                            LoginTest('test_login_in_ui'),
                                            LoginTest('test_login_in_with_wrong_string'),
                                            LoginTest('test_login_in_with_wrong_username'),
                                            LoginTest('test_kan_fang_login_page'),
                                            #SecondHandHouseTest('test_click_second_hand_house'),
                                            SecondHandHouseTest('test_reduce_price_sencond_hand_house'),
                                            #SecondHandHouseTest('test_second_house_pop_window'),
                                            SecondHandHouseTest('test_second_house_search_box'),
                                            SecondHandHouseTest('test_second_house_hint'),
                                            SecondHandHouseSortTest('test_second_house_sort_by_unit_price'),
                                            SecondHandHouseSortTest('test_second_house_sort_by_total_price'),
                                            SecondHandHouseSortTest('test_second_house_sort_by_area'),
                                            SearchBoxTest('test_click_search_box'),
                                            SearchBoxTest('test_search_box_with_swipe'),
                                            SearchBoxTest('test_location_in_search_box'),
                                            SearchBoxTest('test_click_letter_location_in_search_box'),
                                            
                                            #二手房列表页位置区域筛选用例。
                                            SecondHandHouseLocationTest('test_second_house_location_area_baoshan'),
                                            SecondHandHouseLocationTest('test_second_house_location_area_minhang'),
                                            SecondHandHouseLocationTest('test_second_house_location_area_pudong'),                                           
                                            SecondHandHouseLocationTest('test_second_house_location_area_songjiang'),
                                            SecondHandHouseLocationTest('test_second_house_location_area_yangpu'),
                                            SecondHandHouseLocationTest('test_second_house_location_area_putuo'),
                                            SecondHandHouseLocationTest('test_second_house_location_area_jiading'),
                                            SecondHandHouseLocationTest('test_second_house_location_area_xuhui'),
                                            SecondHandHouseLocationTest('test_second_house_location_area_zhabei'),
                                            SecondHandHouseLocationTest('test_second_house_location_area_fengxian'),
                                            SecondHandHouseLocationTest('test_second_house_location_area_hongkou'),
                                            SecondHandHouseLocationTest('test_second_house_location_area_jinshan'),
                                            SecondHandHouseLocationTest('test_second_house_location_area_qingpu'),
                                            SecondHandHouseLocationTest('test_second_house_location_area_changning'),
                                            SecondHandHouseLocationTest('test_second_house_location_area_jingan'),
                                            SecondHandHouseLocationTest('test_second_house_location_area_chongming'),
                                            SecondHandHouseLocationTest('test_second_house_location_area_huangpu'),
                                            
                                            #二手房列表页位置地铁筛选用例。
                                            SecondHandHouseLocationTestSubWay('test_second_house_subway_line1'),
                                            SecondHandHouseLocationTestSubWay('test_second_house_subway_line2'),                                            #SecondHandHouseLocationTest('test_second_house_location_area_minhang'),
                                            SecondHandHouseLocationTestSubWay('test_second_house_subway_line3'),                                            #SecondHandHouseLocationTest('test_second_house_location_area_pudong'),
                                            SecondHandHouseLocationTestSubWay('test_second_house_subway_line4'),
                                            SecondHandHouseLocationTestSubWay('test_second_house_subway_line5'),
                                            SecondHandHouseLocationTestSubWay('test_second_house_subway_line6'),
                                            SecondHandHouseLocationTestSubWay('test_second_house_subway_line7'),
                                            SecondHandHouseLocationTestSubWay('test_second_house_subway_line8'),
                                            SecondHandHouseLocationTestSubWay('test_second_house_subway_line9'),
                                            SecondHandHouseLocationTestSubWay('test_second_house_subway_line10'),
                                            SecondHandHouseLocationTestSubWay('test_second_house_subway_line11'),
                                            SecondHandHouseLocationTestSubWay('test_second_house_subway_line12'),
                                            SecondHandHouseLocationTestSubWay('test_second_house_subway_line13'),
                                            SecondHandHouseLocationTestSubWay('test_second_house_subway_line16'),

                                            #地铁房测试用例集
                                            SubwayHouseTest('test_subway_house_title'),
                                            #SubwayHouseTest('test_sort_by_unit_price'),
                                            #SubwayHouseTest('test_sort_by_total_price'),
                                            #SubwayHouseTest('test_sort_by_area'),
                                            #SubwayHouseTest('test_sort_by_res_num'),
                                            #SubwayHouseLocationTest('test_subway_house_subway_line1'),
                                            
                                            
                                            HomePageTest('test_click_search_box'),
                                            HomePageTest('test_search_history'),
                                            HomePageTest('test_clear_search_history'),
                                            HomePageTest('test_search_new_house'),
                                            HomePageTest('test_search_new_house_and_second_house'),
                                            HomePageTest('test_search_with_huxing'),
                                            
                                            #二手房精品类目，新上房源
                                            #SecondHandHouseColumnNewHouseLocationTest('test_second_house_column_new_house_location_area_baoshan'),
                                            #SecondHandHouseColumnNewHouseSortTest('test_second_house_sort_by_unit_price'),
                                            #SecondHandHouseColumnNewHouseSortTest('test_second_house_sort_by_total_price'),
                                            #SecondHandHouseColumnNewHouseSortTest('test_second_house_sort_by_area'),
                                            #SecondHandHouseColumnNewHouseFilterTest('test_second_house_list_page_filter'),
                                            #SecondHandHouseColumnNewHouseFilterTest('test_second_house_label_filter'),
                                            
                                            #二手房精品类目，降价房源
                                            #SecondHandHouseColumnSaleHouseLocationTest('test_second_house_column_sale_house_location_area_baoshan'),
                                            #SecondHandHouseColumnSaleHouseSortTest('test_second_house_sort_by_unit_price'),
                                            #SecondHandHouseColumnSaleHouseSortTest('test_second_house_sort_by_total_price'),
                                            #SecondHandHouseColumnSaleHouseSortTest('test_second_house_sort_by_area'),
                                            #SecondHandHouseColumnSaleHouseFilterTest('test_second_house_list_page_filter'),
                                            #SecondHandHouseColumnSaleHouseFilterTest('test_second_house_label_filter'),
                                            
                                            #二手房精品类目，全城热卖
                                            #SecondHandHouseColumnHotHouseLocationTest('test_second_house_column_hot_house_location_area_baoshan'),
                                            #SecondHandHouseColumnHotHouseSortTest('test_second_house_sort_by_unit_price'),
                                            #SecondHandHouseColumnHotHouseSortTest('test_second_house_sort_by_total_price'),
                                            #SecondHandHouseColumnHotHouseSortTest('test_second_house_sort_by_area'),
                                            #SecondHandHouseColumnHotHouseFilterTest('test_second_house_list_page_filter'),
                                            #SecondHandHouseColumnHotHouseFilterTest('test_second_house_label_filter'),
                                            ]
                                )

nightlyTestSuite = TestSuite(name='nightlyTestSuite',
                                 test_list=[LoginTest('test_install_fangdd_on_android'),
                                            LoginTest('test_login_in_ui'),
                                            LoginTest('test_login_in_with_wrong_string'),
                                            LoginTest('test_login_in_with_wrong_username'),
                                            LoginTest('test_kan_fang_login_page'),
                                            #SecondHandHouseTest('test_click_second_hand_house'),
                                            SecondHandHouseTest('test_reduce_price_sencond_hand_house'),
                                            SecondHandHouseTest('test_second_house_pop_window'),
                                            SecondHandHouseTest('test_second_house_search_box'),
                                            SecondHandHouseTest('test_second_house_hint'),
                                            SecondHandHouseSortTest('test_second_house_sort_by_unit_price'),
                                            SecondHandHouseSortTest('test_second_house_sort_by_total_price'),
                                            SecondHandHouseSortTest('test_second_house_sort_by_area'),
                                            SearchBoxTest('test_click_search_box'),
                                            SearchBoxTest('test_search_box_with_swipe'),
                                            SearchBoxTest('test_location_in_search_box'),
                                            SearchBoxTest('test_click_letter_location_in_search_box'),                                            
                                            SecondHandHouseLocationTestSubWay('test_second_house_subway_line1'),
                                            SecondHandHouseLocationTestSubWay('test_second_house_subway_line2'),                                            
                                            SecondHandHouseLocationTestSubWay('test_second_house_subway_line3'),                                            
                                            SecondHandHouseLocationTestSubWay('test_second_house_subway_line4'),
                                            SecondHandHouseLocationTestSubWay('test_second_house_subway_line5'),                                            
                                            SecondHandHouseLocationTestSubWay('test_second_house_subway_line6'),
                                            SecondHandHouseLocationTestSubWay('test_second_house_subway_line7'),
                                            SecondHandHouseLocationTestSubWay('test_second_house_subway_line8'),                                            
                                            SecondHandHouseLocationTestSubWay('test_second_house_subway_line9'),
                                            SecondHandHouseLocationTestSubWay('test_second_house_subway_line10'),
                                            SecondHandHouseLocationTestSubWay('test_second_house_subway_line11'),                                           
                                            SecondHandHouseLocationTestSubWay('test_second_house_subway_line12'),
                                            SecondHandHouseLocationTestSubWay('test_second_house_subway_line13'),
                                            SecondHandHouseLocationTestSubWay('test_second_house_subway_line16'),
                                            SecondHandHouseLocationTest('test_second_house_location_area_baoshan'),
                                            SecondHandHouseLocationTest('test_second_house_location_area_minhang'),
                                            SecondHandHouseLocationTest('test_second_house_location_area_pudong'),
                                            SecondHandHouseLocationTest('test_second_house_location_area_songjiang'),
                                            SecondHandHouseLocationTest('test_second_house_location_area_yangpu'),
                                            SecondHandHouseLocationTest('test_second_house_location_area_putuo'),
                                            SecondHandHouseLocationTest('test_second_house_location_area_jiading'),
                                            SecondHandHouseLocationTest('test_second_house_location_area_xuhui'),
                                            SecondHandHouseLocationTest('test_second_house_location_area_zhabei'),
                                            SecondHandHouseLocationTest('test_second_house_location_area_fengxian'),
                                            SecondHandHouseLocationTest('test_second_house_location_area_hongkou'),
                                            SecondHandHouseLocationTest('test_second_house_location_area_jinshan'),
                                            SecondHandHouseLocationTest('test_second_house_location_area_qingpu'),
                                            SecondHandHouseLocationTest('test_second_house_location_area_changning'),
                                            SecondHandHouseLocationTest('test_second_house_location_area_jingan'),
                                            SecondHandHouseLocationTest('test_second_house_location_area_chongming'),
                                            SecondHandHouseLocationTest('test_second_house_location_area_huangpu'),
                                            SubwayHouseTest('test_subway_house_title'),
                                            SubwayHouseTest('test_sort_by_unit_price'),
                                            SubwayHouseTest('test_sort_by_total_price'),
                                            SubwayHouseTest('test_sort_by_area'),
                                            SubwayHouseTest('test_sort_by_res_num'),
                                            SubwayHouseLocationTest('test_subway_house_subway_line1'),
                                            HomePageTest('test_click_search_box'),
                                            HomePageTest('test_search_history'),
                                            HomePageTest('test_clear_search_history'),
                                            HomePageTest('test_search_new_house'),
                                            HomePageTest('test_search_new_house_and_second_house'),
                                            HomePageTest('test_search_with_huxing'),
                                            ]
                             )

restPreCheckInTestSuite = TestSuite(name='restPreCheckInTestSuite',
                                 test_list=[
                                            RestLoginTest('test_rest_login_and_log_out'),
                                            RestModifyPassword('test_modify_password_with_old_password'),
                                            RestModifyPassword('test_modify_password_with_auth_code'),
                                            RestGetAuthCode('test_get_auth_code'),                                                                                                                                    
                                            #RestGeneralTestCase('test_check_current_mobile'),
                                            RestGetSupportedCityList('test_get_supported_city_list'),
                                            RestGetMessageList('test_get_message_list'),
                                            RestGetMessage('test_get_message'),
                                            RestGetUnreadMessage('test_get_unread_message'),
                                            RestGetUserProfile('test_get_user_profile'),                                         
                                            #RestGeneralTestCase('test_set_password'),
                                            #RestGeneralTestCase('test_upload_device_info'),
                                            RestGetAggregateHouseSource('test_get_aggregate_house_source'),
                                            RestGetAttentionHouseSource('test_get_attention_house_source'),
                                            RestCancelAttentionHouseSource('test_cancel_attention_house_source'),
                                            RestGetAttentionHouseSourceList('test_get_attention_house_source_list'),
                                            #RestGeneralTestCase('test_get_house_source_menu'),
                                            #RestGeneralTestCase('test_get_all_house_source_filter_conditions_menu'),
                                            #RestGeneralTestCase('test_get_metrothouse_source_menu'),
                                            #RestGeneralTestCase('test_get_metro_list'),
                                            #RestGeneralTestCase('test_get_house_source_list'),
                                            #RestGeneralTestCase('test_aggregate_house_source'),
                                            RestGetRecentPriceCutHouse('test_get_recent_price_cut_house'),
                                            #RestGeneralTestCase('test_search_hints'),
                                            RestGetHouseSourceDetail('test_get_house_source_detail'),
                                            RestGetHouseSourceBasicInfo('test_get_house_source_basic_info'),                                            
                                            RestGetHouseSourceAllComments('test_get_house_source_all_comments'),                                  
                                            #RestGetReverseList('test_get_reverse_list'),
                                            RestGetHotLines('test_get_hot_lines'),
                                            RestGetHotDistrict('test_get_hot_district'),
                                            RestGetBanner('test_get_banner'),
                                            RestGetAdvertisement('test_get_advertisement'),
                                            RestGetPopupWindows('test_get_popup_windows'),
                                            RestGetCellBasicInfo('test_get_cell_basic_info'),
                                            #RestGeneralTestCase('test_get_cell_from_cell_name'),
                                            RestTalkWithSeller('test_talk_with_seller'),
                                            #RestGeneralTestCase('test_send_invitation_code'),
                                            #RestGeneralTestCase('test_group_send_agent'),
                                            RestGetSellPublishedHouseSourceList('test_get_sell_publich_house_source_list'),
                                            RestGetSellerHouseSourceDetailInformation('test_get_seller_house_source_detail_information'),
                                            RestGetSupportedReserveMethod('test_get_supported_reserve_method'), 
                                            #RestGeneralTestCase('test_get_agent_profile'),
                                            RestGetNearbyAgentProfile('test_get_nearby_agent_profile'),
                                            RestGetHouseDirections('test_get_house_directions'),
                                            RestGenerateFinanceSign('test_generate_finance_sign'),
                                            RestHomePage('test_home_page'),
                                            RestGetRecommandHouseSource('test_get_recommand_house_source'),
                                            RestShareSuccess('test_share_success'),
                                            #RestGeneralTestCase('test_report_house_source'),
                                            RestReportUser('test_report_user'),
                                            RestGetUserReportStatus('test_get_user_report_status'),
                                            #RestGeneralTestCase('test_house_evaluate'),
                                            RestGetBuyerConsultList('test_get_buyer_consult_list'),
                                            RestGetSellerConsultList('test_get_seller_consult_list'),
                                            RestGetXiaoduoProfile('test_get_xiaoduo_profile'),
                                            RestGetBoutiqueSecondHouses('test_get_boutique_second_houses'),
                                            RestGetHouseSourceFans('test_get_house_source_fans'),
                                            RestGetOwnerInfo('test_get_owner_info'),
                                            RestGetAppMetaSetting('test_get_app_meta_settings'),
                                            
                                            ##春峰完成
                                            #筛选接口测试
                                            RestChoice('test_choiceHouse1' ),
                                            RestChoice('test_choiceHouse2' ),
                                            RestChoice('test_choiceHouse3' ),
                                            RestChoice('test_filter_with_shang_men_shi_kan'),
                                            RestChoice('test_filter_with_wu_dai_kuan'),
                                            RestChoice('test_filter_with_man_wu_wei_yi'),
                                            RestChoice('test_filter_with_man_liang_nian'),
                                            RestChoice('test_filter_with_dian_tie_fang'),
                                            RestChoice('test_filter_with_xue_qu_fang' ),
                                            RestChoice('test_filter_with_zongjia_100_yi_xia' ),
                                            RestChoice('test_filter_with_zongjia_100_150' ),
                                            RestChoice('test_filter_with_zongjia_150_200' ),
                                            RestChoice('test_filter_with_zongjia_200_300' ),
                                            RestChoice('test_filter_with_zongjia_300_400' ),
                                            RestChoice('test_filter_with_zongjia_400_500' ),
                                            RestChoice('test_filter_with_zongjia_500_700' ),
                                            RestChoice('test_filter_with_zongjia_700_1000'),
                                            RestChoice('test_filter_with_zongjia_1000_up' ),
                                            RestChoice('test_filter_with_1_shi' ),
                                            RestChoice('test_filter_with_2_shi' ),
                                            RestChoice('test_filter_with_3_shi' ),
                                            RestChoice('test_filter_with_4_shi' ),
                                            RestChoice('test_filter_with_5_shi' ),
                                                                                        
                                            #获取个人profile接口测试用例
                                            RestProfile('test_basic_profile' ),
                                            RestProfile('test_order_history' ),
                                            RestProfile('test_order_detail' ),
                                            #RestProfile('test_order_detail_info'  ),
                                            
                                            #找房神探接口测试用例
                                            #RestDetective('test_detective_price'),
                                            #RestDetective('test_detective_layout'),
                                            #RestDetective('test_detective_multiple_layout'),
                                            #RestDetective('test_detective_location'),
                                            #RestDetective('test_detective_price_and_layout'),
                                            
                                            #获取板块信息接口用例
                                            RestBlock('test_block_content' ),
                                            
                                            #板块地图接口
                                            #获取后台配置接口用例
                                            RestGetServerConfiguration('test_nearby_item' ),
                                            RestGetServerConfiguration('test_filter_house_tags' ),
                                            
                                            #房源接口
                                            RestHouseSourceTest('test_publish_house_source'),
                                            RestHouseSourceTest('test_online_house_source'),
                                            RestHouseSourceTest('test_offline_house_source'),
                                            RestHouseSourceTest('test_modify_house_price'),
                                            RestHouseSourceTest('test_edit_house_info'),
                                            RestHouseSourceTest('test_delete_house_source'),   
                                            RestReverseHouseTest('test_reverse_house_source'),
                                            RestReverseHouseTest('test_same_type_house_source_reverse'),
                                            RestReverseHouseTest('test_buyer_get_reserve_list'),
                                            RestReverseHouseTest('test_buyer_get_reserve_detail'),
                                            RestReverseHouseTest('test_push_reversvation'),#栋嘉催约用例
                                            RestReverseHouseTest('test_seller_get_reserve_list'),
                                            RestReverseHouseTest('test_seller_get_reserve_detail'),
                                            RestReverseHouseTest('test_seller_agree_reservation'),
                                            RestReverseHouseTest('test_cancel2_reservation'),
                                            RestReverseHouseTest('test_confirm_to_see'),
                                            RestReverseHouseTest('test_buyer_remove_reservation'),
                                            RestReverseHouseTest('test_seller_remove_reservation'),
                                            ]
                                    )


All_Test_Suite = [preCheckInTestSuite,preCheckInTestSuite2,nightlyTestSuite,restPreCheckInTestSuite,] 

def listAllNameStartedWith(prefix, list=[], filteredList=[]):
    for item in list:
        startIndex = item.rfind(prefix,0,len(prefix))
        if -1 != startIndex:
            filteredList.append(item)

def listAllTestCasesOf(type):
    testCases = []
    filteredList = []
    if type == 'preCheckInTestSuite':
        testCases = dir(LoginTest)
        listAllNameStartedWith('test',testCases,filteredList)
        for item in filteredList:  
            print '----[TestCase] %s' % item
        
        filteredList = []
        testCases = dir(SecondHandHouseTest)
        listAllNameStartedWith('test',testCases,filteredList)
        for item in filteredList:  
            print '----[TestCase] %s' % item

        filteredList = []
        testCases = dir(SearchBoxTest)
        listAllNameStartedWith('test',testCases,filteredList)
        for item in filteredList:  
            print '----[TestCase] %s' % item
            
    elif type=='nightlyTestSuite':
        testCases = dir(LoginTest)
        listAllNameStartedWith('test',testCases,filteredList)
        for item in filteredList:  
            print '----[TestCase] %s' % item
        
        filteredList = []        
        testCases = dir(SecondHandHouseTest)
        listAllNameStartedWith('test',testCases,filteredList)
        for item in filteredList:  
            print '----[TestCase] %s' % item   

        filteredList = []
        testCases = dir(SearchBoxTest)
        listAllNameStartedWith('test',testCases,filteredList)
        for item in filteredList:  
            print '----[TestCase] %s' % item 
            
    elif type=='restPreCheckInTestSuite':
        testCases = dir(RestLoginTest)
        listAllNameStartedWith('test',testCases,filteredList)
        for item in filteredList:  
            print '----[TestCase] %s' % item

        filteredList = []        
        testCases = dir(RestModifyPassword)
        listAllNameStartedWith('test',testCases,filteredList)
        for item in filteredList:  
            print '----[TestCase] %s' % item
            
    else: 
        print '----[TestCase] %s' % "Not implemented"

def listAllTestSuite():
    for testSuite in All_Test_Suite:
        print '[TestSuite] %s' % (testSuite.name)

def listAllTestCasesAndSuit():
    for testSuite in All_Test_Suite:
        print '[TestSuite] %s' % (testSuite.name)
        listAllTestCasesOf(testSuite.name)         

def runSingleTestSuite(name):
    if name in map(str,range(0,4)):
        if int(name)<=All_Test_Suite.__len__():
            All_Test_Suite[int(name)].execute()
            return 
    for testSuite in All_Test_Suite:
        if testSuite.name == name:
            testSuite.execute()
            break;
    
#def runAllTestSuite():
#    runner = unittest.TextTestRunner()
#    runner = lib.HTMLTestRunner(stream='TestReport.html',title="Test Result",description='Test Suite') 
#    testsuite = unittest.TestSuite()
#    for testSuite in All_Test_Suite:
#        for test in testSuite.test_list():
#            testsuite.addTest(test)
#    runner.run(testsuite)

#添加生成测试用例方法，只限于不关注测试用例顺序的测试集。
def generate_test_case(testCase):
    list=[]
    for i in dir(testCase):
        if i[:4]=='test':
            list.append(testCase(i))
    return list
        
def process_options():
    usage='''python testSuite.py [ -s <precheckin|regression|nightly>] | [-t <testcase1> [ -t <testcase2> ] | [ -l <all|suite|cases> ] 

-s --suite
    precheckin
        all defined precheckin test cases will be run
    regression 
        all defined regression test cases will be run
    nightly
        all defined nightly test cases will be run

-t, --testcase
    You can provide multiple -t options to run those test suites. 

-l, --list
    all
        all testsuite and testcases will be displayed
    suite
        only test suites will be listed
    cases
        only test cases will be listed

Example:
    imttests.py -s precheckin

Example:
    imttests.py -l all
    imttests.py -l suite

Example:
    imttests.py -t test_login_in_fangdd_on_android

'''
    parser = OptionParser(usage=usage) 
    parser.set_defaults(run_list=[])
    parser.add_option("-s","--suite",
                      action='store',
                      type='choice',
                      choices=['preCheckInTestSuite','preCheckInTestSuite2','nightlyTestSuite','restPreCheckInTestSuite','all' ]+map(str, range(0,4) ) ,
                      #choices=['preCheckInTestSuite','preCheckInTestSuite2','nightlyTestSuite','restPreCheckInTestSuite','all' ]+['test' ],
                      dest="suite_type",
                      help="type of test you want to run")
    parser.add_option("-l", "--list",
                      action='store',
                      type='choice',
                      choices=['all','suite','cases'],
                      dest="list_option",
                      help="show test suite and/or test cases accordingly")
    (options, args) = parser.parse_args()
    return (options, args)          

if __name__ == '__main__':
    options, args = process_options()
    if options.list_option != None:
        if options.list_option == 'all':
            listAllTestCasesAndSuit()
        elif options.list_option == 'suite':
            listAllTestSuite()
    elif options.suite_type != None:
        runSingleTestSuite(options.suite_type)
        
    #suite=unittest.TestSuite()
    #suite.addTest(Fangdd('test_login_in_fangdd_on_android'))
    #suite.addTest(Fangdd('test_click_second_hand_house'))    
    #runner = unittest.TextTestRunner()
    #runner.run(suite)