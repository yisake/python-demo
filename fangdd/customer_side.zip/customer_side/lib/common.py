#coding:utf-8
import logging 
import subprocess
import os
import sys
import time
import json
import collections

def clean_app_cache(deviceName,packageName):
    return exec_local('adb -s ' + deviceName + ' shell pm clear '+packageName)
    
def exec_local(cmd, pflag=True):
    ''' Execute command on local client and return code,out,err tuple '''
    logging.info(cmd)
    ps = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    ps.wait()
    (out, err) = ps.communicate()
    '''if pflat is set,logging the standard output or error output'''
    if pflag: 
        if  ps.returncode==0:
            logging.debug(out)
            logging.debug(err)
        else:
            logging.warning(out)
            logging.warning(err)
    return (ps.returncode, out, err)
    
def scriptsPath():
    #根据os.path.abspath(sys.argv[0])获取执行脚本绝对路径
    path = os.path.abspath(os.path.join(sys.argv[0], os.path.pardir)).replace('\\','/')
    #加入运行单个脚本时，获取脚本绝对路径的问题。
    if path.count('logs')!=0:
        path=path[:path.find('logs')]
    elif path.count('testCase' ) !=0:
        path=path[:path.find('testCase')]
    else:
        pass
    return path

def get_pinyin(chars=u"你好吗"):
    scriptPath=scriptsPath()
    if scriptPath.count('logs')!=0:
        scriptPath=scriptPath[:-5]
    data_path=scriptPath+'/lib/Mandarin.dat'
    result = []
    pinYinDict ={}
    for line in open(data_path):
        k, v = line.split('\t')
        pinYinDict[k] = v
    splitter=''
    for char in chars:
        key = "%X" % ord(char)
        try:
            result.append(pinYinDict[key].split(" ")[0].strip()[:-1].lower())
        except:
            return False
    return splitter.join(result)    
    
def convert_json_to_test_case(filePath,test):
    fh=file(filePath)
    jsonString=json.load(fh,object_pairs_hook=collections.OrderedDict)
    content=''
    content+='''
import unittest
import os
import sys
import logging
import time
import lib
import traceback
import platform
sys.path.append('..')
sys.path.append('../..')
from collections import OrderedDict
'''
    for itemJsonString in jsonString:
        content+="class "+itemJsonString["class name"]+"("+itemJsonString["base class name"]+"):\r"
        content+="    "+"'''"+itemJsonString["class description"]+"'''\r"
        for itemFunctions in itemJsonString['functions']:
            content+='    def '+itemFunctions['test case name']+'(self):\r'
            content+="        '''"+itemFunctions['test case description']+"'''\r"
            for itemStep in itemFunctions['steps']:
                content+='        logging.info("'+itemStep['step_description']+'")\r'
                if test=='test' :
                    url= "'https://a.esf.fangdd.net:60006'+"+itemStep['url']
                elif test=='prePublish' : 
                    url= "'https://a.esf.fangdd.com.cn:443'+" +itemStep['url']
                content+='        self.'+itemStep['customer']+'.'+itemStep['method']+'('+url+','+itemStep['parameters']+')\r'
            content+='        self.CheckTestResultFlag()\r'

    #import codecs 
    #a=codecs.open('./test.txt','w',encoding='utf-8')
    #a.write(content)
    #a.close() 
    #print content
    return content


def wait(max_count):
    """重复执行某个函数的装饰器"""
    def deco(func):
        def warpper(*args, **kwargs):
            count = 0
            while count < max_count:
                try:
                    result = func(*args, **kwargs)

                    # 如果函数返回的结果是一个空列表，则继续重试
                    if isinstance(result, (list, tuple, dict)) and len(result) == 0:
                        count += 1
                        logging.warning(u'空列表 重试 %s 次' % str(count))
                        time.sleep(1)
                        continue
                    return result

                # 如果函数异常，也继续重试
                except Exception as e:
                    count += 1
                    logging.warning(u'异常 重试 %s 次' % str(count))
                    time.sleep(1)
            return None

        return warpper

    return deco