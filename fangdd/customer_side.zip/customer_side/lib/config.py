#encoding=utf-8
import ConfigParser
import logging
import common
logger = logging.getLogger(__name__)

class Config(object):
    constant_id = 0
    default_file = "android.cfg"
  
    def __init__(self, conf_file=None):
        Config.constant_id += 1
        if conf_file != None:
            Config.default_file = conf_file    
        self.load_global_config()
    
    def load_global_config(self):
        self.app_root = common.scriptsPath()
        print 'Setting scriptsPath to:',self.app_root
        
        GLOBAL_CONF = self.app_root + '/config/' + Config.default_file
        
        if Config.default_file=='android.cfg':
            ####Load configuration
            conf = ConfigParser.SafeConfigParser()
            conf.read(GLOBAL_CONF)        
            ####Config sections       
            section = 'COMMON'
            self.std_log_level = conf.get(section, 'STD_LOG_LEVEL')
            
            section = 'ANDROID'
            #self.android_test_version=conf.get(section,'ANDROID_TEST_VERSION')#+ str(Config.constant_id)
            
            section='APPIUM'
            self.test_env=conf.get(section,'TEST_ENV')
            self.appium_path=conf.get(section,'APPIUM_PATH')
            self.device_name=conf.get(section,'DEVICE_NAME')
            self.platform_version=conf.get(section,'PLATFORM_VERSION')
            self.server_port=conf.get(section,'SERVER_PORT')
            self.apk_path=conf.get(section,'APK_PATH')
            
            section = 'MYSQL'
            self.mysql_env = conf.get(section,'MYSQL_ENV')
            #self.mysql_server_ip = conf.get(section,'MYSQL_SERVER_IP')
            #self.mysql_server_port = conf.getint(section,'MYSQL_SERVER_PORT')
            #self.mysql_default_db =  conf.get(section,'MYSQL_DEFAULT_DB')
            #self.mysql_user_name = conf.get(section,'MYSQL_USER_NAME')
            #self.mysql_password =  conf.get(section,'MYSQL_PASSWORD')
            
        elif 'rest.cfg':
            conf = ConfigParser.SafeConfigParser()
            conf.read(GLOBAL_CONF)
            section = 'COMMON'
            self.std_log_level = conf.get(section, 'STD_LOG_LEVEL')
            section = 'TEST_ENV'
            self.test_env = conf.get(section,'TEST_ENV')
            section = 'BUYER'
            self.buyer_mobile = conf.get(section,'BUYER_MOBILE')
            self.buyer_password = conf.get(section,'BUYER_PASSWORD')
            self.buyer_app_version = conf.get(section,'APP_VERSION')
            self.buyer_device_version = conf.get(section,'DEVICE_VERSION')
            self.buyer_device_type = conf.get(section,'DEVICE_TYPE')
            self.buyer_device_name = conf.get(section,'DEVICE_NAME')
            section = 'SELLER'
            self.seller_mobile = conf.get(section,'SELLER_MOBILE')
            self.seller_password = conf.get(section,'SELLER_PASSWORD')
            self.seller_app_version = conf.get(section,'APP_VERSION')
            self.seller_device_version = conf.get(section,'DEVICE_VERSION')
            self.seller_device_type = conf.get(section,'DEVICE_TYPE')
            self.seller_device_name = conf.get(section,'DEVICE_NAME')
        else:
            raise Exception('File Exception','the file do not exists')
        
    def print_global_config(self):
        logging.basicConfig(level=self.log_level)
        logger.debug('  %-20s= %s' % ('Android test version', self.android_test_version))
