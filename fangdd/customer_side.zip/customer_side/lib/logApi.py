import logging
import os

def setUpLoggingInterface(log_path, log_name, log_level):
    if not os.access(log_path, os.F_OK):
        os.makedirs(log_path)
    common_log = '%s/%s.log' % (log_path, log_name)
    result_log = '%s/imt_result.log' % (log_path)
    removeAllLogHandler()  
    setUpStdoutLoggingHandler(log_level)
    setUpFileLoggingHandler(common_log, logging.DEBUG)
    setUpResultLoggingHandler(result_log, logging.FATAL)
    logging.info('Set up logging interface finish')
    
    
def removeAllLogHandler():
    while len(logging.root.handlers) > 0:
        logging.root.removeHandler(logging.root.handlers[-1])
        
def setUpStdoutLoggingHandler(log_level):
    logging.root.setLevel(logging.DEBUG)
    fh = logging.StreamHandler()
    fmt = logging.Formatter(fmt='%(asctime)s %(levelname)-5s - %(message)s'
                            , datefmt='%m/%d/%Y %H:%M:%S')
    fh.setFormatter(fmt)
    fh.setLevel(log_level)
    logging.root.addHandler(fh)
    
def setUpFileLoggingHandler(log_file, log_level):
    # add file logger
    fh = logging.FileHandler(filename=log_file, mode='w')
    fmt = logging.Formatter(fmt='%(asctime)s %(levelname)-5s - %(message)s'
                            , datefmt='%m/%d/%Y %H:%M:%S')
    fh.setFormatter(fmt)
    # force file handler to output debug level log
    fh.setLevel(logging.DEBUG)
    logging.root.addHandler(fh)
    
def setUpResultLoggingHandler(log_file, log_level):
    # add result file logger which only record > WARNING
    fh = logging.FileHandler(filename=log_file, mode='a')
    fmt = logging.Formatter(fmt='%(asctime)s - %(message)s'
                            , datefmt='%m/%d/%Y %H:%M:%S')
    fh.setFormatter(fmt)
    fh.setLevel(log_level)
    logging.root.addHandler(fh)