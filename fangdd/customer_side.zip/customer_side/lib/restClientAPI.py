#coding=utf8
import requests
import time
import logging
import hmac
import hashlib
import re
import codecs
import json

class restClient(object):
    def __init__(self,ip,port,mobile,passWord,deviceType='iOS', appVersion='6.5.0', interfaceLog='', userId='', token='', userName='', logFlag=True ):
        '''初始化一些RestClient的类变量。
        self.url
        self.mobile
        self.password
        self.headers
        self.userId
        self.token
        self.userName
        logFlag 是否记录（GET POST PUT DELETE）请求的log
        '''
        self.session=requests.Session()
        self.url='https://'+ip+':'+port+'/'
        self.mobile=mobile
        self.passWord=passWord
        timestamp = str(int(time.time()))
        self.headers={'User-Id': '0', 
                      'Timestamp' : timestamp, 
                      'Content-Type':'application/json' ,
                      'Device-Type' : deviceType,
                      'App-Version' : appVersion,                      
        }
        self.logFlag=logFlag
        
        if interfaceLog=='':
            self.interfaceLog=None
        else:
            self.interfaceLog=codecs.open(interfaceLog,'w',encoding='utf-8' )
            
        if userId=='' or token=='' or userName=='' :
            return
        else:
            self.headers={'User-Id':userId,'Token':token}
            self.userId=userId
            self.token=token
            self.userName=userName
    
    def login_in(self):
        timestamp = str(int(time.time()))
        body = {"is_auth_login": 0, "password": self.passWord, "mobile": self.mobile}        
        (response,jsonCode)=self.post(self.url+'users/login',dictBody=body, verify=False)
        self.userId=str(jsonCode['data']['user_id'])
        self.token=jsonCode['data']['token']
        self.userName=jsonCode['data']['username']
        self.headers['User-Id']=self.userId
        self.headers['Timestamp']=timestamp
        self.headers['Token']=self.token
        self.headers['Device-Type']='android'
        self.headers['Content-Type']='application/json'
        return response,jsonCode
    
    def log_out(self):
        return self.post(self.url+'users/logout',verify=False)        
        
    def get_auth_code(self):
        '''获取验证码'''
        body = {'mobile':self.mobile,'type':'login' }
        return self.post(self.url+'users/auth_code',dictBody=body, verify=False)
    
    def get_voice_auth_code(self):
        '''获取语音验证码'''
        body = {'mobile':self.mobile,'type':'login' }
        return self.post(self.url+'users/voice_auth_code',dictBody=body, verify=False)
    
    def get_user_profile(self):
        '''获取个人信息'''
        return self.get(self.url+'users/profile', verify=False)        
    
    def modify_user_profile(self):
        '''修改个人信息'''
        body = {'mobile':self.mobile}
        return self.put(self.url+'users/profile',data=body, verify=False)        
    
    def filter_house(self,city_id='121',From='0',house_price='350-850',lat='31.284094',lng='121.446309'):
        return self.get(self.url+'search?city_id='+city_id)
        
    def modify_user_password(self,newPassword,oldPassword=''):
        '''根据老密码修改新密码'''
        if oldPassword=='':
            oldPassword=self.passWord
        body = {'mobile':self.mobile,'old_password':oldPassword,'password':newPassword}
        return self.put(self.url+'users/password',data=body, verify=False)
    
    def modify_user_password_by_auth_code(self,newPassword,auth_code='111111'):
        '''根据验证码修改新密码'''
        body = {'mobile':self.mobile,'auth_code':auth_code,'password':newPassword}
        return self.put(self.url+'users/forget_password',data=body, verify=False)
    
    def check_current_mobile(self):
        '''验证当前手机'''
        body = {'mobile':self.mobile,'auth_code':self.passWord}
        return self.post(self.url+'users/check_old_mobile',dictBody=body, verify=False)
    
    def modify_mobile_phone(self,old_mobile,old_auth_code,new_mobile,new_auth_code):     
        '''修改手机号'''
        body = {'old_mobile':old_mobile,'old_auth_code':old_auth_code,'new_mobile':new_mobile,'new_auth_code':new_auth_code}
        return self.put(self.url+'users/mobile',dictBody=body, verify=False)
    
    def get_message_list(self,page_size,page_index):
        '''消息列表&'''
        return self.get(self.url+'users/messages?page_size='+page_size+'&page_index='+page_index,verify=False)        
    
    def get_message(self,messageId):
        '''获取消息&'''
        return self.get(self.url+'users/messages/'+messageId,verify=False)
    
    def get_unread_message_number(self):
        '''未读消息总数'''
        return self.get(self.url+'users/unread', verify=False)
    
    def set_password(self,password):
        '''设置密码'''
        body = {'mobile':self.mobile,'password':password }
        return self.post(self.url+'/users/password',dictBody=body, verify=False)
        
    def upload_device_info(self):
        '''上传设备信息'''
        #body = {'event':1,'password':cId,'city_id':121,'city_name':u'上海','cert_name':'ershoufang_dev'}
        #return self.put(self.url+'users/device',data=body, verify=False)
                        
    def attention_house_source(self,house_id):
        '''关注房源'''
        body = {'house_id':house_id}
        return self.post(self.url+'users/collects',dictBody=body, verify=False)        
    
    def cancel_attention_house_souce(self,house_id):
        '''取消关注房源'''
        return self.delete(self.url+'users/collects/'+house_id, verify=False)        
    
    def get_attention_house_source_list(self,page_size,page_index):   
        '''获取关注房源列表'''
        return self.get(self.url+'users/collects?page_size='+page_size+'&page_index='+page_index, verify=False)        
     
    def get_supported_city_list(self):
        '''获取支持的城市列表'''
        return self.get(self.url+'meta/cities', verify=False)        
    
    def get_all_house_source_filter_conditions_menu(self,city_id):
        '''获取所有的房源筛选条件菜单'''
        '/meta/full-menus?city_id='+city_id
         
    def get_house_source_menu(self):
        '''获取房源筛选条件菜单'''
        return self.get(self.url+'meta/menus', verify=False)         
    
    def get_recent_reduce_price_house_source(self,city_id):
        '''获取最近降价房源列表'''
        return self.get('/search/price_cut?city_id='+city_id, verify=False)
    
    def get_search_hints(self):
        '''搜索提示'''
        pass
    
    def get_house_source_detail_page(self,houseId):
        '''房源详情页'''
        #return self.get(self.url+'houses/'+houseId,dictBody=body, verify=False)
    
    def get_house_source_basic_info(self,houseId):
        '''房源基础信息'''
        #return self.get(self.url+'houses/simple/'+houseId,dictBody=body, verify=False)
    
    def resverse_house_source(self,houseSourceId,startTime,endTime,name,gender):
        '''预约房源'''
        #return self.post(self.url+'/houses/'+houseSourceId+'/appoint',dictBody=body, verify=False)        
    
    def get_house_source_all_comments(self):
        '''查询房源所有评价'''
        #return self.get(self.url+'/houses/'+houseSourceId+'/appoint',dictBody=body, verify=False)        
    
    def cancel_reverse(self,appointment_id,reason):
        body={'appointment_id':appointment_id,'reason':reason}
        return self.post(self.url+'calendar/cancel',dictBody=body, verify=False)        
    
    def vefiry_reverse(self,appointment_id,agree='true'):
        body={'appointment_id':appointment_id,'agree':agree}
        return self.get(self.url+'calendar/agree',dictBody=body, verify=False)        
    
    def get_reverse_list(self,customerId,status,page_size,page_index):        
        '''获取预约列表'''
        body={'customerID':customerId,'status':status,'page_size':page_size,'page_index':page_index}
        return self.get(self.url+'calendar/list?customerID='+customerId+'&status='+status+'&page_size='+page_size+'&page_index='+page_index,dictBody=body, verify=False)
    
    def get_reverse_detail(self,appointmentId):
        '''获取预约详情'''
        body={'appointment_id':appointmentId}
        return self.get(self.url+'calendar/detail',dictBody=body, verify=False)
                    
    def push_reversvation(self,appointmentId):
        '''催约'''
        return self.get(self.url+'calendar/press?appointment_id='+str(appointmentId),verify=False)
        
    def get_hot_district(self,city_id):
        '''热门小区'''
        return self.get(self.url+'meta/hot_cells?city_id='+city_id, verify=False)
    
    def get_hotlines(self,city_id):
        '''热线电话'''
        return self.get(self.url+'meta/hot_lines', verify=False)               
    
    def get_banner(self,city_id):
        '''首页banner'''
        return self.get(self.url+'meta/banners', verify=False)         
    
    def get_advertisement(self,city_id):
        '''广告位'''
        return self.get(self.url+'meta/advertisement', verify=False)
    
    def get_popup_windows(self):
        '''弹出弹窗'''
        return self.get(self.url+'meta/advertisement', verify=False)
    
    def get_cell_basic_info(self,cell_id,city_id):
        '''获取小区基本信息'''
        return self.get(self.url+'cells/'+cell_id+'-'+city_id, verify=False)
        
    def get_cell_from_cell_name(self,city_id,key_word):
        '''根据小区名称搜索小区'''
        return self.get(self.url+'cells/search?city_id='+city_id+'&keyword='+key_word, verify=False)
    
    def talk_with_seller(self,customer_id,owner_id,house_id,timestamp,msg,):
        '''咨询业主'''
        body={'customer_id':customer_id,'owner_id':owner_id,'house_id':house_id,'timestamp':timestamp,'msg':msg,'type':type}
        return self.post(self.url+'meta/chat',dictBody=body, verify=False)        
    
    def send_invitation_code(self,invitation_code):
        '''邀请码验证'''
        body={'invitation_code':invitation_code}
        return self.post(self.url+'meta/invitation-code',dictBody=body, verify=False)        
    
    def group_send_agent(self,house_id,content):
        '''群发经纪人'''
        body={'house_id ':house_id,'content':content}
        return self.post(self.url+'owner/agent/groupsend',dictBody=body, verify=False)        
    
    def publish_house_source(self,):
        body={"cell_address":u"浦东金高路988弄","is_only":True,"agent_auto_through":0,"cell_id":"407","shi":"1","wei":"0","house_lng":"121.615753","on_floor":"2","ting":"0","cell_name":u"春江花悦园","expect_price":"111","year_type":2,"buyer_auto_through":0,"building_no":"2","area":"111","house_lat":"31.291983","owner_name":self.userName,"owner_phone":self.mobile,"room_no":"2","city_id":121,"has_loan":True,"owner_sex":0,"all_floor":"2","suggest_look_house_time":u"工作日白天，周末白天","owner_id":self.userId}
        return self.post(self.url+'owner/house',dictBody=body, verify=False)
        
    def edit_house_source(self,house_id,edit_type,**kargs):
        '''编辑房源'''        
        body={"house_id":house_id,"edit_type":edit_type}
        if kargs.has_key('kargs'):
            dict2=kargs['kargs']
            body=dict(body,**dict2)
        return self.put(self.url+'owner/house',data=body, verify=False)
    
    def delete_house_source(self,house_id):
        '''删除房源'''
        return self.delete(self.url+'owner/house/'+house_id,verify=False)        
        
    def on_line_house_source(self,house_id):
        '''上架房源'''
        body={"house_id":house_id,"status":"3"}
        return self.put(self.url+'owner/house/'+house_id+'/onoffline/3',data=body,verify=False)        
        
    def off_line_house_source(self,house_id):    
        '''下架房源'''
        body={"house_id":house_id,"status":"4"}
        return self.put(self.url+'owner/house/'+house_id+'/onoffline/4',data=body,verify=False)        
            
    def modify_house_price(self,house_id,price):
        '''修改房源价格'''
        body={"house_id":house_id,"price":price}
        return self.put(self.url+'owner/house/'+house_id+'/price/'+price,data=body,verify=False)        
    
    def get_ownver_house(self):
        '''获取业主发房源信息'''
        return self.get(self.url+'owner/house/list',verify=False)
    
    def reverse_house_source(self,body={"house_id":524727,"appointment_people_name": u"皇甫","appointment_people_gender":1,"match_appointment_time_period":1}):
        '''发起预约3.5'''        
        return self.post(self.url+'appointments/',verify=False,dictBody=body)
    
    def same_type_house_source_reverse(self,appointment_id,house_ids):
        '''同类型房源批量预约,house_ids是list'''
        body={"appointment_id":appointment_id,"house_ids":house_ids}
        return self.post(self.url+'appointments/batch',verify=False,dictBody=body)
    
    def buyer_get_reserve_list(self,status,page_index='00',page_size='10'):
        '''买家获取预约列表'''
        return self.get(self.url+'appointments/list?status='+status+'&page_index='+page_index+'&page_size='+page_size)
    
    def buyer_get_reserve_deail(self,appointmentid):
        '''买家获取预约详情'''
        return self.get(self.url+'appointments/'+str(appointmentid),verify=False)
    
    def seller_get_reserve_list(self,house_id='524512',status='processing',page_index='00',page_size='10'):
        ''''卖家获取预约列表3.5'''
        return self.get(self.url+'appointments/owner/list?house_id='+house_id+'&status='+status+'&page_index='+page_index+'&page_size='+page_size,verify=False)
    
    def seller_get_reserve_detail(self,appointmentid):
        '''卖家获取预约详情页5.6'''
        return self.get(self.url+'appointments/owner/'+str(appointmentid))
    
    def seller_handle_reservation(self,appointmentid,attitude,appoint_type,disagree_reason,disagree_reason_type):
        '''卖家同意5.3'''
        body={"appointmentid":appointmentid,"attitude":attitude,"appoint_type":appoint_type,"disagree_reason":disagree_reason,"disagree_reason_type":disagree_reason_type}
        return self.post(self.url+'appointments/'+str(appointmentid)+'/owner_agree',verify=False,dictBody=body)
    
    def cancel_reservation(self,appointmentid):
        '''取消预约3.5(5.3版本以前用)'''
        return self.post(self.url)
    
    def cancel2_reservation(self,appointmentid,cancel_reason='test',cancel_reason_type=0):
        '''取消预约3.5(5.3版本开始用)'''
        body={"appointmentid":appointmentid,"cancel_reason":cancel_reason,"cancel_reason_type":cancel_reason_type}
        return  self.post(self.url+'appointments/'+str(appointmentid)+'/cancel2',verify=False,dictBody=body)
    
    def confirm_to_see(self,appointmentid,appoint_type=1,star=2,**kargs):
        '''确认待看'''        
        body={"appointmentid":appointmentid,"appoint_type":appoint_type,"start":star}
        if kargs.has_key('kargs'):
            dict2=kargs['kargs']
            body=dict(body,**dict2)
        return self.post(self.url+'appointments/'+str(appointmentid)+'/comment',)
        
    def buyer_remove_reservation(self,appointmentid):
        '''买家删除预约单'''
        return self.delete(self.url+'appointments/'+str(appointmentid)+'/customer')
    
    def seller_remove_reservation(self,appointmentid):
        '''卖家删除预约单'''
        return self.delete(self.url+'appointments/'+str(appointmentid)+'/owner')
        
    def get(self,url,verify=False,headers=None,filterCode=(True,''),params=None):
        if headers:
            self.headers.update(headers)
        user_id = self.headers.get('User-Id', '')
        token = self.headers.get('Token', '')
        timestamp = self.headers.get('Timestamp', '')
        if params:
            response=requests.get(url,verify=verify, headers=self.headers,params=params)
            params_url=response.url
            m = re.match(r'^(https|http)://([0-9a-zA-Z:\.]*)([0-9a-zA-Z/_\-?=%&.]*)', params_url)
        else:
            m = re.match(r'^(https|http)://([0-9a-zA-Z:\.]*)([0-9a-zA-Z/_\-?=%&.]*)', url)
        url_postfix = m.group(3)
        #print url_postfix
        method = 'GET'
        body=''
        access_id = 'N4D76QBF7U941Q5RROWIv63'
        key = 'HwKLTq1lok6xBK0fMgMAztoKTIHC0AO037xJMkaJ'
        to_sign = ''.join([access_id.strip(), user_id.strip(), token.strip(), timestamp.strip(), method.strip(), url_postfix.strip(), body.strip()])
        sign = hmac.new(key, to_sign, hashlib.sha1).hexdigest().encode('base64').rstrip()
        self.headers['Sign'] = sign
        if params:
            response=self.session.get(url,verify=verify, headers=self.headers,params=params)
        else:
            response=self.session.get(url,verify=verify, headers=self.headers)
        if self.logFlag:
            if response.status_code==200:
                logging.info('##################################################################')
                logging.info('GET URL:'+url)
                logging.info('Request Headers:'+str(self.headers))
                logging.info('User id:'+user_id+' Token:'+token)
                logging.info('Status code:'+str(response.status_code))
                logging.info('Response:'+response.text)
                #logging.info('Encoding:'+response.encoding)
                logging.info('Headers:',response.headers)
                self.write_log(response,url,filterCode)
                logging.info('--------------------------------    ----------------------------------')
                return (response,response.json())
            else:
                logging.debug('##################################################################')
                logging.debug('GET URL:'+url)
                logging.debug('Request Headers:'+str(self.headers))
                logging.debug('User id:'+user_id+' Token:'+token)
                logging.debug('Status code:'+str(response.status_code))
                logging.debug('Response:'+response.text)
                #logging.debug('Encoding:'+response.encoding)
                logging.debug('Headers:',response.headers)
                self.write_log(response,url,filterCode)
                logging.info('------------------------------------------------------------------')            
                return (response,response.json())
        else:
            return (response,response.json())
    
    def post(self,url, dictBody={}, verify=False, headers=None,filterCode=(True,'')):
        user_id = self.headers.get('User-Id', '')
        token = self.headers.get('Token', '')
        timestamp = self.headers.get('Timestamp', '')
        m = re.match(r'^(https|http)://([0-9a-zA-Z:\.]*)([0-9a-zA-Z/_\-?=&]*)', url)
        url_postfix = m.group(3)
        body = ''
        for key, value in dictBody.items():
            if isinstance(value, basestring):
                value = '"%s"' % value
            elif isinstance(value, bool):
                value = str(value).lower()
            body += '"%s": %s, ' % (key, value)
        body = '{%s}' % body[:-2]
        method = 'POST'
        access_id = 'N4D76QBF7U941Q5RROWIv63'
        key = 'HwKLTq1lok6xBK0fMgMAztoKTIHC0AO037xJMkaJ'
        to_sign = ''.join([access_id.strip(), user_id.strip(), token.strip(), timestamp.strip(), method.strip(), url_postfix.strip(), body.strip()])
        if isinstance(to_sign, unicode):
            to_sign = repr(to_sign)[2:-1]
        sign = hmac.new(key, to_sign, hashlib.sha1).hexdigest().encode('base64').rstrip()
        self.headers['Sign'] = sign
        response=self.session.post(url, json=dictBody, verify=verify, headers=self.headers)
        if self.logFlag:
            if response.status_code==200:
                logging.info('##################################################################')
                logging.info('POST URL:'+url)
                logging.info('Request Headers:'+str(self.headers))
                logging.info('Request Body:'+body)
                logging.info('User id:'+user_id+' Token:'+token)
                logging.info('Status code:'+str(response.status_code))
                logging.info('Response:'+response.text)
                #logging.info('Encoding:'+response.encoding)
                logging.info('Headers:',response.headers)
                self.write_log(response,url,filterCode)
                logging.info('------------------------------------------------------------------')
                return (response,response.json())
            else:
                logging.debug('##################################################################')
                logging.debug('POST URL:'+url)
                logging.debug('Request Headers:'+str(self.headers))
                logging.debug('Request Body:'+body)            
                logging.debug('User id:'+user_id+' Token:'+token)
                logging.debug('Status code:'+str(response.status_code))
                logging.debug('Response:'+response.text)
                #logging.debug('Encoding:'+response.encoding)
                logging.debug('Headers:',response.headers)
                self.write_log(response,url,filterCode)
                logging.info('------------------------------------------------------------------')            
                return (response,response.json())
        else:
            return (response,response.json())                
    
    def put(self,url,data='',verify=False, headers=None,filterCode=(True,'' )):
        user_id = self.headers.get('User-Id', '')
        token = self.headers.get('Token', '')
        timestamp = self.headers.get('Timestamp', '')
        m = re.match(r'^(https|http)://([0-9a-zA-Z:\.]*)([0-9a-zA-Z/_\-?=&]*)', url)
        url_postfix = m.group(3)
        method = 'PUT'
        body=''
        if data=='':
            body=data
        else:
            for key, value in data.items():
                if isinstance(value, basestring):
                    value = '"%s"' % value
                elif isinstance(value, bool):
                    value = str(value).lower()
                body += '"%s": %s, ' % (key, value)
        body = '{%s}' % body[:-2]
        access_id = 'N4D76QBF7U941Q5RROWIv63'
        key = 'HwKLTq1lok6xBK0fMgMAztoKTIHC0AO037xJMkaJ'
        to_sign = ''.join([access_id.strip(), user_id.strip(), token.strip(), timestamp.strip(), method.strip(), url_postfix.strip(), body.strip()])
        if isinstance(to_sign, unicode):
            to_sign = repr(to_sign)[2:-1]        
        sign = hmac.new(key, to_sign, hashlib.sha1).hexdigest().encode('base64').rstrip()
        self.headers['Sign'] = sign
        if data=='':
            response=self.session.put(url,verify=verify, headers=self.headers)
        else:    
            response=self.session.put(url,data=json.dumps(data),verify=verify,headers=self.headers)
        if self.logFlag:        
            if response.status_code==200:
                logging.info('##################################################################')
                logging.info('PUT URL:'+url)
                logging.info('Request Headers:'+str(self.headers))
                logging.info('Request Body:'+body)
                logging.info('User id:'+user_id+' Token:'+token)
                logging.info('Status code:'+str(response.status_code))
                logging.info('Response:'+response.text)
                #logging.info('Encoding:'+response.encoding)
                logging.info('Headers:'+str(response.headers))
                self.write_log(response,url,filterCode)
                logging.info('------------------------------------------------------------------')            
                return (response,response.json())
            else:
                logging.debug('##################################################################')
                logging.debug('PUT URL:'+url)
                logging.debug('Request Headers:'+str(self.headers))
                logging.debug('Request Body:'+body)
                logging.debug('User id:'+user_id+' Token:'+token)
                logging.debug('Status code:'+str(response.status_code))
                logging.debug('Response:'+response.text)
                #logging.debug('Encoding:'+response.encoding)
                logging.debug('Headers:'+str(response.headers))
                self.write_log(response,url,filterCode)
                logging.info('------------------------------------------------------------------')                       
                return (response,response.json())
        else:
            return (response,response.json())                
        
    def delete(self,url,verify=False, headers=None,filterCode=(True,'')):    
        user_id = self.headers.get('User-Id', '')
        token = self.headers.get('Token', '')
        timestamp = self.headers.get('Timestamp', '')
        m = re.match(r'^(https|http)://([0-9a-zA-Z:\.]*)([0-9a-zA-Z/_\-?=&]*)', url)
        url_postfix = m.group(3)
        method = 'DELETE'
        body=''
        access_id = 'N4D76QBF7U941Q5RROWIv63'
        key = 'HwKLTq1lok6xBK0fMgMAztoKTIHC0AO037xJMkaJ'
        to_sign = ''.join([access_id.strip(), user_id.strip(), token.strip(), timestamp.strip(), method.strip(), url_postfix.strip(), body.strip()])
        if isinstance(to_sign, unicode):
            to_sign = repr(to_sign)[2:-1]        
        sign = hmac.new(key, to_sign, hashlib.sha1).hexdigest().encode('base64').rstrip()
        self.headers['Sign'] = sign
        response=self.session.delete(url,verify=verify, headers=self.headers)
        if self.logFlag:        
            if response.status_code==200:
                logging.info('##################################################################')
                logging.info('DELETE URL:'+url)
                logging.info('Request Headers:'+str(self.headers))
                logging.info('User id:'+user_id+' Token:'+token)
                logging.info('Status code:'+str(response.status_code))
                logging.info('Response:'+response.text)
                #logging.info('Encoding:'+response.encoding)
                logging.info('Headers:'+str(response.headers))
                self.write_log(response,url,filterCode)
                logging.info('------------------------------------------------------------------')                      
                return (response,response.json())
            else:
                logging.debug('##################################################################')
                logging.debug('DELETE URL:'+url)
                logging.debug('Request Headers:'+str(self.headers))
                logging.debug('User id:'+user_id+' Token:'+token)
                logging.debug('Status code:'+str(response.status_code))
                logging.debug('Response:'+response.text)
                #logging.debug('Encoding:'+response.encoding)
                logging.debug('Headers:'+str(response.headers))
                self.write_log(response,url,filterCode)
                logging.info('------------------------------------------------------------------')            
                return (response,response.json()) 
        else:
            return (response,response.json())             
    
    def write_log(self,response,url,filterCode=(True,'')):
        '''filterCode为空，只判断msg字段'''
        if self.interfaceLog==None:
            return
        #判断msg和code
        if response.json()['msg']!='success':
            raise AssertionError('Response msg:',response.json()['msg'])
        if response.json()['code']!='00000':
            raise AssertionError('Response code:',response.json()['code'])
        logging.info('Checking json code ["msg"],["code"] successfully!')
        #判断是否需要记录,只判断msg和code，不记录log。
        if filterCode=='':
            return
        if filterCode[0]==True:#filterCode为元祖，第一个字段为True，过滤掉后面的字段            
            if filterCode[1]=='':#当为空字符串的时候，保存全部log
                dictCode=response.json()
                if response.headers.__contains__('Date'):
                    del response.headers['Date']
                self.interfaceLog.write('GET URL:'+url+'\r')
                self.interfaceLog.write('Status code:'+str(response.status_code)+'\r')
                self.interfaceLog.write('Response:'+str(dictCode)+'\r')
                self.interfaceLog.write('Headers:'+str(response.headers)+'\r')
                self.interfaceLog.flush()
            else:
                dictCode=response.json()
                if response.headers.__contains__('Date'):
                    del response.headers['Date']
                del dictCode['data'][filterCode[1]]
                self.interfaceLog.write('GET URL:'+url+'\r')
                self.interfaceLog.write('Status code:'+str(response.status_code)+'\r')
                self.interfaceLog.write('Response:'+str(dictCode)+'\r')
                self.interfaceLog.write('Headers:'+str(response.headers)+'\r')
                self.interfaceLog.flush()
        else:#filterCode为元祖，第一个字段为False，只保存相应的字段
            dictCode=response.json()
            del response.headers['Date']            
            self.interfaceLog.write('GET URL:'+url+'\r')
            self.interfaceLog.write('Status code:'+str(response.status_code)+'\r')
            self.interfaceLog.write('Response:'+dictCode['data'][filterCode[1]]+'\r')
            self.interfaceLog.write('Headers:'+str(response.headers)+'\r')
            self.interfaceLog.flush()

            
#a=restClient('a.esf.fangdd.net','60006','18300000001','123456')
#a.login_in()
#payload={'city_id':'121','lat':'31.284094','lng':'121.446309','from':'0','room':'2'}
#response,content= a.get(a.url+'search',verify=False,params=payload)
