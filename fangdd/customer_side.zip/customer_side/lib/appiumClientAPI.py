# coding=utf8

import logging
import common
import appium
import time
try:
    import airtest
    use_airtest = True
except Exception, e:
    use_airtest = False


class SecondHandHouseSource(object):
    '''
    houseName 房源名字
    houseLayout 房源布局
    houseArea 房源面积
    houseResNum 房源预约次数
    housePrice 房源总价
    houseUnivalentPrice 房源单价（每平米多少价格）
    houseLabel 房源标签
    houseDistance 房源距离地铁距离
    #ownerSpeak 业主评价
    newHouseTag 新房
    saleHouseTag 降价房源
    #hotHouseTag 热卖房源
    '''
    def __init__(self,houseName,houseLayout,houseArea,houseResNum,housePrice,unitPrice,houseLabel='',houseDistance='',newHouseTag=False,saleHouseTag=False,actualTag=False):
        self.houseName=houseName
        self.houseLayout=houseLayout
        self.houseArea=houseArea
        self.houseResNum=houseResNum
        self.housePrice=housePrice
        self.unitPrice=unitPrice
        self.houseLabel=houseLabel
        self.houseDistance=houseDistance
        self.newHouseTag=newHouseTag
        self.saleHouseTag=saleHouseTag
        self.actualTag=actualTag

class SecondHandHouseSourceElement(object):
    '''
    houseName 房源名字
    houseLayout 房源布局
    houseArea 房源面积
    houseResNum 房源预约次数
    housePrice 房源总价
    houseUnivalentPrice 房源单价（每平米多少价格）
    houseLabel 房源标签
    houseDistance 房源距离地铁距离
    #ownerSpeak 业主评价
    newHouseTag 新房
    saleHouseTag 降价房源
    #hotHouseTag 热卖房源
    '''
    def __init__(self,houseName,houseLayout,houseArea,houseResNum,housePrice,unitPrice,houseLabel='',houseDistance='',newHouseTag=False,saleHouseTag=False,actualTag=False):
        self.houseName=houseName
        self.houseLayout=houseLayout
        self.houseArea=houseArea
        self.houseResNum=houseResNum
        self.housePrice=housePrice
        self.unitPrice=unitPrice
        self.houseLabel=houseLabel
        self.houseDistance=houseDistance
        self.newHouseTag=newHouseTag
        self.saleHouseTag=saleHouseTag
        self.actualTag=actualTag

class ReserveHouseSource(object):
    def __init__(self,reverseState,houseName,houseLayout,housePrice,ownerButton,message,call,buy):
        '''
        reverseState 预约状态
        houseName 小区名字
        houseLayout 房源布局
        housePrice 房源价格
        ownerButton 评价业主
        message 留言
        call 致电
        buy 我想买TA
        '''
        self.reverseState=reverseState
        self.houseName=houseName
        self.houseLayout=houseLayout
        self.housePrice=housePrice
        self.ownerButton=ownerButton
        self.message=message
        self.call=call
        self.buy=buy

class AppiumApi(object):
    def __init__(self, desired_caps, host='localhost', server_port='4723'):
        self.platformVersion = desired_caps['platformVersion']
        self.driver = appium.webdriver.Remote('http://' + host + ':' + server_port + '/wd/hub', desired_caps)
        self.get_window_size()
    
        if use_airtest:
            self._init_air_test_client(desired_caps['platformName'], desired_caps['deviceName'])
        
    def _init_air_test_client(self,system='android',deviceName=''):
        self.device=airtest.Device(system+'://'+deviceName)
        self.app=airtest.connect(system+'://'+deviceName,device='android',monitor=False,logfile=False)
        self.app.globalSet(image_match_method='template')
        self.app.globalSet(threshold=0.9)
        self.app.globalSet(snapshot_method='screencap')
        if (self.windowSize['width'],self.windowSize['height'])!=(1080,1920):
            logging.info('System screen_resolution is:'+str(self.windowSize['width'])+'*'+str(self.windowSize['height']))
            logging.info('Setting the screen_resolution to 1080*1920')
            self.app.globalSet(screen_resolution=(1080,1920))
    
    def click_the_enter_button(self):
        for item in self.driver.find_elements_by_class_name('android.widget.ImageView'):
            if item.get_attribute('clickable')==u'true':
                item.click()
                return True
        return False
    
    def click_back_image(self):
        ele=self.driver.find_element_by_class_name('android.widget.ImageView').click()
    
    def click_by_id(self,element,timeOut=5):
        ele=self.wait_by_id(element,timeOut)
        time.sleep(1)
        ele.click()
        return True
        
    def click_by_name(self,element,timeOut=5):
        ele=self.wait_by_name(element,timeOut)
        time.sleep(1)
        ele.click()      
        return True
    
    def click_by_class(self,element,timeOut=5):
        ele=self.wait_by_class(element,timeOut)
        time.sleep(1)
        ele.click()
        return True
    
    def click_by_class_index(self, element, index, timeout=1):
        """根据class name查找元素列表后，点击其中第index个元素"""
        ele_list = self.wait_by_class_list(element)
        time.sleep(timeout)
        ele_list[index].click()
        return True
    
    def click_by_image(self, image, timeout=1):
        """根据image查找元素后，点击该元素"""
        location = self.app.wait(image)
        time.sleep(timeout)
        self.app.click(location)
        return True
    
    #比较房源列表总价高低
    def compareHousePrice(self,houseList,method):
        result=0
        i=0
        while i<len(houseList)-1:
            if method=='up':
                if float(houseList[i].housePrice)<=float(houseList[i+1].housePrice):
                    result+=1
            if method=='down':
                if float(houseList[i].housePrice)>=float(houseList[i+1].housePrice):
                    result+=1             
            i+=1
        if result==len(houseList)-1:
            return True
        else:
            return False          
            
    #比较房源列表单价高低
    def compareUnitPirce(self,houseList,method):
        result=0
        i=0
        while i<len(houseList)-1:
            if method=='up':
                if int(houseList[i].unitPrice[:houseList[i].unitPrice.find(u'\u5143/\u5e73\u7c73')])<=int(houseList[i+1].unitPrice[:houseList[i+1].unitPrice.find(u'\u5143/\u5e73\u7c73')]):
                    result+=1
            if method=='down':
                if int(houseList[i].unitPrice[:houseList[i].unitPrice.find(u'\u5143/\u5e73\u7c73')])>=int(houseList[i+1].unitPrice[:houseList[i+1].unitPrice.find(u'\u5143/\u5e73\u7c73')]):
                    result+=1             
            i+=1
        if result==len(houseList)-1:
            return True
        else:
            return False
    
    #比较房源列表面积大小
    def compareHouseArea(self,houseList,method):
        result=0
        i=0
        while i<len(houseList)-1:
            if method=='up':
                if float(houseList[i].houseArea[:houseList[i].houseArea.find(u'\u5e73')])<=float(houseList[i].houseArea[:houseList[i].houseArea.find(u'\u5e73')]):
                    result+=1
            if method=='down':
                if float(houseList[i].houseArea[:houseList[i].houseArea.find(u'\u5e73')])>=float(houseList[i].houseArea[:houseList[i].houseArea.find(u'\u5e73')]):
                    result+=1             
            i+=1
        if result==len(houseList)-1:
            return True
        else:
            return False
    
    #比较房源列表页根据预约人数排序
    def compareResNum(self,houseList,method):
        result=0
        i=0
        while i<len(houseList)-1:
            if method=='up':
                if int(houseList[i].houseResNum[:houseList[i].houseResNum.find(u'\u4eba')])<=int(houseList[i+1].houseResNum[:houseList[i+1].houseResNum.find(u'\u4eba')]):
                    result+=1
            if method=='down':
                if int(houseList[i].houseResNum[:houseList[i].houseResNum.find(u'\u4eba')])>=int(houseList[i+1].houseResNum[:houseList[i+1].houseResNum.find(u'\u4eba')]):
                    result+=1             
            i+=1
        if result==len(houseList)-1:
            return True
        else:
            return False  
            
    #根据content-description过滤返回控件列表
    def contElement(self,element,className,desc):
        result=[]
        eleList=element.find_elements_by_class_name(className)
        for i in eleList:
            if i.get_attribute('name')==desc:
                result.append(i)
        return result
    
    
    def get_all_house_source_element_from_second_hand_house(self):
        houseSourceList=[]
        #安卓4.3根据resource-id定位
        listView=self.wait_by_id('com.fangdd.mobile.fddhouseownersell:id/refresh_list')
        for frameLayoutItem in listView.find_elements_by_class_name('android.widget.FrameLayout'):            
            if self.contElement(frameLayoutItem,'android.view.View','')==[]:
                break                
            if frameLayoutItem.get_attribute('name')=='houseSource':    
                '''获取房源名字'''
                houseName=frameLayoutItem.find_element_by_id('com.fangdd.mobile.fddhouseownersell:id/house_title')
                
                '''获取房源标签，上门实勘或者推荐房源'''
                try:
                    actualTag=False
                    frameLayoutItem.find_element_by_id('com.fangdd.mobile.fddhouseownersell:id/house_tag')
                    actualTag=True
                except:
                    pass
                    
                '''获取房源标签，新房或者降价房源'''
                try:
                    newHouseTag=False
                    frameLayoutItem.find_element_by_id('com.fangdd.mobile.fddhouseownersell:id/house_title_icon_0')
                    newHouseTag=True
                except:
                    pass
                try:
                    saleHouseTag=False
                    frameLayoutItem.find_element_by_id('com.fangdd.mobile.fddhouseownersell:id/house_price_reduce')
                    saleHouseTag=True
                except:
                    pass                   
                
                '''获取房源户型+面积'''
                TextView=frameLayoutItem.find_element_by_id('com.fangdd.mobile.fddhouseownersell:id/house_sub_title_0')
                houseLayout=TextView.text.split(' ')[0]
                houseArea=TextView.text.split(' ')[3]
                
                '''获取房源预约次数'''
                try:
                    houseResNum=frameLayoutItem.find_element_by_id('com.fangdd.mobile.fddhouseownersell:id/house_sub_title_1')
                except:
                    houseResNum=''
                    
                '''获取房源价格'''
                housePrice=frameLayoutItem.find_element_by_id('com.fangdd.mobile.fddhouseownersell:id/house_price')
                
                '''获取房源单价'''
                unitPrice=frameLayoutItem.find_element_by_id('com.fangdd.mobile.fddhouseownersell:id/house_univalent_price')
                
                '''获取房源标签，满五唯一，地铁房等'''
                try:
                    houseLabel=''
                    element=frameLayoutItem.find_element_by_id('com.fangdd.mobile.fddhouseownersell:id/house_tags2')
                    for item in element.find_elements_by_class_name('android.widget.TextView'):
                        houseLabel+=item.text+' '
                except:
                    pass
                
                '''获取房源地铁距离'''
                try:
                    houseDistance=frameLayoutItem.find_element_by_id('com.fangdd.mobile.fddhouseownersell:id/house_subway_text')
                except:
                    houseDistance=''
    
                houseSourceList.append(SecondHandHouseSourceElement(houseName,houseLayout,houseArea,houseResNum,housePrice,unitPrice=unitPrice,houseLabel=houseLabel,houseDistance=houseDistance,newHouseTag=newHouseTag,saleHouseTag=saleHouseTag,actualTag=actualTag))
        return houseSourceList
        
    def get_all_house_source_from_second_hand_house(self):
        '''在房源列表页获取房源列表'''
        houseSourceList=[]
        #安卓4.3根据resource-id定位
        if self.platformVersion.count('4.2')!=1:
            listView=self.wait_by_id('com.fangdd.mobile.fddhouseownersell:id/refresh_list')
            for frameLayoutItem in listView.find_elements_by_class_name('android.widget.FrameLayout'):            
                if self.contElement(frameLayoutItem,'android.view.View','')==[]:
                    break                
                if frameLayoutItem.get_attribute('name')=='houseSource':    
                    '''获取房源名字'''
                    houseName=frameLayoutItem.find_element_by_id('com.fangdd.mobile.fddhouseownersell:id/house_title').text
                    
                    '''获取房源标签，上门实勘或者推荐房源'''
                    try:
                        actualTag=False
                        frameLayoutItem.find_element_by_id('com.fangdd.mobile.fddhouseownersell:id/house_tag')
                        actualTag=True
                    except:
                        pass
                        
                    '''获取房源标签，新房或者降价房源'''
                    try:
                        newHouseTag=False
                        frameLayoutItem.find_element_by_id('com.fangdd.mobile.fddhouseownersell:id/house_title_icon_0')
                        newHouseTag=True
                    except:
                        pass
                    try:
                        saleHouseTag=False
                        frameLayoutItem.find_element_by_id('com.fangdd.mobile.fddhouseownersell:id/house_price_reduce')
                        saleHouseTag=True
                    except:
                        pass                   
                    
                    '''获取房源户型+面积'''
                    TextView=frameLayoutItem.find_element_by_id('com.fangdd.mobile.fddhouseownersell:id/house_sub_title_0')
                    houseLayout=TextView.text.split(' ')[0]
                    houseArea=TextView.text.split(' ')[3]
                    
                    '''获取房源预约次数'''
                    try:
                        houseResNum=frameLayoutItem.find_element_by_id('com.fangdd.mobile.fddhouseownersell:id/house_sub_title_1').text
                    except:
                        houseResNum=''
                        
                    '''获取房源价格'''
                    housePrice=frameLayoutItem.find_element_by_id('com.fangdd.mobile.fddhouseownersell:id/house_price').text
                    
                    '''获取房源单价'''
                    unitPrice=frameLayoutItem.find_element_by_id('com.fangdd.mobile.fddhouseownersell:id/house_univalent_price').text                    
                    
                    '''获取房源标签，满五唯一，地铁房等'''
                    try:
                        houseLabel=''
                        element=frameLayoutItem.find_element_by_id('com.fangdd.mobile.fddhouseownersell:id/house_tags2')
                        for item in element.find_elements_by_class_name('android.widget.TextView'):
                            houseLabel+=item.text+' '
                    except:
                        pass
                    
                    '''获取房源地铁距离'''
                    try:
                        houseDistance=frameLayoutItem.find_element_by_id('com.fangdd.mobile.fddhouseownersell:id/house_subway_text').text
                    except:
                        houseDistance=''
    
                    houseSourceList.append(SecondHandHouseSource(houseName,houseLayout,houseArea,houseResNum,housePrice,unitPrice=unitPrice,houseLabel=houseLabel,houseDistance=houseDistance,newHouseTag=newHouseTag,saleHouseTag=saleHouseTag,actualTag=actualTag))
    
        else:
            #安卓4.2，根据cont-desc过滤控件
            frameList=self.contElement(self.driver,'android.widget.FrameLayout','houseSource')
            for itemFrame in frameList:
                #获取房源名字
                if self.contElement(itemFrame,'android.view.View','')==[]:
                    break
                houseName=self.contElement(itemFrame,'android.widget.TextView','houseName')[0].text
    
                
                #获取房源布局，面积3室2厅 191.3平米
                houseTypeList=self.contElement(itemFrame,'android.widget.LinearLayout','houseType')
                houseType=self.contElement(itemFrame,'android.widget.LinearLayout','houseType')[0]
                houseText=houseType.find_elements_by_class_name('android.widget.TextView')[0]
                houseLayout=houseText.text.split(' ')[0]
                houseArea=houseText.text.split(' ')[3]
                housePrice=houseType.find_elements_by_class_name('android.widget.TextView')[1].text
                
                #获取房源预约次数
                if self.contElement(itemFrame,'android.widget.TextView','houseLocation')==[]:
                    houseResNum=0
                else:
                    houseResNum=self.contElement(itemFrame,'android.widget.TextView','houseLocation')[0].text
                    
                #获取房源单价
                unitPrice=self.contElement(itemFrame,'android.widget.TextView','unitprice')[0].text
                
                #获取房源标签
                if self.contElement(itemFrame,'android.widget.LinearLayout','housetag')==[]:
                    houseTag=''
                else:
                    Layout=self.contElement(itemFrame,'android.widget.LinearLayout','housetag')[0]
                    houseTag=''
                    for i in Layout.find_elements_by_class_name('android.widget.TextView'):
                        houseTag+=i.text+' '
                        
                #获取房源地铁属性
                if self.contElement(itemFrame,'android.widget.TextView','subway')==[]:
                    subway=''
                else:
                    subway=self.contElement(itemFrame,'android.widget.TextView','subway')
                    subway=subway[0].text
                    
                logging.info('###########Get house attribute###########')
                #logging.info(houseName,houseLayout,houseArea,houseResNum,housePrice,unitPrice,houseTag,subway)
                #print houseName 
                #print houseLayout 
                #print houseArea 
                #print houseResNum 
                #print housePrice 
                #print unitPrice
                #print houseTag
                #print subway            
                houseSourceList.append(SecondHandHouseSource(houseName,houseLayout,houseArea,houseResNum,housePrice,unitPrice=unitPrice,houseLabel=houseTag,houseDistance=subway))
        return houseSourceList
    
    def get_window_size(self):
        self.windowSize=self.driver.get_window_size()
        return self.windowSize
        
    def enter(self,element,content):
        element.send_keys(content)
        return True
    
    def long_press_by_id(self,id,sec=5,timeOut=10):
        ele=self.wait_by_id(id,timeOut)        
        action = appium.webdriver.common.touch_action.TouchAction(self.driver)
        action.long_press(ele).wait(sec).perform()
        return True
    
    def swipe_to_element(self,element,by,dir='up',times=2):
        #up时向上滑动times次数然后寻找控件。
        if dir=='up':
            if by=='name':
                #by name
                for i in range(0,times):
                    if i==0:
                        if self.wait_by_name(element) is not None:
                            return self.wait_by_name(element)
                    self.swipe_from_middle_to_top()
                    if self.wait_by_name(element) is not None:
                        return self.wait_by_name(element)
                return None
            elif by=='class':
                #by class name
                for i in range(0,times):
                    if i==0:
                        if self.wait_by_class(element) is not None:
                            return self.wait_by_class(element)
                    self.swipe_from_middle_to_top()
                    if self.wait_by_class(element) is not None:
                        return self.wait_by_class(element)
                return None
            else:
                for i in range(0,times):
                    if i==0:
                        if self.wait_by_id(element) is not None:
                            return self.wait_by_id(element)                
                    self.swipe_from_middle_to_top()
                    if self.wait_by_id(element) is not None:
                        return self.wait_by_id(element)
                return None
    
    def swipe_to_picture(self,image,dir='up',times=2):
        if dir=='up':
            for i in range(0,times):                
                if i==0:
                    pt=self.app.safeWait(image,10)
                    if pt:
                        return pt
                self.swipe_from_middle_to_top()
                pt=self.app.safeWait(image,10)
                if pt:
                    return pt
            return None
        else:
            for i in range(0,times):
                if i==0:
                    pt=self.app.safeWait(image,10)
                    if pt:
                        return pt
                self.swipe_from_middle_to_bottom()
                pt=self.app.safeWait(image,10)
                if pt:
                    return pt                
            return None
            
    def swipe_and_click_picture(self,image,dir='up',times=2):
        if dir=='up':
            for i in range(0,times):                
                if i==0:
                    pt=self.app.safeWait(image,10)
                    if pt:
                        self.app.click(image)
                        return True
                self.swipe_from_middle_to_top()
                pt=self.app.safeWait(image,10)
                if pt:
                    self.app.click(image)
                    return True
            return False
        else:
            for i in range(0,times):
                if i==0:
                    pt=self.app.safeWait(image,10)
                    if pt:
                        self.app.click(image)
                        return True
                self.swipe_from_middle_to_bottom()
                pt=self.app.safeWait(image,10)
                if pt:
                    self.app.click(image)
                    return True               
            return False
        
    '''Android and IOS device coordinate,x=width,y=height'''
    def swipe_to_top(self,timeOut=3):
        self.driver.swipe(self.windowSize['width']/2,self.windowSize['height'],self.windowSize['width']/2,1)
        time.sleep(timeOut)
        
    def swipe_to_bottom(self,timeOut=3):
        try:
            self.driver.swipe(self.windowSize['width']/2,1,self.windowSize['width']/2,self.windowSize['height'])
        except:
            pass
        time.sleep(timeOut)
        
    def swipe_to_left(self,timeOut=3):
        try:
            self.driver.swipe(self.windowSize['width']-1,self.windowSize['height']/2,1,self.windowSize['height']/2)
        except:
            pass
        time.sleep(timeOut)
        
    def swipe_to_right(self,timeOut=3):
        try:
            self.driver.swipe(1,self.windowSize['height']/2,self.windowSize['width'],self.windowSize['height']/2)
        except:
            pass
        time.sleep(timeOut)
        
    def swipe_from_middle_to_top(self,timeOut=3):
        try:
            self.driver.swipe(self.windowSize['width']/2,self.windowSize['height']/2,self.windowSize['width']/2,23)
        except:
            pass
        time.sleep(timeOut)
        
    def swipe_from_middle_to_bottom(self,timeOut=3):
        try:
            self.driver.swipe(self.windowSize['width']/2,self.windowSize['height']/2,self.windowSize['width'],self.windowSize['height'])
        except:
            pass
        time.sleep(timeOut)
        
    def swipe_from_middle_to_left(self,timeOut=3):
        try:
            self.driver.swipe(self.windowSize['height']/2,self.windowSize['width']/2,self.windowSize['height']/2,1)
        except:
            pass
        time.sleep(timeOut)
        
    def swipe_from_middle_to_right(self,timeOut=3):
        try:
            self.driver.swipe(self.windowSize['height']/2,self.windowSize['width']/2,self.windowSize['height']/2,self.windowSize['width'])
        except:
            pass
        time.sleep(timeOut)
    
    def swipe_from_element_to_element(self,element1,element2):
        pass
        
    def save_screen_shot(self,fileName):
        self.driver.get_screenshot_as_file(fileName)
    
    def stop_driver(self):
        self.driver.quit()
    
    def wait_by_id(self,id,timeOut=5):
        count=0
        while (count<=timeOut):
            try:
                return self.driver.find_element_by_id(id)
            except:                
                count+=1
                time.sleep(1)
        return None
        
    def wait_by_name(self,text,timeOut=5):
        count=0
        while (count<=timeOut):
            try:
                return self.driver.find_element_by_name(text)
            except:                
                count+=1
                time.sleep(1)
        return None
        
    def wait_by_class(self,className,timeOut=5):
        count=0
        while (count<=timeOut):
            try:
                return self.driver.find_element_by_class_name(className)
            except Exception,e:
                count+=1
                time.sleep(1)
        return None
    
    def wait_by_class_list(self, classname, timeout=5):
        """根据class name查找元素列表，返回一个列表"""
        return common.wait(timeout)(self.driver.find_elements_by_class_name)(classname)
    
    def wait_by_image(self, image, timeout=5):
        """根据image查找元素，返回一个坐标"""
        return self.app.safeWait(image, timeout)    

#desired_caps = {}
#desired_caps['platformName'] = 'Android'
#desired_caps['newCommandTimeout'] = 3600
#desired_caps['unicodeKeyboard'] = True
#desired_caps['resetKeyboard'] = True
#desired_caps['appPackage'] = 'com.fangdd.mobile.fddhouseownersell'
#desired_caps['appActivity'] = 'com.fangdd.mobile.fddhouseownersell.activity.WelcomeActivity'
#desired_caps['deviceName'] = '192.168.56.101:5555'
#desired_caps['platformVersion'] = '4.3'
#a=AppiumApi(desired_caps,'localhost', '4723')
#a.click_by_name(u'二手房')
#a.click_by_name(u'筛选')
#a.swipe_seek_picture('2.png',times=2)

