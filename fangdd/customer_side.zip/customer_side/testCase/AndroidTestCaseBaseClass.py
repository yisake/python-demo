#coding=utf8
import unittest
import os
import sys
import logging
import time
import traceback
import platform
import shutil
import warnings
import MySQLdb
from sshtunnel import SSHTunnelForwarder
sys.path.append('..')
import lib

class AndroidTestCaseBaseClass(unittest.TestCase):        
    '''Base class for all appium android test cases
    修改setUp中的方法(InitAppiumClient AppiumLogin)或者run方法，需要同时注意修改setUpClass方法
    classInitAppiumClient
    classAppiumLoginIn
    '''
    report_path=time.strftime('%Y-%m-%d_%H@%M',time.localtime(time.time()))
    '''失败重跑次数，默认是4-1=3次'''
    repeat_time = 4

    @classmethod
    def classLoadConfig(cls):
        '''Integrate to jenkins,if exists the environment varible,set the config file with the value'''
        if os.environ.has_key('JENKINS_HOME'):
            cls.conf_name='android.cfg'
            cls.cf = lib.Config(cls.conf_name)
            logging.info('Version: '+ os.environ['JOB_NAME'])
        else:
            cls.conf_name='android.cfg'
            cls.cf = lib.Config(cls.conf_name)

    @classmethod
    def classInitAppiumClient(cls, app_path=None):
        
        #初始化脚本路径。
        if lib.scriptsPath().count('logs')!=0:
            cls.script_path=lib.scriptsPath()[:-5]
        else:
            cls.script_path=lib.scriptsPath()
            
        #根据平台不同带入不同格式的路径，初始化image_path   
        if platform.system()=='Windows':
            cls.image_path=cls.script_path + '\\images\\'
        else:
            cls.image_path=cls.script_path + '/images/'
                  
        cls.classInit = True
        cls.classLoadConfig()
        desired_caps = {}
        desired_caps['platformName'] = 'Android'
        desired_caps['newCommandTimeout'] = 3600
        desired_caps['unicodeKeyboard'] = True
        desired_caps['resetKeyboard'] = True
        AndroidTestCaseBaseClass.package_name = desired_caps['appPackage'] = 'com.fangdd.mobile.fddhouseownersell'
        desired_caps['appActivity'] = 'com.fangdd.mobile.fddhouseownersell.activity.WelcomeActivity'

        # if os.environ.has_key('JENKINS_HOME'): // has_key() 已经不建议使用
        if 'JENKINS_HOME' in os.environ:
            AndroidTestCaseBaseClass.device_name = desired_caps['deviceName'] = os.environ['deviceName']
            desired_caps['platformVersion'] = os.environ['platformVersion']
            server_port = os.environ['serverPort']
            # cls.appiumClient=lib.AppiumApi(deviceName=os.environ['deviceName'],platformVersion=os.environ['platformVersion'],serverPort=os.environ['serverPort'],apk_path=apk_path)
        else:
            AndroidTestCaseBaseClass.device_name = desired_caps['deviceName'] = cls.cf.device_name
            desired_caps['platformVersion'] = cls.cf.platform_version
            server_port = cls.cf.server_port

        if app_path is not None:
            desired_caps['app'] = app_path

        cls.appiumClient = lib.AppiumApi(desired_caps, 'localhost', server_port)
        
        #commit by春峰:2016.6.17
        #if cls.appiumClient.wait_by_id('com.fangdd.mobile.fddhouseownersell:id/ll_page') is not None:
        #    cls.classAppiumLoginIn()
            
        #if cls.appiumClient.app.safeWait(cls.image_path+'tmp1.png'):
        #    cls.appiumClient.app.click(cls.image_path+'xiaoqu.png')
                        
        if cls.appiumClient.wait_by_name(u'发现新版本') is not None:
            cls.appiumClient.click_by_name(u'取消')
    
    @classmethod
    def classAppiumLoginIn(cls):
        cls.appiumClient.wait_by_class('android.support.v4.view.ViewPager')
        cls.appiumClient.swipe_to_left()
        cls.appiumClient.swipe_to_left()
        cls.appiumClient.swipe_to_left()
        cls.appiumClient.click_the_enter_button()
        cls.assertTrue(cls.appiumClient.click_by_name(u'上海'),'无法点击定位城市')        
        if cls.appiumClient.wait_by_name(u'发现新版本') is not None:
            cls.appiumClient.click_by_name(u'取消')
            
    def setUp(self):
        self.InitialTest()
        
    def tearDown(self):
        logging.info(self.test_name+' Tear Down...')
        self.tearDownStep()
    
    def tearDownStep(self):    
        #进入脚本的绝对路径。
        logging.info('Changing path to...'+self.log_path)
        os.chdir(self.log_path)
        logging.info('Current path is '+os.getcwd())
        
        self.close_mysql()
        
        #删除截图文件。
        if os.path.exists('./tmp'):
            logging.info('Deleting screenshot...')
            shutil.rmtree('./tmp')
        try:
            if self.IsCaseFailed():
                logging.warning('Skip tear down to save failure information')
                logging.fatal('FAILED: Case%s %s' % (self.test_id, self.test_name))
                #如果有rest_flag，则跳过退出appium drver步骤
                if hasattr(self,'rest_flag'):
                    return                
                self.appiumClient.save_screen_shot('capture.png')                
                if hasattr(self, 'classInit'):
                    logging.info('Skip quit appium driver...')
                    pass
                else:    
                    self.appiumClient.stop_driver()
            else:
                logging.fatal('PASSED: Case%s %s' % (self.test_id, self.test_name))
                
                #如果有rest_flag，则跳过退出appium drver步骤
                if hasattr(self,'rest_flag'):
                    return
                
                #如果有类方法
                if hasattr(self, 'classInit'):
                    logging.info('Skip quit appium driver...')
                    pass
                else:    
                    self.appiumClient.stop_driver()
        except Exception,e:
            logging.fatal(e)
            logging.fatal(traceback.format_exc())
    '''    
    ###############################################
    #Program:
    #    Common test step method for all test cases
    ###############################################
    '''
    def InitialTest(self,config_file='android.cfg'):
        try:
            self.SetTestNameAndId()
            self.LoadConfig(config_file)
            self.SetLogConfig()
            self.SetupLogInterface()
            if lib.scriptsPath().count('logs')!=0:
                os.chdir(lib.scriptsPath()[:-5]+ '/logs/'+self.report_path+'/'+self.test_name+'/')
            else:
                os.chdir(lib.scriptsPath() + '/logs/'+self.report_path+'/'+self.test_name+'/')        
        except:
            test_info = sys.exc_info()
            if test_info[2]:
                tb = traceback.format_exception(test_info[0], test_info[1], test_info[2])
                print ''.join(tb)
   
    def SetTestNameAndId(self):
        self.test_id = time.strftime('%Y-%m-%d_%H:%S',time.localtime(time.time()))
        self.test_name = '.'.join((self.id().split('.')[-2],self.id().split('.')[-1]))
        self.test_case_name = self.id().split('.')[-1]
        
    def LoadConfig(self,config_file='android.cfg'):
        '''Integrate to jenkins,if exists the environment varible,set the config file with the value'''
        if os.environ.has_key('JENKINS_HOME'):
            self.conf_name=config_file
            self.cf = lib.Config(self.conf_name)
        else:            
            self.conf_name=config_file
            self.cf = lib.Config(self.conf_name)
        self.SetupTestAttr()
    
    def SetupTestAttr(self):
        if os.environ.has_key('JENKINS_HOME'):
            self.test_env=os.environ['TEST_ENV']
        else:
            self.test_env=self.cf.test_env
        if self.test_env=='test':
            self.test_env=u'测试环境'
        elif self.test_env=='prePublish':
            self.test_env=u'预发布环境'        
        
    def SetLogConfig(self):
        lib.removeAllLogHandler()
        lib.setUpStdoutLoggingHandler(logging.DEBUG)
        self.logger = logging.getLogger(__name__)

    def SetupLogInterface(self):
        #初始化脚本路径。
        self.script_path=lib.scriptsPath()        
            
        #根据平台不同带入不同格式的路径，初始化log_pah和image_path，log_path加入report_path时间戳。
        if platform.system()=='Windows':
            self.log_path = self.script_path + '\\logs\\'+self.report_path+'\\'
            self.image_path=self.script_path + '\\images\\'
        else:
            self.log_path = self.script_path + '/logs/'+self.report_path+'/'
            self.image_path=self.script_path + '/images/'
        
        if not os.access(self.log_path, os.F_OK):
            os.mkdir(self.log_path)
        
        #Commit by Chunfeng:2016.10.9
        #No need to seprate js and css file with report.
        #
        #shutil.copyfile(self.script_path+'\\lib\\script.js',self.log_path+'script.js')
        #shutil.copyfile(self.script_path+'\\lib\\script.css',self.log_path+'script.css')
        
        #log_path加入测试用例名称,mkdir。
        self.log_path = self.log_path + self.test_name
        if not os.access(self.log_path, os.F_OK):
            os.mkdir(self.log_path)
        
        #初始化log文件名字log_file。
        self.log_file = '%s/%s.log' % (self.log_path, self.test_case_name)
        
        while len(logging.root.handlers) > 0:
            logging.root.removeHandler(logging.root.handlers[-1])
        logging.root.setLevel(logging.DEBUG)
        '''Add stdout logger'''
        fh = logging.StreamHandler()
        fmt = logging.Formatter(fmt='%(asctime)s %(levelname)-5s - %(message)s'
                                , datefmt='%m/%d/%Y %H:%M:%S')
        fh.setFormatter(fmt)
        fh.setLevel(self.cf.std_log_level)
        logging.root.addHandler(fh)
        '''Add file logger'''
        fh = logging.FileHandler(filename=self.log_file, mode='w',)
        fmt = logging.Formatter(fmt='%(asctime)s %(levelname)-5s - %(message)s'
                                , datefmt='%m/%d/%Y %H:%M:%S')
        fh.setFormatter(fmt)
        fh.setLevel(logging.DEBUG)
        logging.root.addHandler(fh)
        logging.info('Test case: '+self.test_name)  
        logging.info('Load config file:'+self.conf_name)  
        logging.info('Set up logging interface finish')
        logging.info('Test environment:'+self.test_env)
        
        #根据配置文件名判断是否获取安卓版本和apk路径，需要同时修改HTMLTestRunner。
        if self.cf.default_file=='android.cfg':
            if os.environ.has_key('JENKINS_HOME'):
                logging.info('Android Version:'+os.environ['platformVersion'])
                logging.info('Apk Path:'+os.environ['apkPath'])        
            else:
                logging.info('Android Version:'+self.cf.platform_version)
                logging.info('Apk Path:'+ self.cf.apk_path)
     
    def InitAppiumClient(self, app_path=None,resolution_flag=False):
        desired_caps = {}
        desired_caps['platformName'] = 'Android'
        desired_caps['newCommandTimeout'] = 3600
        desired_caps['unicodeKeyboard'] = True
        desired_caps['resetKeyboard'] = True
        self.package_name = desired_caps['appPackage'] = 'com.fangdd.mobile.fddhouseownersell'
        desired_caps['appActivity'] = 'com.fangdd.mobile.fddhouseownersell.activity.WelcomeActivity'

        if 'JENKINS_HOME' in os.environ:
            self.devide_name = desired_caps['deviceName'] = os.environ['deviceName']
            desired_caps['platformVersion'] = os.environ['platformVersion']
            server_port = os.environ['serverPort']
            # self.appiumClient=lib.AppiumApi(deviceName=os.environ['deviceName'],platformVersion=os.environ['platformVersion'],serverPort=os.environ['serverPort'],apkPath=apk_path)
        else:
            self.device_name = desired_caps['deviceName'] = self.cf.device_name
            desired_caps['platformVersion'] = self.cf.platform_version
            server_port = self.cf.server_port
        
        if app_path is not None:
            desired_caps['app'] = app_path

        self.appiumClient = lib.AppiumApi(desired_caps, 'localhost', server_port)
        
        if resolution_flag:
            self.appiumClient.app.globalSet(screen_resolution=(self.appiumClient.windowSize['width'],self.appiumClient.windowSize['height']))
        
        #commit by春峰:2016.6.17
        #if self.appiumClient.wait_by_id('com.fangdd.mobile.fddhouseownersell:id/ll_page') is not None:
        #    self.AppiumLoginIn()
        
        #commit by春峰:2016.6.17    
        #if self.appiumClient.app.safeWait(self.image_path+'tmp1.png'):
        #    self.appiumClient.app.click(self.image_path+'xiaoqu.png')
                        
        if self.appiumClient.wait_by_name(u'发现新版本') is not None:
            self.appiumClient.click_by_name(u'取消')
        
    def AppiumLoginIn(self):
        self.appiumClient.wait_by_class('android.support.v4.view.ViewPager')
        self.appiumClient.swipe_to_left()
        self.appiumClient.swipe_to_left()
        self.appiumClient.swipe_to_left()
        self.appiumClient.click_the_enter_button()
        self.assertTrue(self.appiumClient.click_by_name(u'上海'),'无法点击定位城市')        
        if self.appiumClient.wait_by_name(u'发现新版本') is not None:
            self.appiumClient.click_by_name(u'取消')
                
    def IsCaseFailed(self):
        ''' Check if case is failed by Assertion or not'''
        test_info = sys.exc_info()
        if test_info[2]:
            tb = traceback.format_exception(test_info[0], test_info[1], test_info[2])
            logging.error(''.join(tb))
        #failed = isinstance(test_info[1], AssertionError)
        failed = (test_info[2] != None) 
        return failed
    
    def RecoverTestEnv(self,choose=0):
        if choose==0:
            pass
        elif 1:
            lib.common.clean_app_cache(self.device_name,self.package_name)
        
    def run(self, result=None):
        orig_result = result
        if result is None:
            result = self.defaultTestResult()
            startTestRun = getattr(result, 'startTestRun', None)
            if startTestRun is not None:
                startTestRun()

        self._resultForDoCleanups = result
        result.startTest(self)

        testMethod = getattr(self, self._testMethodName)
        if (getattr(self.__class__, "__unittest_skip__", False) or
            getattr(testMethod, "__unittest_skip__", False)):
            # If the class or method was skipped.
            try:
                skip_why = (getattr(self.__class__, '__unittest_skip_why__', '')
                            or getattr(testMethod, '__unittest_skip_why__', ''))
                self._addSkip(result, skip_why)
            finally:
                result.stopTest(self)
            return
        try:
            success = False
            try:
                self.setUp()
            except unittest.case.SkipTest as e:
                self._addSkip(result, str(e))
            except KeyboardInterrupt:
                raise
            except:
                result.addError(self, sys.exc_info())
            else:
                try:
                    #重写unittest.TestCase run方法，失败重跑两次,i取值范围0~repeat_time-1
                    for i in range(0,self.repeat_time):
                        #用来存储当前运行的i次数
                        self.repeat_index=i
                        try:
                            logging.info('########start to test for '+str(i)+' times')                            
                            if i!=0:
                                logging.info('****Class setUpClass method init****')
                                setUpClass = getattr(self.__class__, 'setUpClass', None)
                                if setUpClass is not None:
                                    setUpClass()
                            testMethod()
                            self.appiumClient.app.dev.adbclient.close()
                            break
                        except Exception,e:
                            #失败重跑最后一次(n次)结果为失败时，不退出driver，引发异常
                            #失败重跑0~n-1次退出driver，执行失败退出driver，清理app程序缓存
                            self.appiumClient.app.dev.adbclient.close()
                            if i==self.repeat_time-1:                                
                                logging.info(traceback.format_exc())
                                raise e
                            else:                                
                                logging.info(traceback.format_exc())
                                #self.appiumClient.stop_driver()                                
                            self.RecoverTestEnv()
                            continue
                except KeyboardInterrupt:
                    raise
                except self.failureException:
                    result.addFailure(self, sys.exc_info())
                except unittest.case._ExpectedFailure as e:
                    addExpectedFailure = getattr(result, 'addExpectedFailure', None)
                    if addExpectedFailure is not None:
                        addExpectedFailure(self, e.exc_info)
                    else:
                        warnings.warn("TestResult has no addExpectedFailure method, reporting as passes",
                                      RuntimeWarning)
                        result.addSuccess(self)
                except unittest.case._UnexpectedSuccess:
                    addUnexpectedSuccess = getattr(result, 'addUnexpectedSuccess', None)
                    if addUnexpectedSuccess is not None:
                        addUnexpectedSuccess(self)
                    else:
                        warnings.warn("TestResult has no addUnexpectedSuccess method, reporting as failures",
                                      RuntimeWarning)
                        result.addFailure(self, sys.exc_info())
                except unittest.case.SkipTest as e:
                    self._addSkip(result, str(e))
                except:
                    result.addError(self, sys.exc_info())
                else:
                    success = True

                try:
                    self.tearDown()
                except KeyboardInterrupt:
                    raise
                except:
                    result.addError(self, sys.exc_info())
                    success = False

            cleanUpSuccess = self.doCleanups()
            success = success and cleanUpSuccess
            if success:
                result.addSuccess(self)
        finally:
            result.stopTest(self)
            if orig_result is None:
                stopTestRun = getattr(result, 'stopTestRun', None)
                if stopTestRun is not None:
                    stopTestRun()
    
    def connet_to_mysql(self):
        if os.environ.has_key('JENKINS_HOME'):
            env=os.environ['TEST_ENV']
        else:
            env=self.cf.test_env
        if env=='test':
            logging.info('Connect to test MySQL...')
            self.connect_test_mysql()
        elif env=='prePublish':
            logging.info('Connect to prePublish MySQL...')
            self.connect_pre_publish_mysql()
        else:
            raise ValueError('Choose MySQL parameter error...') 
        
    def close_mysql(self):
        if hasattr(self, 'mysql_server'):
            logging.info('Closeing mysql connection...')
            self.conn.close()
            self.mysql_server.stop()
            self.mysql_server.close()
            
    def connect_test_mysql(self):
        self.conn=MySQLdb.connect(host='10.12.21.120',user='common',passwd='VGMtp3yl',db='fdd_second_house',port=3306,charset="utf8")
    
    def connect_pre_publish_mysql(self):
        self.mysql_server= SSHTunnelForwarder(
                ('10.50.110.11', 22),
                ssh_username="xfsh",
                ssh_password="2c8b78a6943ad98abebe930704c827b7",         
                remote_bind_address=('10.50.20.91', 3306))
        self.mysql_server.start()
        self.conn = MySQLdb.connect(host='127.0.0.1',
                            port=self.mysql_server.local_bind_port,
                            user='esf_test',
                            passwd='pwd_test',
                            db='fdd_second_house',
                            charset="utf8")
        
    def get_sql_info( self , SQL):
        cur=self.conn.cursor()
        cur.execute(SQL)
        result=cur.fetchall()
        cur.close()
        return result        