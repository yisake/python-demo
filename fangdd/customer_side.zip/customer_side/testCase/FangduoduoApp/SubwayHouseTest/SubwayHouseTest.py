#coding=utf8
import unittest
import os
import sys
import logging
import time
import traceback
import platform
sys.path.append('../../..')
import lib
from testCase.AndroidTestCaseBaseClass import AndroidTestCaseBaseClass

class SubwayHouseTest(AndroidTestCaseBaseClass):
    '''地铁房业务测试集'''
    #Author Huangfu
    #Date 2015/12/2
    #Program:
    #    Test second hand house
    
    @classmethod
    def setUpClass(cls):
        cls.classInitAppiumClient()
        
    @classmethod
    def tearDownClass(cls):  
        cls.appiumClient.stop_driver()
        
    def test_subway_house_title(self):
        '''测试地铁房标题栏'''
        logging.info('Step-2:点击地铁房')
        self.assertTrue(self.appiumClient.click_by_name(u'地铁房'),'Found location failed...')

    def test_click_subway_house(self):
        '''测试地铁房提示栏'''
        logging.info('Step-3:查看提示是否存在')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png',30.0),'无法找到提示')
        self.appiumClient.app.click(self.image_path+'secondhouse/x.png')
        self.assertIsNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png',10.0),'无法找到提示') 
        
    def test_sort_by_unit_price(self):
        '''测试地铁房根据单价排序'''
        logging.info('测试单价从高到低')        
        self.assertTrue(self.appiumClient.click_by_name(u'排序'),'无法找到排序')
        self.appiumClient.app.click(self.image_path+'secondhouse/paixu/danjiayougaodaodi.png')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'paixu.png'))        
        houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
        self.assertTrue(self.appiumClient.compareUnitPirce(houseList,'down'),'比较失败')
        
        logging.info('测试单价从低到高')
        self.assertTrue(self.appiumClient.click_by_name(u'排序'),'无法找到排序')
        self.appiumClient.app.click(self.image_path+'secondhouse/paixu/danjiayoudidaogao.png')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'paixu.png'))
        houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
        self.assertTrue(self.appiumClient.compareUnitPirce(houseList,'up'),'比较失败')

    def test_sort_by_total_price(self):
        '''测试地铁房根据总价排序'''
        logging.info('测试总价从高到低')        
        self.assertTrue(self.appiumClient.click_by_name(u'排序'),'无法找到排序')
        self.appiumClient.app.click(self.image_path+'secondhouse/paixu/zongjiayougaodaodi.png')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'paixu.png'))
        houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
        self.assertTrue(self.appiumClient.compareHousePrice(houseList,'down'),'比较失败')
        
        logging.info('测试总价从低到高')
        self.assertTrue(self.appiumClient.click_by_name(u'排序'),'无法找到排序')
        self.appiumClient.app.click(self.image_path+'secondhouse/paixu/zongjiayoudidaogao.png')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'paixu.png'))
        houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
        self.assertTrue(self.appiumClient.compareHousePrice(houseList,'up'),'比较失败')

    def test_sort_by_area(self):
        '''测试地铁房根据面积排序'''
        logging.info('测试面积从小到大')        
        self.assertTrue(self.appiumClient.click_by_name(u'排序'),'无法找到排序')
        self.appiumClient.app.click(self.image_path+'secondhouse/paixu/mianjiyouxiaodaoda.png')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'paixu.png'))
        houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
        self.assertTrue(self.appiumClient.compareHouseArea(houseList,'down'),'比较失败')
        
        logging.info('测试单价从大到小')
        self.assertTrue(self.appiumClient.click_by_name(u'排序'),'无法找到排序')
        self.appiumClient.app.click(self.image_path+'secondhouse/paixu/mianjiyoudadaoxiao.png')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'paixu.png'))
        houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
        self.assertTrue(self.appiumClient.compareHouseArea(houseList,'up'),'比较失败')
    
    def test_sort_by_res_num(self):
        '''测试地铁房根据预约人数由高到低'''
        logging.info('测试单价从大到小')
        self.assertTrue(self.appiumClient.click_by_name(u'排序'),'无法找到排序')
        self.appiumClient.app.click(self.image_path+'secondhouse/paixu/yuyuerenshuyougaodaodi.png')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'paixu.png'))
        houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
        self.assertTrue(self.appiumClient.compareResNum(houseList,'down'),'比较失败')
        
if __name__ == '__main__':
    suite=unittest.TestSuite()
    suite.addTest(SubwayHouseTest('test_subway_house_title'))
    suite.addTest(SubwayHouseTest('test_click_subway_house'))
    suite.addTest(SubwayHouseTest('test_sort_by_unit_price'))
    suite.addTest(SubwayHouseTest('test_sort_by_total_price'))
    suite.addTest(SubwayHouseTest('test_sort_by_area'))
    suite.addTest(SubwayHouseTest('test_sort_by_res_num'))
    runner = lib.HTMLTestRunner(stream='TestReport.html',title="Test Result",description='Test Suite')
    runner.run(suite)
    if ((runner.failure_count !=0) or (runner.error_count!=0)):
        raise Exception('Test Suite execute finished,Test suite failed...')
    