#coding=utf8
import unittest
import os
import sys
import logging
import time
import traceback
import platform
sys.path.append('../../..')
import lib
from testCase.AndroidTestCaseBaseClass import AndroidTestCaseBaseClass

class SubwayHouseLocationTest(AndroidTestCaseBaseClass):
    '''测试地铁房地铁地铁'''
    
    @classmethod
    def setUpClass(cls):
        AndroidTestCaseBaseClass.classInitAppiumClient()
        
    @classmethod
    def tearDownClass(cls):  
        cls.appiumClient.stop_driver()    
    
    def test_subway_house_subway_line1(self):
        '''测试地铁房地铁1号线筛选'''
        logging.info('Step-1:点击地铁房')
        self.assertTrue(self.appiumClient.click_by_name(u'地铁房',20),'无法找到地铁房')
        
        #过滤 shanxinanlu,shanghaimaxicheng,jinjiangleyuan,changshulu,
        areaList=['fujinlu','youyixilu','baoangonglu','gongfuxincun','hulanlu','tonghexincun','gongkanglu',
        'pengpuxincun','wenshuilu','yanchanglu','zhongshanbeilu','shanghaihuochezhan',
        'hanzhonglu','xinzhalu','renminguangchang','huangpinanlu','hengshanlu',
        'xujiahui','caobaolu','shanghainanzhan','lianhualu','waihuanlu','xinzhuang']
        
        for area in areaList:
            self.assertTrue(self.appiumClient.click_by_name(u'地铁',20),'无法找到地铁')
            if area=='fujinlu':     
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/ditie/1haoxian.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/ditie/1haoxian/'+area+'.png')
            self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
            houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
            for house in houseList:
                self.assertTrue(house.houseDistance.count(u'1\u53f7\u7ebf') or lib.get_pinyin(house.houseDistance[1:house.houseDistance.find(u'\u7ad9')]).count(area),'地铁地铁错误')
    
    def test_subway_house_subway_line2(self):
        '''测试地铁房地铁2号线筛选'''
        logging.info('Step-1:点击地铁房')

        #过滤'zhongshangongyuan',
        areaList=['pudongguojijichang','haitiansanlu','yuandongdadao','lingkonglu','chuansha','huaxiadonglu',
        'chuangxinzhonglu','tangzhen','guanglanlu','jinkelu','zhangjianggaoke','longyanglu','shijigongyuan','shanghaikejiguan',
        'shijidadao','dongchanglu','lujiazui','nanjingdonglu','jingansi','jiangsulu','loushanguanlu',
        'weininglu','beixinjing','songhonglu','hongqiao2haohangzhanlou','hongqiaohuochezhan','xujingdong']
        
        for area in areaList:
            self.assertTrue(self.appiumClient.click_by_name(u'地铁',20),'无法找到地铁')
            if area=='pudongguojijichang':
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/ditie/2haoxian.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/ditie/2haoxian/'+area+'.png')
            self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
            houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
            for house in houseList:
                self.assertTrue(house.houseDistance.count(u'2\u53f7\u7ebf') or lib.get_pinyin(house.houseDistance[1:house.houseDistance.find(u'\u7ad9')]).count(area),'地铁地铁错误')
    
    def test_subway_house_subway_line3(self):
        '''测试地铁房地铁3号线筛选'''
        logging.info('Step-1:点击地铁房')
        
        #过滤'longcaolu','zhongshangongyuan',hongkouzuqiuchang
        areaList=['shanghainanzhan','shilonglu','caoxilu','yishanlu','hongqiaolu','yananxilu',
        'jinshajianglu','caoyanglu','zhenpinglu','zhongtanlu','shanghaihuochezhan','baoshanlu',
        'dongbaoxinglu','hongkouzuqiuchang','chifenglu','dabaishu','jiangwanzhen','yingaoxilu','changjiangnanlu','songfalu','zhanghuabang',
        'songbinlu','shuichanlu','baoyanglu','youyilu','tielilu','jiangyangbeilu']

        for area in areaList:
            self.assertTrue(self.appiumClient.click_by_name(u'地铁',20),'无法找到地铁')
            if area=='shanghainanzhan':
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/ditie/3haoxian.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/ditie/3haoxian/'+area+'.png')
            self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
            houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
            for house in houseList:
                self.assertTrue(house.houseDistance.count(u'3\u53f7\u7ebf') or lib.get_pinyin(house.houseDistance[1:house.houseDistance.find(u'\u7ad9')]).count(area),'地铁地铁错误')

    def test_subway_house_subway_line4(self):
        '''测试地铁房地铁4号线筛选'''
        logging.info('Step-1:点击地铁房')
        
        #过滤'pudianlu','zhenpinglu','caoyanglu','zhongshangongyuan',
        areaList=['yishanlu','shanghaitiyuguan','shanghaitiyuchang','donganlu','damuqiaolu','lubanlu','xizangnanlu',
        'nanpudaqiao','tangqiao','lancunlu','shijidadao','pudongdadao','yangshupulu','dalianlu',
        'linpinglu','hailunlu','baoshanlu','shanghaihuochezhan','zhongtanlu','jinshajianglu','yananxilu','hongqiaolu']

        for area in areaList:
            self.assertTrue(self.appiumClient.click_by_name(u'地铁',20),'无法找到地铁')
            if area=='yishanlu':
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/ditie/4haoxian.png')            
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/ditie/4haoxian/'+area+'.png')
            self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
            houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
            for house in houseList:
                self.assertTrue(house.houseDistance.count(u'4\u53f7\u7ebf') or lib.get_pinyin(house.houseDistance[1:house.houseDistance.find(u'\u7ad9')]).count(area),'地铁地铁错误')
    
    def test_subway_house_subway_line5(self):
        '''测试地铁房地铁5号线筛选'''
        logging.info('Step-1:点击地铁房')
                
        areaList=['xinzhuang','chunshenlu','yindulu','zhuanqiao','beiqiao','jianchuanlu','dongchuanlu',
        'jinpinglu','huaninglu','wenjinglu','minhangkaifaqu']

        for area in areaList:
            self.assertTrue(self.appiumClient.click_by_name(u'地铁',20),'无法找到地铁')
            if area=='xinzhuang':
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/ditie/5haoxian.png')            
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/ditie/5haoxian/'+area+'.png')
            self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
            houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
            for house in houseList:
                self.assertTrue(house.houseDistance.count(u'5\u53f7\u7ebf') or lib.get_pinyin(house.houseDistance[1:house.houseDistance.find(u'\u7ad9')]).count(area),'地铁地铁错误')
    
    def test_subway_house_subway_line6(self):
        '''测试地铁房地铁6号线筛选'''
        logging.info('Step-1:点击地铁房')
        
        #过滤'pudianlu','dongfangtiyuzhongxin'
        areaList=['gangchenglu','waigaoqiaobaoshuiqubei','hangjinlu','waigaoqiaobaoshuiqunan','zhouhailu',
        'wuzhoudadao','dongjinglu','jufenglu','wulianlu','boxinglu','jinqiaolu','yunshanlu','depinglu',
        'beiyangjinglu','minshenglu','yuanshentiyuzhongxin','shijidadao','lancunlu','shanghaiertongyixuezhongxin',
        'linyixincun','gaokexilu','dongminglu','gaoqinglu','huaxiaxilu','shangnanlu','lingyannanlu']

        for area in areaList:
            self.assertTrue(self.appiumClient.click_by_name(u'地铁',20),'无法找到地铁')
            if area=='gangchenglu':
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/ditie/6haoxian.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/ditie/6haoxian/'+area+'.png')
            self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
            houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
            for house in houseList:
                self.assertTrue(house.houseDistance.count(u'6\u53f7\u7ebf') or lib.get_pinyin(house.houseDistance[1:house.houseDistance.find(u'\u7ad9')]).count(area),'地铁地铁错误')
    
    def test_subway_house_subway_line7(self):
        '''测试地铁房地铁7号线筛选'''
        logging.info('Step-1:点击地铁房')
        
        areaList=['huamulu','longyanglu','fanghualu','jinxiulu','yanggaonanlu','gaokexilu','yuntailu',
        'yaohualu','changqinglu','houtan','longhuazhonglu','donganlu','zhaojibanglu','changshulu','jingansi',
        'changpinglu','changshoulu','zhenpinglu','langaolu','xincunlu','dahuasanlu','xingzhilu','dachangzhen',
        'changzhonglu','shangdalu','nanchenlu','shanghaidaxue','gucungongyuan','liuhang','panguanglu','luonanxincun',
        'meilanhu']

        for area in areaList:
            self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
            self.assertTrue(self.appiumClient.click_by_name(u'地铁',20),'无法找到地铁')
            if area=='huamulu':
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/ditie/7haoxian.png')
            if area=='fanghualu':
                time.sleep(2)
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/ditie/7haoxian/'+area+'.png')
            self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
            houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
            for house in houseList:
                self.assertTrue(house.houseDistance.count(u'7\u53f7\u7ebf') or lib.get_pinyin(house.houseDistance[1:house.houseDistance.find(u'\u7ad9')]).count(area),'地铁地铁错误')
    
    def test_subway_house_subway_line8(self):
        '''测试地铁房地铁8号线筛选'''
        logging.info('Step-1:点击地铁房')
        
        areaList=['shendugonglu','lianhanglu','jiangyuelu','pujiangzhen','luhenglu','lingzhaoxincun','yangsi',
        'chengshanlu','yaohualu','zhonghuayishugong','xizangnanlu','lujiabanglu','laoximen','dashijie','renminguangchang',
        'quhulu','zhongxinglu','xizangbeilu','hongkouzuqiuchang','quyanglu','sipinglu','anshanxincun','jiangpulu','huangxinglu',
        'yanjizhonglu','huangxinggongyuan','xiangyinlu','nenjianglu','shiguanglu']

        for area in areaList:
            self.assertTrue(self.appiumClient.click_by_name(u'地铁',20),'无法找到地铁')
            if area=='shendugonglu':
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/ditie/8haoxian.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/ditie/8haoxian/'+area+'.png')
            self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
            houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
            for house in houseList:
                self.assertTrue(house.houseDistance.count(u'8\u53f7\u7ebf') or lib.get_pinyin(house.houseDistance[1:house.houseDistance.find(u'\u7ad9')]).count(area),'地铁地铁错误')
    
    def test_subway_house_subway_line9(self):
        '''测试地铁房地铁9号线筛选'''
        logging.info('Step-1:点击地铁房')
        
        #过滤，'xujiahui'
        areaList=['yanggaozhonglu','shijidadao','shangchenglu','xiaonanmen','lujiabanglu','madanglu','dapuqiao','jiashanlu',
        'zhaojiabanglu','yishanlu','guilinlu','caohejingkaifaqu','hechuanlu','xingzhonglu','qibao','zhongchunlu',
        'jiuting','sijing','sheshan','dongjing','songjiangdaxuecheng','songjiangxincheng','songjiangtiyuzhongxin',
        'zuibaichi','songjiangnanzhan']

        for area in areaList:
            self.assertTrue(self.appiumClient.click_by_name(u'地铁',20),'无法找到地铁')
            if area=='yanggaozhonglu':
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/ditie/9haoxian.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/ditie/9haoxian/'+area+'.png')
            self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
            houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
            for house in houseList:
                self.assertTrue(house.houseDistance.count(u'9\u53f7\u7ebf') or lib.get_pinyin(house.houseDistance[1:house.houseDistance.find(u'\u7ad9')]).count(area),'地铁地铁错误')
    
    def test_subway_house_subway_line10(self):
        '''测试地铁房地铁10号线筛选'''
        logging.info('Step-1:点击地铁房')
        
        #过滤，'xitiandi','hongqiao2haohangzhanlou',
        areaList=['xinjiangwancheng','yingaodonglu','sanmenlu','jiangwantiyuchang','wujiaochang','guoquanlu',
        'tongjidaxue','sipinglu','youdianxincun','hailunlu','sichuanbeilu','tiantonglu','nanjingdonglu','yuyuan',
        'laoximen','shanxinanlu','shanghaitushuguan','jiaotongdaxue','hongqiaolu','songyuanlu','yililu',
        'shuichenglu','longxilu','shanghaidongwuyuan','hongqiao1haohangzhanlou','hongqiaohuochezhan',
        'longbaixincun','zitenglu','hangzhonglu']

        for area in areaList:
            self.assertTrue(self.appiumClient.click_by_name(u'地铁',20),'无法找到地铁')
            if area=='xinjiangwancheng':
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/ditie/10haoxian.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/ditie/10haoxian/'+area+'.png')
            self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
            houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
            for house in houseList:
                self.assertTrue(house.houseDistance.count(u'10\u53f7\u7ebf') or lib.get_pinyin(house.houseDistance[1:house.houseDistance.find(u'\u7ad9')]).count(area),'地铁地铁错误')
    
    def test_subway_house_subway_line11(self):
        '''测试地铁房地铁11号线筛选'''
        logging.info('Step-1:点击地铁房')
        
        #过滤,xujiahui,jiangsulu，shanghaisaichechang
        areaList=['kangxingonglu','xiuyanlu','luoshanlu','yuqiao','pusanlu','sanlindong','sanlin','dongfangtiyuzhongxin','longyaolu',
        'yunjinlu','shanghaiyouyongguan','jiaotongdaxue','longdelu','caoyanglu','fengqiaolu',
        'zhenru','shanghaixizhan','liziyuan','qilianshanlu','wuweilu','taopuxincun','nanxiang','malu','jiadingxincheng',
        'baiyinlu','jiadingxi','jiadingbei','changjidonglu','shanghaiqichecheng','anting']

        for area in areaList:
            self.assertTrue(self.appiumClient.click_by_name(u'地铁',20),'无法找到地铁')
            if area=='kangxingonglu':
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/ditie/11haoxian.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/ditie/11haoxian/'+area+'.png')
            self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
            houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
            for house in houseList:
                self.assertTrue(house.houseDistance.count(u'11\u53f7\u7ebf') or lib.get_pinyin(house.houseDistance[1:house.houseDistance.find(u'\u7ad9')]).count(area),'地铁地铁错误')

    def test_subway_house_subway_line12(self):
        '''测试地铁房地铁12号线筛选'''
        logging.info('Step-1:点击地铁房')
        
        #过滤
        areaList=['jinhailu','shenjianglu','jinjinglu','yanggaobeilu','jufenglu','donglulu','fuxingdao',
        'aiguolu','longchanglu','ningguolu','jiangpugongyuan','dalianlu','tilanqiao','guojikeyunzhongxin',
        'tiantonglu','quhulu','hanzhonglu','nanjingxilu','shanxinanlu','jiashanlu','damuqiaolu','longhuazhonglu',
        'longhua','longcaolu','caobaolu','guilingongyuan','hongcaolu','hongmeilu','donglanlu','gudailu','hongxinlu',
        'qixinlu']

        for area in areaList:
            self.assertTrue(self.appiumClient.click_by_name(u'地铁',20),'无法找到地铁')
            if area=='jinhailu':
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/ditie/12haoxian.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/ditie/12haoxian/'+area+'.png')
            self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
            houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
            for house in houseList:
                self.assertTrue(house.houseDistance.count(u'12\u53f7\u7ebf') or lib.get_pinyin(house.houseDistance[1:house.houseDistance.find(u'\u7ad9')]).count(area),'地铁地铁错误')

    def test_subway_house_subway_line13(self):
        '''测试地铁房地铁13号线筛选'''
        logging.info('Step-1:点击地铁房')
        
        #过滤,nanjingxilu,
        areaList=['jinyunlu','jinshajiangxilu','fengzhuang','qilianshannanlu','zhenbeilu','daduhelu','jinshajianglu',
        'longdelu','wuninglu','changshoulu','jiangninglu','hanzhonglu','ziranbowuguan','huaihaizhonglu',
        'xintiandi','madanglu','shibohuibowuguan','shibodadao']

        for area in areaList:
            self.assertTrue(self.appiumClient.click_by_name(u'地铁',20),'无法找到地铁')
            if area=='jinyunlu':
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/ditie/13haoxian.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/ditie/13haoxian/'+area+'.png')
            self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
            houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
            for house in houseList:
                self.assertTrue(house.houseDistance.count(u'13\u53f7\u7ebf') or lib.get_pinyin(house.houseDistance[1:house.houseDistance.find(u'\u7ad9')]).count(area),'地铁地铁错误')

    def test_subway_house_subway_line16(self):
        '''测试地铁房地铁16号线筛选'''
        logging.info('Step-1:点击地铁房')
  
        areaList=['dishuihu','lingangdadao','shuyuan','huinandong','huinan','yeshengdongwuyuan','xinchang','hangtoudong',
        'heshahangcheng','zhoupudong','luoshanlu','huaxiazhonglu','longyanglu']

        for area in areaList:
            self.assertTrue(self.appiumClient.click_by_name(u'地铁',20),'无法找到地铁')
            if area=='dishuihu':
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/ditie/16haoxian.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/ditie/16haoxian/'+area+'.png')
            self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
            houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
            for house in houseList:
                self.assertTrue(house.houseDistance.count(u'16\u53f7\u7ebf') or lib.get_pinyin(house.houseDistance[1:house.houseDistance.find(u'\u7ad9')]).count(area),'地铁地铁错误')
        
if __name__ == '__main__':
    suite=unittest.TestSuite()
    suite.addTest(SubwayHouseLocationTest('test_subway_house_subway_line1'))
    #suite.addTest(SubwayHouseLocationTest('test_subway_house_subway_line2'))
    #suite.addTest(SubwayHouseLocationTest('test_subway_house_subway_line3'))
    #suite.addTest(SubwayHouseLocationTest('test_subway_house_subway_line4'))
    #suite.addTest(SubwayHouseLocationTest('test_subway_house_subway_line5'))
    #suite.addTest(SubwayHouseLocationTest('test_subway_house_subway_line6'))
    #suite.addTest(SubwayHouseLocationTest('test_subway_house_subway_line7'))
    #suite.addTest(SubwayHouseLocationTest('test_subway_house_subway_line8'))
    #suite.addTest(SubwayHouseLocationTest('test_subway_house_subway_line9'))
    #suite.addTest(SubwayHouseLocationTest('test_subway_house_subway_line10'))
    #suite.addTest(SubwayHouseLocationTest('test_subway_house_subway_line11'))
    #suite.addTest(SubwayHouseLocationTest('test_subway_house_subway_line12'))
    #suite.addTest(SubwayHouseLocationTest('test_subway_house_subway_line13'))
    #suite.addTest(SubwayHouseLocationTest('test_subway_house_subway_line16'))
    runner = lib.HTMLTestRunner(stream='TestReport.html',title="Test Result",description='Test Suite')
    runner.run(suite)
    if ((runner.failure_count !=0) or (runner.error_count!=0)):
        raise Exception('Test Suite execute finished,Test suite failed...')
    