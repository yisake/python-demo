# -*- coding: utf-8 -*-
import unittest
import os
import sys
import logging
import time
import traceback
import platform
sys.path.append('../../..')
import lib
from testCase.AndroidTestCaseBaseClass import AndroidTestCaseBaseClass

class LoginTest(AndroidTestCaseBaseClass):
    '''测试登陆'''
    #Author Huangfu
    #Date 2015/12/2
    #Program:
    #    Test login to fangduo app on android
        
    def test_install_fangdd_on_android(self):
        '''测试安装apk，找到二手房'''
        logging.info('Step-1:打开房多多App')
        if os.environ.has_key('JENKINS_HOME'):
            self.InitAppiumClient(os.environ['apkPath'])
        else:
            self.InitAppiumClient(self.cf.apk_path)
        logging.info('Step-2:进入到主页')
        if self.appiumClient.wait_by_id('com.fangdd.mobile.fddhouseownersell:id/ll_page') is not None:
            self.AppiumLoginIn()
        
        if self.appiumClient.wait_by_id('com.fangdd.mobile.fddhouseownersell:id/iv'):
            self.appiumClient.app.click(self.image_path+'xiaoqu.png')        
        
        if self.appiumClient.wait_by_name(u'应用程序许可',30) is not None:
            self.appiumClient.click_by_name(u'确认')
        self.assertIsNotNone(self.appiumClient.wait_by_name(u'二手房'),'无法找到二手房')
        self.assertIsNotNone(self.appiumClient.wait_by_name(u'查房价'),'无法找到卖房')
        self.assertIsNotNone(self.appiumClient.wait_by_name(u'地图找房'),'无法找到地图找房')
        self.assertIsNotNone(self.appiumClient.wait_by_name(u'学区房'),'无法找到学区房')
        self.assertIsNotNone(self.appiumClient.wait_by_name(u'地铁房'),'无法找到地铁房')
    
    def test_change_test_env(self):
        logging.info('Step-1:打开房多多App')
        self.InitAppiumClient()
        
        #如果有jenkins环境变量，从环境变量获取
        if 'JENKINS_HOME' in os.environ:
            #如果包为正式包，则不切换环境
            if os.environ['PACKAGE_ENV']=='Formal':
                return
            else:
                var=os.environ['testEnv']
                if var=='test':
                    env=u'外网测试环境'
                elif 'formal':
                    env=u'正式环境'
                elif 'prePublish':
                    env=u'预发布环境'
                else:
                    env=u'正式环境'               
        else:
            if self.cf.test_env=='test':
                env=u'外网测试环境'
            elif 'formal':
                env=u'正式环境'
            elif 'prePublish':
                env=u'预发布环境'
            else:
                env=u'正式环境'
        logging.info('Step-2:点击我')
        self.assertTrue(self.appiumClient.click_by_name(u'我'),'无法点击看房按钮')
        logging.info('Step-3:点击关于')
        ele=self.appiumClient.swipe_to_element(element=u'关于',by='name')
        self.assertIsNotNone(ele,'无法点击看房按钮')        
        ele.click()
        logging.info('Step-4:长按切换环境')
        self.assertTrue(self.appiumClient.long_press_by_id('com.fangdd.mobile.fddhouseownersell:id/tv'),'')    
        self.assertTrue(self.appiumClient.click_by_name(env),'')
        self.assertTrue(self.appiumClient.click_by_name(u'确定'),'')
        
    def test_login_in_ui(self):
        '''测试登陆界面按钮'''
        logging.info('Step-1:打开房多多App')
        self.InitAppiumClient()
        logging.info('Step-2:点击看房，然后点击我')
        self.assertTrue(self.appiumClient.click_by_name(u'看房'),'无法点击看房按钮')
        self.assertIsNotNone(self.appiumClient.wait_by_name(u'登录'),'无法找到验证码登录')
        self.assertIsNotNone(self.appiumClient.wait_by_name(u'看房日程需要登录才能使用'),'无法找到验证码登录')
        self.assertTrue(self.appiumClient.click_by_name(u'我'),'无法点击我按钮')
        logging.info('Step-3:查看点击登录是否存在')
        self.assertTrue(self.appiumClient.click_by_name(u'点击登录'),'点击登录失败')
        logging.info('Step-4:点击登录查看验证码登录是否存在')
        self.assertIsNotNone(self.appiumClient.wait_by_name(u'验证码登录'),'无法找到验证码登录')
        self.assertIsNotNone(self.appiumClient.wait_by_name(u'请输入手机号'),'无法找到请输入手机号')
        #self.assertIsNotNone(self.appiumClient.wait_by_name(u'请输入短信验证码'),'无法找到请输入验证码')
        logging.info('Step-5:点击登录查看密码登录是否存在')
        self.assertTrue(self.appiumClient.click_by_name(u'密码登录'),'点击密码登录失败')
        self.assertIsNotNone(self.appiumClient.wait_by_name(u'请输入手机号'),'无法找到请输入手机号')
        #self.assertIsNotNone(self.appiumClient.wait_by_name(u'请输入密码'),'无法找到请输入密码')

    def test_login_in_with_wrong_string(self):
        logging.info('Step-1:打开房多多App')
        self.InitAppiumClient()
        logging.info('Step-2:点击我')
        self.assertTrue(self.appiumClient.click_by_name(u'我'),'点击我失败')
        logging.info('Step-3:查看点击登录是否存在')
        self.assertTrue(self.appiumClient.click_by_name(u'点击登录'),'点击登录失败')
        logging.info('Step-4:点击密码登录')
        self.assertTrue(self.appiumClient.click_by_name(u'密码登录'),'点击密码登陆失败')
        ele=self.appiumClient.wait_by_name(u'请输入手机号')
        self.assertTrue(self.appiumClient.enter(ele,'abcd'),'无法输入字母')
        self.assertIsNotNone(self.appiumClient.wait_by_name(u'请输入手机号'),'无法找到请输入手机号')
        self.assertTrue(self.appiumClient.enter(ele,'*?;:[]'),'无法输入符号')
        self.assertIsNotNone(self.appiumClient.wait_by_name(u'请输入手机号'),'无法找到请输入手机号')
        
    def test_login_in_with_wrong_username(self):    
        logging.info('Step-1:打开房多多App')
        self.InitAppiumClient()
        logging.info('Step-2:点击我')
        self.assertTrue(self.appiumClient.click_by_name(u'我'),'点击我失败')
        logging.info('Step-3:点击密码登陆')
        self.assertTrue(self.appiumClient.click_by_name(u'点击登录'),'点击登录失败')
        self.assertTrue(self.appiumClient.click_by_name(u'密码登录'),'点击密码登陆失败')
        logging.info('Step-4:输入错误用户名密码')
        elePhone=self.appiumClient.wait_by_name(u'请输入手机号')
        #elePasswd=self.appiumClient.wait_by_name(u'请输入密码')
        self.assertTrue(self.appiumClient.enter(elePhone,'10000000000'),'无法输入字母')
        self.assertTrue(self.appiumClient.click_by_name(u'登录'),'无法登录')
        self.assertIsNotNone(self.appiumClient.wait_by_name(u'登录'),'登录失败')
        #self.assertTrue(self.appiumClient.enter(ele,'123456'),'无法输入字母')
        
    def test_login_in_with_wrong_password(self):
        logging.info('Step-1:打开房多多App')
        self.InitAppiumClient()
        logging.info('Step-2:点击我')
        self.assertTrue(self.appiumClient.click_by_name(u'我'),'点击我失败')
        logging.info('Step-3:点击密码登陆')
        self.assertTrue(self.appiumClient.click_by_name(u'点击登录'),'点击登录失败')
        self.assertTrue(self.appiumClient.click_by_name(u'密码登录'),'点击密码登陆失败')        
        elePhone=self.appiumClient.wait_by_name(u'请输入手机号')
        #elePasswd=self.appiumClient.wait_by_name(u'请输入密码')
        #logging.info('Step-4:')
        #elePhone.send_keys(self.cf.buyer_phone)        
        #elePasswd.send_keys('*******')
        #self.assertTrue(self.appiumClient.click_by_name(u'登录'),'点击登录失败')
        #self.assertIsNotNone(self.appiumClient.wait_by_name(u'登录'),'登录已经不显示')
        
    def test_kan_fang_login_page(self):
        '''测试看房登录页'''
        logging.info('Step-1:打开房多多App')
        self.InitAppiumClient()
        logging.info('Step-2:测试看房页登录页面是否正确')        
        self.assertTrue(self.appiumClient.click_by_name(u'看房'),'点击失败')
        self.assertTrue(self.appiumClient.click_by_name(u'登录'),'点击失败')
        self.assertTrue(self.appiumClient.app.safeWait(self.image_path+'denglu.png'),'未显示登录页面')
    
    
if __name__ == '__main__':
    suite=unittest.TestSuite()
    suite.addTest(LoginTest('test_change_test_env'))
    runner = lib.HTMLTestRunner(stream='TestReport.html',title="Test Result",description='Test Suite')
    runner.run(suite)        