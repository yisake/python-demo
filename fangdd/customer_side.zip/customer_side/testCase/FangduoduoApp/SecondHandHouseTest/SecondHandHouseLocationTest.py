#coding=utf8
import unittest
import os
import sys
import logging
import time
import traceback
import platform
sys.path.append('../../..')
import lib
import MySQLdb
from testCase.AndroidTestCaseBaseClass import AndroidTestCaseBaseClass

class SecondHandHouseLocationTest(AndroidTestCaseBaseClass):
    '''二手房列表排序测试集'''
        
    @classmethod
    def setUpClass(cls):
        AndroidTestCaseBaseClass.classInitAppiumClient()
        
    @classmethod
    def tearDownClass(cls):  
        cls.appiumClient.stop_driver()
    
    def tearDown(self):
        self.conn.close()
        self.tearDownStep()
    
    def back_to_home_page(self):
        self.appiumClient.click_by_id('com.fangdd.mobile.fddhouseownersell:id/back_button')
    
    def back_to_second_house_list_page(self):
        self.appiumClient.click_by_id('com.fangdd.mobile.fddhouseownersell:id/iv_back')
    
    def clear_area(self):        
        if self.appiumClient.wait_by_id('com.fangdd.mobile.fddhouseownersell:id/close_view') is not None:
            self.appiumClient.click_by_id('com.fangdd.mobile.fddhouseownersell:id/close_view')
    

    def filter_test(self,area_list,area='minhang',ch_name=u'闵行'):
        self.connet_to_mysql()
        i=0
        for item in area_list:
            self.appiumClient.app.click(self.image_path+'weizhi.png')
            if i==0:
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu.png')
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/'+area+'.png')
            i=i+1
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/'+area+'/'+item+'.png')
            self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
            listView=self.appiumClient.get_all_house_source_element_from_second_hand_house()    
            for i in listView:
                self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'weizhi.png'))
                i.houseName.click()
                logging.info('Start to test the area:'+item)
                self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/weizhi/quyu/louceng.png'))
                house_id=self.appiumClient.wait_by_id('com.fangdd.mobile.fddhouseownersell:id/activity_house_detail_base_info_code').text
                section_id,district_id=self.get_section_district_from_house_id(house_id)
                result=self.get_section_district_name_from_id(section_id,district_id)
                self.assertEqual(result,ch_name+area_list[item],'')
                self.back_to_second_house_list_page()    
        
    def get_section_district_from_house_id(self,house_id):        
        cur=self.conn.cursor()
        #print house_id
        cur.execute('select section_id,district_id from fdd_second_house.estate_draft where estate_id='+house_id)
        result=cur.fetchall()
        
        #print result
        cur.close()
        return result[0][0],result[0][1]
    
    def get_section_district_name_from_id(self,section_id,destrict_id):
        cur=self.conn.cursor()
        cur.execute('select alias_name from fdd_second_basic.t_second_district where district_id='+str(destrict_id))
        district = cur.fetchall()
        
        cur.execute('select alias_name from fdd_second_basic.t_second_section where section_id='+str(section_id))
        section = cur.fetchall()
        
        #print district[0][0]+section[0][0]
        #print type(district[0][0]+section[0][0])
        cur.close()
        return district[0][0]+section[0][0]
    
    def switch_to_jiading(self):
        if self.repeat_index == 0:
            self.appiumClient.app.click(self.image_path+'weizhi.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/jiading.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/jiading/fengzhuang.png')        

    def switch_to_qingpu(self):
        if self.repeat_index == 0:
            self.appiumClient.app.click(self.image_path+'weizhi.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/qingpu.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/qingpu/xujing.png')        

        
    def test_second_house_location_area_baoshan(self):
        '''测试位置宝山区域筛选''' 
        logging.info('Step-1:点击二手房')
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')        
        
        logging.info('清楚筛选条件')
        self.clear_area()        
        
        logging.info('测试筛选位置宝山')
        area_list = {'dahua':u'大华' }
        
        # Commit by 春峰:2016.7.1，只运行宝山大华
        #area_list=['dahua','dachangzhen','gucun','gongkang','luodian','luojing','shangda','yuepu','yangxing','songbao',
        #            'zhangmiao','gaojing','gongfu','songnan','tonghe','sitang']
        self.filter_test(area_list=area_list, area='baoshan', ch_name=u'宝山')
        
        self.back_to_home_page()
            
    def test_second_house_location_area_minhang(self):
        '''测试位置闵行区域筛选'''        
        logging.info('测试筛选位置:闵行')
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')
        
        logging.info('清楚筛选条件')
        self.clear_area()
                
        area_list = {'gumeiluoyang' : u'古美'}        
        # Commit by 春峰:2016.7.1
        #area_list=['gumeiluoyang','hanghua','jinhuilongbai','jinganxincheng','pujiangzhen','jiangchuan','huacao','jinhongqiao','meilongchunshen','maqiao',
        #'qibao','wujing','xinzhuang','zhuanqiao']
        
        self.filter_test(area_list=area_list, area='minhang', ch_name=u'闵行')
                                        
        self.back_to_home_page()
                
    def test_second_house_location_area_pudong(self):
        '''测试位置区域筛选浦东'''
        logging.info('筛选位置:浦东')
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')
        
        logging.info('清楚筛选条件')
        self.clear_area()
                
        area_list = {'biyun' : u'碧云'}
        # Commit by 春峰:2016.7.1
        #area_list=['biyun','caolu','chuansha','gaohang','hangtou','huinan','jinqiao','lianyang','lingangxincheng','sanlin','shijigongyuan','tangqiao','tangzhen','yuanshen','zhangjiang','beicai','waigaoqiao','jinyang','kangqiao','nanmatou',
        #'shibobinjiang','weifang','yangdong','yangjing','zhoupu','huamu','lujiazui','shangnan','yuqiao','meiyuan']
        
        self.filter_test(area_list=area_list, area='pudong', ch_name=u'浦东')
                                        
        self.back_to_home_page()     
        
    def test_second_house_location_area_songjiang(self):
        '''测试位置区域筛选松江'''
        logging.info('筛选位置，松江')
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')
        
        logging.info('清楚筛选条件')
        self.clear_area()
                
        area_list = {'nanjiuting':u'九亭'}
        #area_list=['nanjiuting','songjiangxincheng','sijing','sheshan','songjianglaocheng','xinqiao','xinmin','songjiangdaxuecheng',
        #'songjiangqita','xiaokunshan','beijiuting']

        self.filter_test(area_list=area_list, area='songjiang', ch_name=u'松江')
                                       
        self.back_to_home_page() 
        
    def test_second_house_location_area_yangpu(self):
        '''测试位置区域筛选杨浦'''
        logging.info('Step-3:测试区域筛选杨浦')
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')
        area_list = {'anshan':u'鞍山' }
        
        logging.info('清楚筛选条件')
        self.clear_area()        
        #Commit by:春峰 
        #area_list=['anshan','dongwaitan','huangxinggongyuan','kongjiang','wujiaochang','xinjiangwancheng',
        #           'zhongyuan','jiangpulu']
        
        self.filter_test(area_list=area_list, area='yangpu', ch_name=u'杨浦')
                                        
        self.back_to_home_page()
            
    def test_second_house_location_area_putuo(self):    
        '''测试位置区域普陀'''
        logging.info('筛选位置普陀')        
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')
        
        logging.info('清楚筛选条件')
        self.clear_area()        
        
        area_list = {'changfeng' : u'长风' }        
        #Commit by春峰
        #area_list=['changfeng','changzheng','guangxin','taopu','wuning','wanli','zhenru','ganquanyichuan','zhongyuanliangwancheng','changshoulu','caoyang']        
        
        self.filter_test(area_list=area_list, area='putuo', ch_name=u'普陀')
                                             
        self.back_to_home_page()
            
    def test_second_house_location_area_jiading(self):
        '''测试位置区域嘉定'''
        logging.info('筛选位置嘉定')
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')
        
        logging.info('清楚筛选条件')
        self.clear_area()        
        
        area_list = {'fengzhuang' : u'丰庄'}
        #area_list=['fengzhuang','jiangqiao','jiadingxincheng','nanxiang','anting','jiadingchengqu','malu','jiadingbeibu']
        
        self.filter_test(area_list=area_list, area='jiading', ch_name=u'嘉定')
                                       
        self.back_to_home_page()
        
    def test_second_house_location_area_xuhui(self):                
        '''测试位置区域徐汇'''
        logging.info('筛选位置徐汇')
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')
        
        logging.info('清楚筛选条件')
        self.clear_area()
        
        area_list={'nanzhan':u'南站'}
        #area_list=['nanzhan','longhua','changqiao','huadongligong','huajing','kangjian','tianlin','wantiguan',
        #           'xuhuibinjiang','xujiahui','zhiwuyuan','damuqiao','huaihaibei','huaihainan']     
        
        logging.info('清楚筛选条件')
        self.switch_to_jiading()
        
        logging.info('清楚筛选条件')      
        self.filter_test(area_list=area_list,area='xuhui',ch_name=u'徐汇')
        
        logging.info('清楚筛选条件')
        self.back_to_home_page()
            
    def test_second_house_location_area_zhabei(self):
        '''测试位置区域闸北'''
        logging.info('筛选位置闸北')
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')

        logging.info('清楚筛选条件')
        self.clear_area()
        
        area_list={'buyecheng':u'不夜城'}
        #area_list=['nanzhan','longhua','changqiao','huadongligong','huajing','kangjian','tianlin','wantiguan',
        #           'xuhuibinjiang','xujiahui','zhiwuyuan','damuqiao','huaihaibei','huaihainan']     
        
        logging.info('清楚筛选条件')
        self.switch_to_jiading()
        
        logging.info('清楚筛选条件')      
        self.filter_test(area_list=area_list,area='zhabei',ch_name=u'闸北')
                                     
        self.back_to_home_page()

    def test_second_house_location_area_fengxian(self):                
        '''测试位置区域奉贤'''
        logging.info('筛选位置奉贤')
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')

        logging.info('清楚筛选条件')
        self.clear_area()
        
        area_list={'fengcheng':u'奉城'}
        #area_list=['fengcheng','haiwan','nanqiao','zhuanghang','tuolin','fengxianqita','haiwanlvyouqu','jinhuizhen','xidu']
        
        logging.info('清楚筛选条件')
        self.switch_to_jiading()
        
        logging.info('清楚筛选条件')      
        self.filter_test(area_list=area_list,area='fengxian',ch_name=u'奉贤')
                                
        self.back_to_home_page()
    
    def test_second_house_location_area_hongkou(self):
        '''测试位置区域虹口'''
        logging.info('筛选位置虹口')
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')
        
        logging.info('清楚筛选条件')
        self.clear_area()
                
        area_list={'beiwaitan':u'北外滩'}
        #area_list=['beiwaitan','linping','jiangwanliangcheng','quyang','sichuanbeilu','sipinglu','guangzhong']
        logging.info('清楚筛选条件')
        self.switch_to_jiading()
        
        logging.info('清楚筛选条件')      
        self.filter_test(area_list=area_list,area='hongkou',ch_name=u'虹口')                   
        self.back_to_home_page()

    def test_second_house_location_area_jinshan(self):                
        '''测试位置区域金山'''
        logging.info('筛选位置金山')
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')
        
        logging.info('清楚筛选条件')
        self.clear_area()

        area_list={'jinshanxincheng':u'金山新城'}
        #area_list=['jinshanxincheng','shihua','tinglin','zhujing','jinshanqita','fengjing']
                
        logging.info('清楚筛选条件')
        self.switch_to_jiading()
        
        logging.info('清楚筛选条件')      
        self.filter_test(area_list=area_list,area='jinshan',ch_name=u'金山') 
                                        
        self.back_to_home_page()

    def test_second_house_location_area_qingpu(self):                
        '''测试位置区域青浦'''
        logging.info('筛选位置青浦')
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')
        
        logging.info('清楚筛选条件')
        self.clear_area()

        area_list={'xujing':u'徐泾'}
        #area_list=['xujing','zhujiajiao','zhaoxiang','huaxin','chonggu','qingpuchengqu','huqingping','baihe']

        logging.info('清楚筛选条件')
        self.switch_to_jiading()
        
        logging.info('清楚筛选条件')      
        self.filter_test(area_list=area_list,area='qingpu',ch_name=u'青浦') 
                                    
        self.back_to_home_page()

    def test_second_house_location_area_changning(self):                
        '''测试位置区域长宁'''
        logging.info('筛选位置长宁')
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')
        
        logging.info('清楚筛选条件')
        self.clear_area()
        
        area_list={'beixinjing':u'北新泾'}
        #area_list=['beixinjing','gubei','hongqiao','tianshan','xijiao','xianxia','xinhualu','zhenninglu','zhongshangongyuan']
        
        logging.info('清楚筛选条件')
        self.switch_to_jiading()
        self.switch_to_qingpu()
        
        logging.info('清楚筛选条件')      
        self.filter_test(area_list=area_list,area='changning',ch_name=u'长宁')                                
        self.back_to_home_page()

    def test_second_house_location_area_jingan(self):
        '''测试位置区域静安'''
        logging.info('筛选位置静安')
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')

        logging.info('清楚筛选条件')
        self.clear_area()
        
        area_list={'caojiadu':u'曹家渡'}
        #area_list=['caojiadu','jiangninglu','jingansi','nanjingxilu']
        
        logging.info('清楚筛选条件')
        self.switch_to_jiading()
        self.switch_to_qingpu()
        
        logging.info('清楚筛选条件')      
        self.filter_test(area_list=area_list,area='jingan',ch_name=u'静安')                                 
        self.back_to_home_page()

    def test_second_house_location_area_chongming(self):
        '''测试位置区域崇明'''
        logging.info('筛选位置崇明')
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')

        logging.info('清楚筛选条件')
        self.clear_area()
        
        area_list={'chongming' : u'崇明'}
        
        logging.info('清楚筛选条件')
        self.switch_to_jiading()
        self.switch_to_qingpu()        
        
        logging.info('清楚筛选条件')      
        self.filter_test(area_list=area_list,area='chongming',ch_name=u'崇明')                                
        self.back_to_home_page()

    def test_second_house_location_area_huangpu(self):
        '''测试位置区域黄埔'''
        logging.info('筛选位置黄埔')
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')
        
        logging.info('清楚筛选条件')
        self.clear_area()        
        
        area_list={'dapuqiao': u'打浦桥'}
        #area_list=['dapuqiao','xintiandi','dongjiadu','laoximen','nanjingdonglu','renminguangchang',
        #           'yuyuan','penglaigongyuan','xietulu','beisuzhouhe','shanxilu','waitan','huangpubinjiang']
        
        logging.info('清楚筛选条件')
        self.switch_to_jiading()
        self.switch_to_qingpu()        
        
        logging.info('清楚筛选条件')      
        self.filter_test(area_list=area_list,area='huangpu',ch_name=u'黄浦')                               
        self.back_to_home_page()
                
class SecondHandHouseLocationTestSubWay(SecondHandHouseLocationTest):
    '''测试二手房位置地铁'''
    def tearDown(self):
        self.tearDownStep()    
    
    def switch_to_lin7(self):
        self.appiumClient.app.click(self.image_path+'weizhi.png')
        self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/ditie.png')
        self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/ditie/7haoxian.png')
        self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/ditie/7haoxian/huamulu.png')
                                    
    def filter_subway_test(self,areaList={'fujinlu':u'富锦路'},subway='1haoxian',ch_name=u'1号线'):
        i=0
        for area in areaList:
            self.appiumClient.app.click(self.image_path+'weizhi.png')
            if i==0:
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/ditie.png')       
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/ditie/'+subway+'.png')
            i=i+1
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/ditie/'+subway+'/'+area+'.png')
            self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
            houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
            for house in houseList:
                self.assertTrue(house.houseDistance.find(ch_name)!=-1,'地铁位置错误')
    
    def test_second_house_subway_line1(self):
        '''测试二手房地铁1号线筛选'''
        logging.info('Step-1:点击二手房')
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')
        
        self.clear_area()
        #过滤,shanxinanlu,renminguangchang,changshulu,xujiahui,jinjiangleyuan,shanghaihuochezhan,
        
        areaList = {'fujinlu':u'富锦路'}
        #areaList=['fujinlu','youyixilu','baoangonglu','gongfuxincun','hulanlu','tonghexincun','gongkanglu',
        #'pengpuxincun','wenshuilu','shanghaimaxicheng','yanchanglu','zhongshanbeilu',
        #'hanzhonglu','xinzhalu','huangpinanlu','hengshanlu','caobaolu','shanghainanzhan','lianhualu','waihuanlu','xinzhuang']
        
        self.filter_subway_test(areaList=areaList,subway='1haoxian',ch_name=u'1号线')
        
        self.back_to_home_page()
        
    def test_second_house_subway_line2(self):
        '''测试二手房地铁2号线筛选'''
        logging.info('Step-1:点击二手房')
        
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')        
        self.clear_area()
        
        areaList= {'pudongguojijichang':u'浦东国际机场'}
        #areaList=['pudongguojijichang','haitiansanlu','yuandongdadao','lingkonglu','chuansha','huaxiadonglu',
        #'chuangxinzhonglu','tangzhen','guanglanlu','jinkelu','zhangjianggaoke','shijigongyuan','shanghaikejiguan',
        #'shijidadao','dongchanglu','lujiazui','nanjingdonglu','jingansi','jiangsulu','loushanguanlu',
        #'weininglu','beixinjing','songhonglu','hongqiao2haohangzhanlou','hongqiaohuochezhan','xujingdong']
        
        self.filter_subway_test(areaList=areaList,subway='2haoxian',ch_name=u'2号线')
        
        self.back_to_home_page()
        
    def test_second_house_subway_line3(self):
        '''测试二手房地铁3号线筛选'''
        logging.info('Step-1:点击二手房')        
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')
        self.clear_area()
        
        #过滤,shanghainanzhan,longcaolu,zhongshangongyuan,hongkouzuqiuchang,
        areaList={'shilonglu':u'石龙路'}
        #areaList=['shilonglu','caoxilu','yishanlu','hongqiaolu','yananxilu',
        #'jinshajianglu','caoyanglu','zhenpinglu','zhongtanlu','shanghaihuochezhan','baoshanlu',
        #'dongbaoxinglu','chifenglu','dabaishu','jiangwanzhen','yingaoxilu','changjiangnanlu','songfalu','zhanghuabang',
        #'songbinlu','shuichanlu','baoyanglu','youyilu','tielilu','jiangyangbeilu']

        self.filter_subway_test(areaList=areaList,subway='3haoxian',ch_name=u'3号线')
        
        self.back_to_home_page()

    def test_second_house_subway_line4(self):
        '''测试二手房地铁4号线筛选'''
        logging.info('Step-1:点击二手房')
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')
        self.clear_area()
        
        #过滤'pudianlu','zhenpinglu','caoyanglu','zhongshangongyuan',
        areaList={'yishanlu':u'宜山路'}
        #areaList=['yishanlu','shanghaitiyuguan','shanghaitiyuchang','donganlu','damuqiaolu','lubanlu','xizangnanlu',
        #'nanpudaqiao','tangqiao','lancunlu','shijidadao','pudongdadao','yangshupulu','dalianlu',
        #'linpinglu','hailunlu','baoshanlu','shanghaihuochezhan','zhongtanlu','jinshajianglu','yananxilu','hongqiaolu']

        self.filter_subway_test(areaList=areaList,subway='4haoxian',ch_name=u'4号线')
        
        self.back_to_home_page()
            
    def test_second_house_subway_line5(self):
        '''测试二手房地铁5号线筛选'''
        logging.info('Step-1:点击二手房')
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')
        self.clear_area()
                
        areaList={'xinzhuang':u'莘庄'}
        #areaList=['xinzhuang','chunshenlu','yindulu','zhuanqiao','beiqiao','jianchuanlu','dongchuanlu',
        #'jinpinglu','huaninglu','wenjinglu','minhangkaifaqu']

        self.filter_subway_test(areaList=areaList,subway='5haoxian',ch_name=u'5号线')
        
        self.back_to_home_page()
            
    def test_second_house_subway_line6(self):
        '''测试二手房地铁6号线筛选'''
        logging.info('Step-1:点击二手房')
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')
        self.clear_area()
        
        #过滤'pudianlu','dongfangtiyuzhongxin'
        areaList={'gangchenglu':u'港城路'}
        #areaList=['gangchenglu','waigaoqiaobaoshuiqubei','hangjinlu','waigaoqiaobaoshuiqunan','zhouhailu',
        #'wuzhoudadao','dongjinglu','jufenglu','wulianlu','boxinglu','jinqiaolu','yunshanlu','depinglu',
        #'beiyangjinglu','minshenglu','yuanshentiyuzhongxin','shijidadao','lancunlu','shanghaiertongyixuezhongxin',
        #'linyixincun','gaokexilu','dongminglu','gaoqinglu','huaxiaxilu','shangnanlu','lingyannanlu']
        
        self.filter_subway_test(areaList=areaList,subway='6haoxian',ch_name=u'6号线')
        
        self.back_to_home_page()
                
    def test_second_house_subway_line7(self):
        '''测试二手房地铁7号线筛选'''
        logging.info('Step-1:点击二手房')
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')
        self.clear_area()
        
        #过滤,changshulu,
        areaList={'huamulu':u'花木路'}
        #areaList=['huamulu','longyanglu','fanghualu','jinxiulu','yanggaonanlu','gaokexilu','yuntailu',
        #'yaohualu','changqinglu','houtan','longhuazhonglu','donganlu','zhaojibanglu','jingansi',
        #'changpinglu','changshoulu','zhenpinglu','langaolu','xincunlu','dahuasanlu','xingzhilu','dachangzhen',
        #'changzhonglu','shangdalu','nanchenlu','shanghaidaxue','gucungongyuan','liuhang','panguanglu','luonanxincun',
        #'meilanhu']
        self.filter_subway_test(areaList=areaList,subway='7haoxian',ch_name=u'7号线')
        
        self.back_to_home_page()
               
    def test_second_house_subway_line8(self):
        '''测试二手房地铁8号线筛选'''
        logging.info('Step-1:点击二手房')
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')
        self.clear_area()
        
        areaList={'shendugonglu':u'沈杜公路'}
        #areaList=['shendugonglu','lianhanglu','jiangyuelu','pujiangzhen','luhenglu','lingzhaoxincun','yangsi',
        #'chengshanlu','yaohualu','zhonghuayishugong','xizangnanlu','lujiabanglu','laoximen','dashijie','renminguangchang',
        #'quhulu','zhongxinglu','xizangbeilu','hongkouzuqiuchang','quyanglu','sipinglu','anshanxincun','jiangpulu','huangxinglu',
        #'yanjizhonglu','huangxinggongyuan','xiangyinlu','nenjianglu','shiguanglu']
        
        self.switch_to_lin7()
        self.filter_subway_test(areaList=areaList,subway='8haoxian',ch_name=u'8号线')
        
        self.back_to_home_page()
               
    def test_second_house_subway_line9(self):
        '''测试二手房地铁9号线筛选'''
        logging.info('Step-1:点击二手房')
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')
        self.clear_area()
        
        #过滤，'xujiahui',yishanlu,
        areaList={'yanggaozhonglu':u'杨高中路'}
        #areaList=['yanggaozhonglu','shijidadao','shangchenglu','xiaonanmen','lujiabanglu','madanglu','dapuqiao','jiashanlu',
        #'zhaojiabanglu','guilinlu','caohejingkaifaqu','hechuanlu','xingzhonglu','qibao','zhongchunlu',
        #'jiuting','sijing','sheshan','dongjing','songjiangdaxuecheng','songjiangxincheng','songjiangtiyuzhongxin',
        #'zuibaichi','songjiangnanzhan']
        
        self.switch_to_lin7()
        self.filter_subway_test(areaList=areaList,subway='9haoxian',ch_name=u'9号线')
        
        self.back_to_home_page()
             
    def test_second_house_subway_line10(self):
        '''测试二手房地铁10号线筛选'''
        logging.info('Step-1:点击二手房')
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')
        self.clear_area()
        
        #过滤，'xitiandi','hongqiao2haohangzhanlou',
        areaList={'xinjiangwancheng':u'新江湾城'}
        #areaList=['xinjiangwancheng','yingaodonglu','sanmenlu','jiangwantiyuchang','wujiaochang','guoquanlu',
        #'tongjidaxue','sipinglu','youdianxincun','hailunlu','sichuanbeilu','tiantonglu','nanjingdonglu','yuyuan',
        #'laoximen','shanxinanlu','shanghaitushuguan','jiaotongdaxue','hongqiaolu','songyuanlu','yililu',
        #'shuichenglu','longxilu','shanghaidongwuyuan','hongqiao1haohangzhanlou','hongqiaohuochezhan',
        #'longbaixincun','zitenglu','hangzhonglu']
        
        self.switch_to_lin7()
        self.filter_subway_test(areaList=areaList,subway='10haoxian',ch_name=u'10号线')
        
        self.back_to_home_page()
            

    def test_second_house_subway_line11(self):
        '''测试二手房地铁11号线筛选'''
        logging.info('Step-1:点击二手房')
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')
        self.clear_area()
        
        #过滤,xujiahui,jiangsulu，shanghaisaichechang
        areaList={'kangxingonglu':u'康新公路'}
        #areaList=['kangxingonglu','xiuyanlu','luoshanlu','yuqiao','pusanlu','sanlindong','sanlin','dongfangtiyuzhongxin','longyaolu',
        #'yunjinlu','shanghaiyouyongguan','jiaotongdaxue','longdelu','caoyanglu','fengqiaolu',
        #'zhenru','shanghaixizhan','liziyuan','qilianshanlu','wuweilu','taopuxincun','nanxiang','malu','jiadingxincheng',
        #'baiyinlu','jiadingxi','jiadingbei','changjidonglu','shanghaiqichecheng','anting']
        
        self.switch_to_lin7()
        self.filter_subway_test(areaList=areaList,subway='11haoxian',ch_name=u'11号线')
        
        self.back_to_home_page()
            

    def test_second_house_subway_line12(self):
        '''测试二手房地铁12号线筛选'''
        logging.info('Step-1:点击二手房')
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')
        self.clear_area()
        
        #过滤,nanjingxilu,shanxinanlu,
        areaList={'jinhailu':u'金海路'}
        #areaList=['jinhailu','shenjianglu','jinjinglu','yanggaobeilu','jufenglu','donglulu','fuxingdao',
        #'aiguolu','longchanglu','ningguolu','jiangpugongyuan','dalianlu','tilanqiao','guojikeyunzhongxin',
        #'tiantonglu','quhulu','hanzhonglu','jiashanlu','damuqiaolu','longhuazhonglu',
        #'longhua','longcaolu','caobaolu','guilingongyuan','hongcaolu','hongmeilu','donglanlu','gudailu','hongxinlu',
        #'qixinlu']
        
        self.switch_to_lin7()
        self.filter_subway_test(areaList=areaList,subway='12haoxian',ch_name=u'12号线')
        
        self.back_to_home_page()
            
    def test_second_house_subway_line13(self):
        '''测试二手房地铁13号线筛选'''
        logging.info('Step-1:点击二手房')
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')
        self.clear_area()
        
        #过滤,nanjingxilu,
        areaList={'jinyunlu':u'金运路'}
        #areaList=['jinyunlu','jinshajiangxilu','fengzhuang','qilianshannanlu','zhenbeilu','daduhelu','jinshajianglu',
        #'longdelu','wuninglu','changshoulu','jiangninglu','hanzhonglu','ziranbowuguan','huaihaizhonglu',
        #'xintiandi','madanglu','shibohuibowuguan','shibodadao']
        self.switch_to_lin7()
        self.filter_subway_test(areaList=areaList,subway='13haoxian',ch_name=u'13号线')
        
        self.back_to_home_page()
            
    def test_second_house_subway_line16(self):
        '''测试二手房地铁16号线筛选'''
        logging.info('Step-1:点击二手房')
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')
        self.clear_area()
        
        areaList={'dishuihu':u'滴水湖'}
        #areaList=['dishuihu','lingangdadao','shuyuan','huinandong','huinan','yeshengdongwuyuan','xinchang','hangtoudong',
        #'heshahangcheng','zhoupudong','luoshanlu','longyanglu']
        self.switch_to_lin7()
        self.filter_subway_test(areaList=areaList,subway='16haoxian',ch_name=u'16号线')
        
        self.back_to_home_page()
            

if __name__ == '__main__':
    suite=unittest.TestSuite()
    
    #位置区域筛选用例
    #suite.addTest(SecondHandHouseLocationTest('test_second_house_location_area_baoshan'))
    #suite.addTest(SecondHandHouseLocationTest('test_second_house_location_area_minhang'))
    #suite.addTest(SecondHandHouseLocationTest('test_second_house_location_area_pudong'))
    #suite.addTest(SecondHandHouseLocationTest('test_second_house_location_area_songjiang'))
    #suite.addTest(SecondHandHouseLocationTest('test_second_house_location_area_yangpu'))
    #suite.addTest(SecondHandHouseLocationTest('test_second_house_location_area_putuo'))
    #suite.addTest(SecondHandHouseLocationTest('test_second_house_location_area_jiading'))
    suite.addTest(SecondHandHouseLocationTest('test_second_house_location_area_xuhui'))    
    #suite.addTest(SecondHandHouseLocationTest('test_second_house_location_area_zhabei'))
    #suite.addTest(SecondHandHouseLocationTest('test_second_house_location_area_fengxian'))
    #suite.addTest(SecondHandHouseLocationTest('test_second_house_location_area_hongkou'))
    #suite.addTest(SecondHandHouseLocationTest('test_second_house_location_area_jinshan'))
    #suite.addTest(SecondHandHouseLocationTest('test_second_house_location_area_qingpu'))
    #suite.addTest(SecondHandHouseLocationTest('test_second_house_location_area_changning'))
    #suite.addTest(SecondHandHouseLocationTest('test_second_house_location_area_jingan'))
    #suite.addTest(SecondHandHouseLocationTest('test_second_house_location_area_chongming'))
    #suite.addTest(SecondHandHouseLocationTest('test_second_house_location_area_huangpu'))
    
    #地铁房测试用例集
    #suite.addTest(SecondHandHouseLocationTestSubWay('test_second_house_subway_line1'))    
    #suite.addTest(SecondHandHouseLocationTestSubWay('test_second_house_subway_line2'))
    #suite.addTest(SecondHandHouseLocationTestSubWay('test_second_house_subway_line3'))
    #suite.addTest(SecondHandHouseLocationTestSubWay('test_second_house_subway_line4'))
    #suite.addTest(SecondHandHouseLocationTestSubWay('test_second_house_subway_line5'))
    #suite.addTest(SecondHandHouseLocationTestSubWay('test_second_house_subway_line6'))
    #suite.addTest(SecondHandHouseLocationTestSubWay('test_second_house_subway_line7'))
    #suite.addTest(SecondHandHouseLocationTestSubWay('test_second_house_subway_line8'))
    #suite.addTest(SecondHandHouseLocationTestSubWay('test_second_house_subway_line9'))
    #suite.addTest(SecondHandHouseLocationTestSubWay('test_second_house_subway_line10'))
    #suite.addTest(SecondHandHouseLocationTestSubWay('test_second_house_subway_line11'))
    #suite.addTest(SecondHandHouseLocationTestSubWay('test_second_house_subway_line12'))
    #suite.addTest(SecondHandHouseLocationTestSubWay('test_second_house_subway_line13'))
    #suite.addTest(SecondHandHouseLocationTestSubWay('test_second_house_subway_line16'))
    runner = lib.HTMLTestRunner(stream='TestReport.html',title="Test Result",description='Test Suite')
    runner.run(suite)
    if ((runner.failure_count !=0) or (runner.error_count!=0)):
        raise Exception('Test Suite execute finished,Test suite failed...')
    