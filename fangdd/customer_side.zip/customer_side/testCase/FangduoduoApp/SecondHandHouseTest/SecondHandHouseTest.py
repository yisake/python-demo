#coding=utf8
import unittest
import os
import sys
import logging
import time
import traceback
import platform
sys.path.append('../../..')
import lib
from testCase.AndroidTestCaseBaseClass import AndroidTestCaseBaseClass

class SecondHandHouseTest(AndroidTestCaseBaseClass):
    '''二手房业务测试集'''
    #Author Huangfu
    #Date 2015/12/2
    #Program:
    #    Test second hand house
    # @classmethod
    # def classLoadConfig(cls):
    #     '''Integrate to jenkins,if exists the environment varible,set the config file with the value'''
    #     if os.environ.has_key('JENKINS_HOME'):
    #         cls.conf_name='android.cfg'
    #         cls.cf = lib.Config(cls.conf_name)
    #         logging.info('Version: '+ os.environ['JOB_NAME'])
    #     else:
    #         cls.conf_name='android.cfg'
    #         cls.cf = lib.Config(cls.conf_name)
    #
    # @classmethod
    # def InitAppiumClient(cls,apkPath=False):
    #     cls.classInit=True
    #     cls.classLoadConfig()
    #     if os.environ.has_key('JENKINS_HOME'):
    #         cls.appiumClient=lib.AppiumApi(deviceName=os.environ['deviceName'],platformVersion=os.environ['platformVersion'],serverPort=os.environ['serverPort'],apkPath=apkPath)
    #     else:
    #         cls.appiumClient=lib.AppiumApi(deviceName=cls.cf.device_name,platformVersion=cls.cf.platform_version,serverPort=cls.cf.server_port,apkPath=apkPath)
    #
    #     if cls.appiumClient.wait_by_name(u'发现新版本') is not None:
    #         cls.appiumClient.click_by_name(u'取消')
    
    @classmethod
    def setUpClass(cls):
        AndroidTestCaseBaseClass.classInitAppiumClient()
        
    @classmethod
    def tearDownClass(cls):  
        cls.appiumClient.stop_driver()
    
    def test_click_second_hand_house(self):
        '''测试点击二手房'''
        logging.info('Step-2:Click second hand house')
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')
        logging.info('Step-3:')
        if self.appiumClient.wait_by_name(u'确定')!=None:
            self.assertTrue(self.appiumClient.click_by_name(u'确定'),'无法找到确定')
        self.assertIsNotNone(self.appiumClient.wait_by_name(u'位置'),'Found location failed...')
        self.assertIsNotNone(self.appiumClient.wait_by_name(u'筛选'),'Found location failed...')
        self.assertIsNotNone(self.appiumClient.wait_by_name(u'排序'),'Found location failed...')
        self.appiumClient.app.click(self.image_path+'back.png')        
        
    def test_second_house_pop_window(self):
        '''测试二手房弹窗'''
        logging.info('Step-2:点击二手房')
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')
        logging.info('Step-3:点击1室')
        self.assertIsNotNone(self.appiumClient.wait_by_name(u'我要试试'),'无法找到二手房...')
        self.appiumClient.driver.press_keycode('4')
        #self.assertTrue(self.appiumClient.click_by_name(u'1室'),'无法找到确定')
        #self.assertTrue(self.appiumClient.click_by_name(u'确定'),'无法找到确定')        
        #self.appiumClient.app.click(self.image_path+'back.png')
        #self.assertIsNotNone(self.appiumClient.wait_by_name(u'二手房'),'无法找到二手房...')
        #
        #logging.info('Step-4:点击2室')
        #self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')
        #self.assertTrue(self.appiumClient.click_by_name(u'2室'),'无法找到确定')
        #self.assertTrue(self.appiumClient.click_by_name(u'确定'),'无法找到确定')
        #self.appiumClient.app.click(self.image_path+'back.png')
        #self.assertIsNotNone(self.appiumClient.wait_by_name(u'二手房'),'无法找到二手房...')
        #
        #logging.info('Step-5:点击3室')
        #self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')
        #self.assertTrue(self.appiumClient.click_by_name(u'3室'),'无法找到确定')
        #self.assertTrue(self.appiumClient.click_by_name(u'确定'),'无法找到确定')
        #self.appiumClient.app.click(self.image_path+'back.png')
        #self.assertIsNotNone(self.appiumClient.wait_by_name(u'二手房'),'无法找到二手房...')
        #
        #logging.info('Step-6:点击4室')
        #self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')
        #self.assertTrue(self.appiumClient.click_by_name(u'4室'),'无法找到确定')
        #self.assertTrue(self.appiumClient.click_by_name(u'确定'),'无法找到确定')
        #self.appiumClient.app.click(self.image_path+'back.png')
        #self.assertIsNotNone(self.appiumClient.wait_by_name(u'二手房'),'无法找到二手房...')
        #
        #logging.info('Step-7:点击5室+')
        #self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')
        #self.assertTrue(self.appiumClient.click_by_name(u'5室+'),'无法找到确定')
        #self.assertTrue(self.appiumClient.click_by_name(u'确定'),'无法找到确定')        
        #self.appiumClient.app.click(self.image_path+'back.png')
        #self.assertIsNotNone(self.appiumClient.wait_by_name(u'二手房'),'无法找到二手房...')
        #
        #logging.info('Step-7:关闭提示栏')
        #self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')
        #self.appiumClient.app.click(self.image_path+'x.png')
        #self.appiumClient.app.click(self.image_path+'back.png')
        #self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')
        #self.assertIsNone(self.appiumClient.wait_by_name(u'1室'),'无法找到二手房...')
        #self.assertIsNone(self.appiumClient.wait_by_name(u'2室'),'无法找到二手房...')
        #self.assertIsNone(self.appiumClient.wait_by_name(u'3室'),'无法找到二手房...')
        #self.appiumClient.app.click(self.image_path+'back.png')

    def test_reduce_price_sencond_hand_house(self):
        pass
        
    def test_second_house_search_box(self):
        '''测试二手房搜索框'''
        logging.info('Step-2:点击二手房')
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')
        logging.info('Step-3:输入广中苑')
        ele=self.appiumClient.wait_by_name(u'请输入小区名、板块')
        self.assertTrue(self.appiumClient.enter(ele,u'广中苑'),'输入失败')
        self.appiumClient.app.click(self.image_path+'homepage/guangzhongyuan.png')
        self.appiumClient.app.click(self.image_path+'back.png')
        logging.info('Step-4:输入佳宁花园')
        self.assertTrue(self.appiumClient.click_by_name(u'请输入小区名、板块'),'click failed')
        ele=self.appiumClient.wait_by_name(u'请输入小区名、板块')
        self.assertTrue(self.appiumClient.enter(ele,u'佳宁花园'),'输入失败')
        self.appiumClient.app.click(self.image_path+'homepage/jianinghuayuan.png')       
        self.appiumClient.app.click(self.image_path+'back.png')
        
    def test_second_house_hint(self):
        '''测试提示栏'''
        logging.info('Step-2:点击二手房')
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')
        logging.info('Step-3:查看提示是否存在')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png',30.0),'无法找到提示')
        #self.appiumClient.app.click(self.image_path+'secondhouse/x.png')
        #self.assertIsNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png',10.0),'无法找到提示')
        
if __name__ == '__main__':
    suite=unittest.TestSuite()
    suite.addTest(SecondHandHouseTest('test_second_house_pop_window'))
    suite.addTest(SecondHandHouseTest('test_second_house_search_box'))
    suite.addTest(SecondHandHouseTest('test_second_house_hint'))
    runner = lib.HTMLTestRunner(stream='TestReport.html',title="Test Result",description='Test Suite')
    runner.run(suite)
    if ((runner.failure_count !=0) or (runner.error_count!=0)):
        raise Exception('Test Suite execute finished,Test suite failed...')
    