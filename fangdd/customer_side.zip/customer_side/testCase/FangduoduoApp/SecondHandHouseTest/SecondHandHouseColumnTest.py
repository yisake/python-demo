#coding=utf8
import unittest
import os
import sys
import logging
import time
import traceback
import platform
sys.path.append('../../..')
import lib
from testCase.AndroidTestCaseBaseClass import AndroidTestCaseBaseClass

class SecondHandHouseColumnNewHouseLocationTest(AndroidTestCaseBaseClass):
    '''二手房精品类目新上房源位置测试集'''

    @classmethod
    def setUpClass(cls):
        AndroidTestCaseBaseClass.classInitAppiumClient()
        
    @classmethod
    def tearDownClass(cls):  
        cls.appiumClient.stop_driver()
    
    def swipe_to_left_back(self):
        return self.appiumClient.swipe_to_element('com.fangdd.mobile.fddhouseownersell:id/back_button','id')
    
    def swipe_to_new_house(self):
        return self.appiumClient.swipe_to_element('com.fangdd.mobile.fddhouseownersell:id/iv_sub_pic_4','id')
    
    def swipe_to_sale_house(self):
        return self.appiumClient.swipe_to_element('com.fangdd.mobile.fddhouseownersell:id/iv_sub_pic_1','id')
    
    def test_second_house_column_new_house_location_area_baoshan(self):
        '''测试位置宝山区域筛选''' 
        logging.info('Step-2:Click second hand house')
        #self.assertTrue(self.appiumClient.swipe_and_click_picture(self.image_path+'xinshangfangyuan.png'),'')
        
        self.appiumClient.swipe_to_element('com.fangdd.mobile.fddhouseownersell:id/iv_sub_pic_1','up')
        
        #commit dahua
        logging.info('测试筛选位置宝山')
        area_list=['dachang','gucun','gongkang','luodian','luojing','shangda','yuepu','yanghang','songbao',
                    'zhangmiao','gaojing','gongfu','songnan','tonghe','sitang']
        
        for item in area_list:
            self.appiumClient.app.click(self.image_path+'weizhi.png')
            if item=='dachang':
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu.png')
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/baoshan.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/baoshan/'+item+'.png')
            self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
            for i in self.appiumClient.get_all_house_source_from_second_hand_house():
                self.assertTrue(i.newHouseTag,'不是新上房源')            
            listView=self.appiumClient.get_all_house_source_element_from_second_hand_house()    
            for i in listView:
                self.assertIsNotNone(self.appiumClient.wait_by_name(u'位置'),'无法找到位置')
                i.houseName.click()
                logging.info('Start to test the area:'+item)
                self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/weizhi/quyu/baoshan/baoshan'+item+'.png',30.0),'无法找到提示')
                self.appiumClient.click_by_id('com.fangdd.mobile.fddhouseownersell:id/left_btn')  
        
    def test_second_house_column_new_house_location_area_minhang(self):
        '''测试位置闵行区域筛选'''        
        logging.info('测试筛选位置:闵行')
        area_list=['gumeiluoyang','hanghua','jinhuilongbai','jinganxincheng','pujiangzhen','jiangchuan','huacao','jinhongqiao','meilongchunshen','maqiao',
        'qibao','wujing','xinzhuang','zhuanqiao']
        
        for item in area_list:
            self.appiumClient.app.click(self.image_path+'weizhi.png')
            if item=='gumeiluoyang':
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/minhang.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/minhang/'+item+'.png')
            self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
            for i in self.appiumClient.get_all_house_source_from_second_hand_house():
                self.assertTrue(i.newHouseTag,'不是新上房源')              
            listView=self.appiumClient.get_all_house_source_element_from_second_hand_house()    
            for i in listView:
                self.assertIsNotNone(self.appiumClient.wait_by_name(u'位置'),'无法找到位置')
                i.houseName.click()
                logging.info('Start to test the area:'+item)
                self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/weizhi/quyu/minhang/minhang'+item+'.png',30.0),'无法找到提示')
                self.appiumClient.click_by_id('com.fangdd.mobile.fddhouseownersell:id/left_btn')

    def test_second_house_column_new_house_location_area_pudong(self):
        '''测试位置区域筛选浦东'''
        logging.info('筛选位置:浦东')
        area_list=['biyun','caolu','chuansha','gaohang','hangtou','huinan','jinqiao','lianyang','lingangxincheng','sanlin','shijigongyuan','tangqiao','tangzhen','yuanshen','zhangjiang','beicai','waigaoqiao','jinyang','kangqiao','nanmatou',
        'shibobinjiang','weifang','yangdong','yangjing','zhoupu','huamu','lujiazui','shangnan','yuqiao','meiyuan']
        
        for item in area_list:
            self.appiumClient.app.click(self.image_path+'weizhi.png')
            if item=='biyun':
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/pudong.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/pudong/'+item+'.png')
            self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
            for i in self.appiumClient.get_all_house_source_from_second_hand_house():
                self.assertTrue(i.newHouseTag,'不是新上房源')              
            listView=self.appiumClient.get_all_house_source_element_from_second_hand_house()    
            for i in listView:
                self.assertIsNotNone(self.appiumClient.wait_by_name(u'位置'),'无法找到位置')
                i.houseName.click()
                logging.info('Start to test the area:'+item)                
                self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/weizhi/quyu/pudong/pudong'+item+'.png',30.0),'无法找到提示')
                self.appiumClient.click_by_id('com.fangdd.mobile.fddhouseownersell:id/left_btn')       
        
    def test_second_house_column_new_house_location_area_songjiang(self):
        '''测试位置区域筛选松江'''
        logging.info('筛选位置，松江')
        area_list=['nanjiuting','songjiangxincheng','sijing','sheshan','songjianglaocheng','xinqiao','xinmin','songjiangdaxuecheng',
        'songjiangqita','xiaokunshan','beijiuting']

        for item in area_list:
            self.appiumClient.app.click(self.image_path+'weizhi.png')
            if item=='nanjiuting':
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/songjiang.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/songjiang/'+item+'.png')
            self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
            for i in self.appiumClient.get_all_house_source_from_second_hand_house():
                self.assertTrue(i.newHouseTag,'不是新上房源')              
            listView=self.appiumClient.get_all_house_source_element_from_second_hand_house()    
            for i in listView:
                self.assertIsNotNone(self.appiumClient.wait_by_name(u'位置'),'无法找到位置')
                i.houseName.click()
                logging.info('Start to test the area:'+item)
                self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/weizhi/quyu/songjiang/songjiang'+item+'.png',30.0),'无法找到提示')
                self.appiumClient.click_by_id('com.fangdd.mobile.fddhouseownersell:id/left_btn')       
        
    def test_second_house_column_new_house_location_area_yangpu(self):
        '''测试位置区域筛选杨浦'''
        logging.info('Step-3:测试区域筛选杨浦')
        area_list=['anshan','dongwaitan','huangxinggongyuan','kongjiang','wujiaochang','xinjiangwancheng',
                   'zhongyuan','jiangpulu']
        
        for item in area_list:
            self.appiumClient.app.click(self.image_path+'weizhi.png')
            if item=='anshan':
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/yangpu.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/yangpu/'+item+'.png')
            self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
            for i in self.appiumClient.get_all_house_source_from_second_hand_house():
                self.assertTrue(i.newHouseTag,'不是新上房源')              
            listView=self.appiumClient.get_all_house_source_element_from_second_hand_house()    
            for i in listView:
                self.assertIsNotNone(self.appiumClient.wait_by_name(u'位置'),'无法找到位置')
                i.houseName.click()
                logging.info('Start to test the area:'+item)
                self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/weizhi/quyu/yangpu/yangpu'+item+'.png',30.0),'无法找到提示')
                self.appiumClient.click_by_id('com.fangdd.mobile.fddhouseownersell:id/left_btn')       
    
    def test_second_house_column_new_house_location_area_putuo(self):    
        '''测试位置区域普陀'''
        logging.info('筛选位置普陀')
        area_list=['changfeng','changzheng','guangxin','taopu','wuning','wanli','zhenru','ganquanyichuan','zhongyuanliangwancheng','changshoulu','caoyang']
        
        for item in area_list:
            self.appiumClient.app.click(self.image_path+'weizhi.png')
            if item=='changfeng':
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/putuo.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/putuo/'+item+'.png')
            self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
            for i in self.appiumClient.get_all_house_source_from_second_hand_house():
                self.assertTrue(i.newHouseTag,'不是新上房源')              
            listView=self.appiumClient.get_all_house_source_element_from_second_hand_house()    
            for i in listView:
                self.assertIsNotNone(self.appiumClient.wait_by_name(u'位置'),'无法找到位置')
                i.houseName.click()
                logging.info('Start to test the area:'+item)
                self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/weizhi/quyu/putuo/putuo'+item+'.png',30.0),'无法找到提示')
                self.appiumClient.click_by_id('com.fangdd.mobile.fddhouseownersell:id/left_btn')       
    
    def test_second_house_column_new_house_location_area_jiading(self):
        '''测试位置区域嘉定'''
        logging.info('筛选位置嘉定')
        area_list=['fengzhuang','jiangqiao','jiadingxincheng','nanxiang','anting','jiadingchengqu','malu','jiadingbeibu']
        
        for item in area_list:
            self.appiumClient.app.click(self.image_path+'weizhi.png')
            if item=='fengzhuang':
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/jiading.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/jiading/'+item+'.png')
            self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
            for i in self.appiumClient.get_all_house_source_from_second_hand_house():
                self.assertTrue(i.newHouseTag,'不是新上房源')              
            listView=self.appiumClient.get_all_house_source_element_from_second_hand_house()    
            for i in listView:
                self.assertIsNotNone(self.appiumClient.wait_by_name(u'位置'),'无法找到位置')
                i.houseName.click()
                logging.info('Start to test the area:'+item)
                self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/weizhi/quyu/jiading/jiading'+item+'.png',30.0),'无法找到提示')
                self.appiumClient.click_by_id('com.fangdd.mobile.fddhouseownersell:id/left_btn')       

    def test_second_house_column_new_house_location_area_xuhui(self):                
        '''测试位置区域徐汇'''
        logging.info('筛选位置徐汇')
        area_list=['nanzhan','longhua','changqiao','huadongligong','huajing','kangjian','tianlin','wantiguan',
                   'xuhuibinjiang','xujiahui','zhiwuyuan','damuqiao','huaihaibei','huaihainan']     

        for item in area_list:
            self.appiumClient.app.click(self.image_path+'weizhi.png')
            if item=='nanzhan':
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/xuhui.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/xuhui/'+item+'.png')
            self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
            for i in self.appiumClient.get_all_house_source_from_second_hand_house():
                self.assertTrue(i.newHouseTag,'不是新上房源')              
            listView=self.appiumClient.get_all_house_source_element_from_second_hand_house()    
            for i in listView:
                self.assertIsNotNone(self.appiumClient.wait_by_name(u'位置'),'无法找到位置')
                i.houseName.click()
                logging.info('Start to test the area:'+item)
                self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/weizhi/quyu/xuhui/xuhui'+item+'.png',30.0),'无法找到提示')
                self.appiumClient.click_by_id('com.fangdd.mobile.fddhouseownersell:id/left_btn')       
    
    def test_second_house_column_new_house_location_area_zhabei(self):
        '''测试位置区域闸北'''
        logging.info('筛选位置闸北')
        area_list=['buyecheng','daning','pengpu','xizangbeilu','yangcheng','yonghe','zhabeigongyuan']
        
        for item in area_list:
            self.appiumClient.app.click(self.image_path+'weizhi.png')
            if item=='buyecheng':
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/zhabei.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/zhabei/'+item+'.png')
            self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
            for i in self.appiumClient.get_all_house_source_from_second_hand_house():
                self.assertTrue(i.newHouseTag,'不是新上房源')              
            listView=self.appiumClient.get_all_house_source_element_from_second_hand_house()    
            for i in listView:
                self.assertIsNotNone(self.appiumClient.wait_by_name(u'位置'),'无法找到位置')
                i.houseName.click()
                logging.info('Start to test the area:'+item)
                self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/weizhi/quyu/zhabei/zhabei'+item+'.png',30.0),'无法找到提示')
                self.appiumClient.click_by_id('com.fangdd.mobile.fddhouseownersell:id/left_btn')       

    def test_second_house_column_new_house_location_area_fengxian(self):                
        '''测试位置区域奉贤'''
        logging.info('筛选位置奉贤')
        area_list=['fengcheng','haiwan','nanqiao','zhuanghang','tuolin','fengxianqita','haiwanlvyouqu','jinhuizhen','xidu']

        for item in area_list:
            self.appiumClient.app.click(self.image_path+'weizhi.png')
            if item=='fengcheng':
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/fengxian.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/fengxian/'+item+'.png')
            self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
            for i in self.appiumClient.get_all_house_source_from_second_hand_house():
                self.assertTrue(i.newHouseTag,'不是新上房源')  
            listView=self.appiumClient.get_all_house_source_element_from_second_hand_house()    
            for i in listView:
                self.assertIsNotNone(self.appiumClient.wait_by_name(u'位置'),'无法找到位置')
                i.houseName.click()
                logging.info('Start to test the area:'+item)
                self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/weizhi/quyu/fengxian/fengxian'+item+'.png',30.0),'无法找到提示')
                self.appiumClient.click_by_id('com.fangdd.mobile.fddhouseownersell:id/left_btn')       
    
    def test_second_house_column_new_house_location_area_hongkou(self):
        '''测试位置区域虹口'''
        logging.info('筛选位置虹口')
        area_list=['beiwaitan','linping','jiangwanliangcheng','quyang','sichuanbeilu','sipinglu','guangzhong']

        for item in area_list:
            self.appiumClient.app.click(self.image_path+'weizhi.png')
            if item=='beiwaitan':
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/hongkou.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/hongkou/'+item+'.png')
            self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
            for i in self.appiumClient.get_all_house_source_from_second_hand_house():
                self.assertTrue(i.newHouseTag,'不是新上房源')              
            listView=self.appiumClient.get_all_house_source_element_from_second_hand_house()    
            for i in listView:
                self.assertIsNotNone(self.appiumClient.wait_by_name(u'位置'),'无法找到位置')
                i.houseName.click()
                logging.info('Start to test the area:'+item)
                self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/weizhi/quyu/hongkou/hongkou'+item+'.png',30.0),'无法找到提示')
                self.appiumClient.click_by_id('com.fangdd.mobile.fddhouseownersell:id/left_btn')       

    def test_second_house_column_new_house_location_area_jinshan(self):                
        '''测试位置区域金山'''
        logging.info('筛选位置金山')
        area_list=['jinshanxincheng','shihua','tinglin','zhujing','jinshanqita','fengjing']
                
        for item in area_list:
            self.appiumClient.app.click(self.image_path+'weizhi.png')
            if item=='jinshanxincheng':
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/jinshan.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/jinshan/'+item+'.png')
            self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
            for i in self.appiumClient.get_all_house_source_from_second_hand_house():
                self.assertTrue(i.newHouseTag,'不是新上房源')              
            listView=self.appiumClient.get_all_house_source_element_from_second_hand_house()    
            for i in listView:
                self.assertIsNotNone(self.appiumClient.wait_by_name(u'位置'),'无法找到位置')
                i.houseName.click()
                logging.info('Start to test the area:'+item)
                self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/weizhi/quyu/jinshan/jinshan'+item+'.png',30.0),'无法找到提示')
                self.appiumClient.click_by_id('com.fangdd.mobile.fddhouseownersell:id/left_btn')       

    def test_second_house_column_new_house_location_area_qingpu(self):                
        '''测试位置区域青浦'''
        logging.info('筛选位置青浦')
        area_list=['xujing','zhujiajiao','zhaoxiang','huaxin','chonggu','qingpuchengqu','huqingping','baihe']

        for item in area_list:
            self.appiumClient.app.click(self.image_path+'weizhi.png')
            if item=='xujing':
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/qingpu.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/qingpu/'+item+'.png')
            self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
            for i in self.appiumClient.get_all_house_source_from_second_hand_house():
                self.assertTrue(i.newHouseTag,'不是新上房源')              
            listView=self.appiumClient.get_all_house_source_element_from_second_hand_house()    
            for i in listView:
                self.assertIsNotNone(self.appiumClient.wait_by_name(u'位置'),'无法找到位置')
                i.houseName.click()
                logging.info('Start to test the area:'+item)
                self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/weizhi/quyu/qingpu/qingpu'+item+'.png',30.0),'无法找到提示')
                self.appiumClient.click_by_id('com.fangdd.mobile.fddhouseownersell:id/left_btn')       

    def test_second_house_column_new_house_location_area_changning(self):                
        '''测试位置区域长宁'''
        logging.info('筛选位置长宁')
        area_list=['beixinjing','gubei','hongqiao','tianshan','xijiao','xianxia','xinhualu','zhenninglu','zhongshangongyuan']
        
        for item in area_list:
            self.appiumClient.app.click(self.image_path+'weizhi.png')
            if item=='beixinjing':
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/changning.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/changning/'+item+'.png')
            self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
            for i in self.appiumClient.get_all_house_source_from_second_hand_house():
                self.assertTrue(i.newHouseTag,'不是新上房源')  
            listView=self.appiumClient.get_all_house_source_element_from_second_hand_house()    
            for i in listView:
                self.assertIsNotNone(self.appiumClient.wait_by_name(u'位置'),'无法找到位置')
                i.houseName.click()
                logging.info('Start to test the area:'+item)
                self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/weizhi/quyu/changning/changning'+item+'.png',30.0),'无法找到提示')
                self.appiumClient.click_by_id('com.fangdd.mobile.fddhouseownersell:id/left_btn')       

    def test_second_house_column_new_house_location_area_jingan(self):
        '''测试位置区域静安'''
        logging.info('筛选位置静安')
        area_list=['caojiadu','jiangninglu','jingansi','nanjingxilu']
        
        for item in area_list:
            self.appiumClient.app.click(self.image_path+'weizhi.png')
            if item=='caojiadu':
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/jingan.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/jingan/'+item+'.png')
            self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
            for i in self.appiumClient.get_all_house_source_from_second_hand_house():
                self.assertTrue(i.newHouseTag,'不是新上房源')              
            listView=self.appiumClient.get_all_house_source_element_from_second_hand_house()    
            for i in listView:
                self.assertIsNotNone(self.appiumClient.wait_by_name(u'位置'),'无法找到位置')
                i.houseName.click()
                logging.info('Start to test the area:'+item)
                self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/weizhi/quyu/jingan/jingan'+item+'.png',30.0),'无法找到提示')
                self.appiumClient.click_by_id('com.fangdd.mobile.fddhouseownersell:id/left_btn')       

    def test_second_house_column_new_house_location_area_chongming(self):
        '''测试位置区域崇明'''
        logging.info('筛选位置崇明')
        area_list=['chongming']
        
        for item in area_list:
            self.appiumClient.app.click(self.image_path+'weizhi.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/chongming.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/chongming/'+item+'.png')
            self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
            for i in self.appiumClient.get_all_house_source_from_second_hand_house():
                self.assertTrue(i.newHouseTag,'不是新上房源')              
            listView=self.appiumClient.get_all_house_source_element_from_second_hand_house()    
            for i in listView:
                self.assertIsNotNone(self.appiumClient.wait_by_name(u'位置'),'无法找到位置')
                i.houseName.click()
                logging.info('Start to test the area:'+item)
                self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/weizhi/quyu/chongming/chongming'+item+'.png',30.0),'无法找到提示')
                self.appiumClient.click_by_id('com.fangdd.mobile.fddhouseownersell:id/left_btn')       

    def test_second_house_column_new_house_location_area_huangpu(self):
        '''测试位置区域黄埔'''
        logging.info('筛选位置黄埔')
        area_list=['dapuqiao','xintiandi','dongjiadu','laoximen','nanjingdonglu','renminguangchang',
                   'yuyuan','penglaigongyuan','xietulu','beisuzhouhe','shanxilu','waitan','huangpubinjiang']
        
        for item in area_list:
            self.appiumClient.app.click(self.image_path+'weizhi.png')
            if item=='dapuqiao':
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/huangpu.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/huangpu/'+item+'.png')
            self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
            for i in self.appiumClient.get_all_house_source_from_second_hand_house():
                self.assertTrue(i.newHouseTag,'不是新上房源')  
            listView=self.appiumClient.get_all_house_source_element_from_second_hand_house()    
            for i in listView:
                self.assertIsNotNone(self.appiumClient.wait_by_name(u'位置'),'无法找到位置')
                i.houseName.click()
                logging.info('Start to test the area:'+item)
                self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/weizhi/quyu/huangpu/huangpu'+item+'.png',30.0),'无法找到提示')
                self.appiumClient.click_by_id('com.fangdd.mobile.fddhouseownersell:id/left_btn')       

class SecondHandHouseColumnNewHouseSortTest(SecondHandHouseColumnNewHouseLocationTest):
    '''二手房精品类目新上房源排序测试集'''
    def test_second_house_sort_by_unit_price(self):
        '''测试二手房根据单价排序'''
        #self.assertTrue(self.appiumClient.swipe_and_click_picture(self.image_path+'xinshangfangyuan.png'),'')
        self.swipe_to_new_house().click()
        
        logging.info('测试单价从高到低')        
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        self.appiumClient.app.click(self.image_path+'secondhouse/paixu/danjiayougaodaodi.png')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'weizhi.png'))        
        for i in self.appiumClient.get_all_house_source_from_second_hand_house():
            self.assertTrue(i.newHouseTag,'不是新上房源')
        houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
        self.assertTrue(self.appiumClient.compareUnitPirce(houseList,'down'),'比较失败')
        
        logging.info('测试单价从低到高')
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        self.appiumClient.app.click(self.image_path+'secondhouse/paixu/danjiayoudidaogao.png')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'weizhi.png'))
        for i in self.appiumClient.get_all_house_source_from_second_hand_house():
            self.assertTrue(i.newHouseTag,'不是新上房源')       
        houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
        self.assertTrue(self.appiumClient.compareUnitPirce(houseList,'up'),'比较失败')
        self.swipe_to_left_back().click()
        
    def test_second_house_sort_by_total_price(self):
        '''测试二手房根据总价排序'''
        #self.assertTrue(self.appiumClient.swipe_and_click_picture(self.image_path+'xinshangfangyuan.png'),'')
        self.swipe_to_new_house().click()
        
        logging.info('测试总价从高到低')
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        self.appiumClient.app.click(self.image_path+'secondhouse/paixu/zongjiayougaodaodi.png')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'weizhi.png'))
        for i in self.appiumClient.get_all_house_source_from_second_hand_house():
            self.assertTrue(i.newHouseTag,'不是新上房源')      
        houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
        self.assertTrue(self.appiumClient.compareHousePrice(houseList,'down'),'比较失败')
        
        logging.info('测试总价从低到高')
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        self.appiumClient.app.click(self.image_path+'secondhouse/paixu/zongjiayoudidaogao.png')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'weizhi.png'))
        for i in self.appiumClient.get_all_house_source_from_second_hand_house():
            self.assertTrue(i.newHouseTag,'不是新上房源')       
        houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
        self.assertTrue(self.appiumClient.compareHousePrice(houseList,'up'),'比较失败')
        self.swipe_to_left_back().click()  
        
    def test_second_house_sort_by_area(self):
        '''测试二手房根据面积排序'''
        #self.assertTrue(self.appiumClient.swipe_and_click_picture(self.image_path+'xinshangfangyuan.png'),'')
        self.swipe_to_new_house().click()
        
        logging.info('测试面积从小到大')        
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        self.appiumClient.app.click(self.image_path+'secondhouse/paixu/zongjiayougaodaodi.png')
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        self.appiumClient.app.click(self.image_path+'secondhouse/paixu/mianjiyouxiaodaoda.png')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'weizhi.png'))
        for i in self.appiumClient.get_all_house_source_from_second_hand_house():
            self.assertTrue(i.newHouseTag,'不是新上房源')     
        houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
        self.assertTrue(self.appiumClient.compareHouseArea(houseList,'down'),'比较失败')
        
        logging.info('测试单价从大到小')
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        self.appiumClient.app.click(self.image_path+'secondhouse/paixu/mianjiyoudadaoxiao.png')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'weizhi.png'))
        for i in self.appiumClient.get_all_house_source_from_second_hand_house():
            self.assertTrue(i.newHouseTag,'不是新上房源')       
        houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
        self.assertTrue(self.appiumClient.compareHouseArea(houseList,'up'),'比较失败')    
        self.swipe_to_left_back().click()
    
class SecondHandHouseColumnNewHouseFilterTest(SecondHandHouseColumnNewHouseLocationTest):
    '''二手房精品类目新上房源筛选测试集'''
    def test_second_house_list_page_filter(self):
        '''测试二手房列表页筛选户型'''
        self.swipe_to_new_house().click()
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'shaixuan.png'), '')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/yishi.png'), u'点击一室按钮失败')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'), u'点击确定按钮失败')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))        
        house_list = self.appiumClient.get_all_house_source_from_second_hand_house()
        for h in house_list:
            self.assertEqual(h.houseLayout.find(u'1室'), 0, u'户型不匹配')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'shaixuan.png'), '')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/liangshi.png'), u'点击两室按钮失败')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'), u'点击确定按钮失败')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
        house_list = self.appiumClient.get_all_house_source_from_second_hand_house()
        for h in house_list:
            self.assertEqual(h.houseLayout.find(u'2室'), 0, u'户型不匹配')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'shaixuan.png'), '')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/sanshi.png'), u'点击三室按钮失败')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'), u'点击确定按钮失败')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
        house_list = self.appiumClient.get_all_house_source_from_second_hand_house()
        for h in house_list:
            self.assertEqual(h.houseLayout.find(u'3室'), 0, u'户型不匹配')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'shaixuan.png'), '')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/sishi.png'), u'点击四室按钮失败')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'), u'点击确定按钮失败')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
        house_list = self.appiumClient.get_all_house_source_from_second_hand_house()
        for h in house_list:
            self.assertEqual(h.houseLayout.find(u'4室'), 0, u'户型不匹配')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'shaixuan.png'), '')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/wushi.png'), u'点击五室以上按钮失败')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'), u'点击确定按钮失败')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
        house_list = self.appiumClient.get_all_house_source_from_second_hand_house()
        for h in house_list:
            flag = -1
            if h.houseLayout[0] >= 5:
                flag = 0
            self.assertEqual(flag, 0, u'户型不匹配')
        logging.info('Step-4:同时选中多个户型进行筛选')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'shaixuan.png'), '')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/yishi.png'), u'点击一室按钮失败')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/liangshi.png'), u'点击两室按钮失败')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'), u'点击确定按钮失败')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
        house_list = self.appiumClient.get_all_house_source_from_second_hand_house()
        for h in house_list:
            flag = -1
            if h.houseLayout.find(u'1室') == 0 or h.houseLayout.find(u'2室') == 0:
                flag = 0
            self.assertEqual(flag, 0, u'户型不匹配')
        self.swipe_to_left_back().click()
            
    def test_second_house_label_filter(self):
        '''测试二手房列表页筛选特色标签'''
        
        logging.info('Step1:点击上门实勘按钮')
        self.swipe_to_new_house().click()
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'shaixuan.png'), '')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.appiumClient.swipe_to_picture(self.image_path+'homepage/shangmenshikan.png',times=2)
        self.appiumClient.click_by_image(self.image_path+'homepage/default.png')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path+'homepage/shangmenshikan.png'))
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'))
        
        house_list=self.appiumClient.get_all_house_source_from_second_hand_house()
        for house in house_list:
            self.assertTrue(house.actualTag,'不是实勘房源')
        
        logging.info('Step2:点击满五唯一按钮')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'shaixuan.png'), '')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.appiumClient.swipe_to_picture(self.image_path+'homepage/manwuweiyi.png',times=2)
        self.assertTrue(self.appiumClient.click_by_image(self.image_path+'homepage/manwuweiyi.png'))
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'))
        
        house_list=self.appiumClient.get_all_house_source_from_second_hand_house()
        for house in house_list:
            self.assertGreaterEqual(house.houseLabel.count(u'\u6ee1\u4e94\u552f\u4e00'),1,'没有满五唯一标签')
        
        logging.info('Step3:点击满两年按钮')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'shaixuan.png'), '')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.appiumClient.swipe_to_picture(self.image_path+'homepage/manliangnian.png',times=2)
        self.assertTrue(self.appiumClient.click_by_image(self.image_path+'homepage/manliangnian.png'))
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'))
        
        house_list=self.appiumClient.get_all_house_source_from_second_hand_house()
        for house in house_list:
            self.assertGreaterEqual(house.houseLabel.count(u'\u6ee1\u4e94\u552f\u4e00') or house.houseLabel.count(u'\u6ee1\u4e24\u5e74') or house.houseLabel.count(u'\u6ee1\u4e94\u5e74'),1,'没有满五唯一标签')

        logging.info('Step4:点击电梯房按钮')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'shaixuan.png'), '')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.appiumClient.swipe_to_picture(self.image_path+'homepage/diantifang.png',times=2)
        self.assertTrue(self.appiumClient.click_by_image(self.image_path+'homepage/diantifang.png'))
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'))
        
        house_list=self.appiumClient.get_all_house_source_from_second_hand_house()
        for house in house_list:
            self.assertGreaterEqual(house.houseLabel.count(u'\u7535\u68af\u623f'),1,'没有满五唯一标签')

        logging.info('Step5:点击地铁房按钮')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'shaixuan.png'), '')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.appiumClient.swipe_to_picture(self.image_path+'homepage/ditiefang.png',times=2)
        self.assertTrue(self.appiumClient.click_by_image(self.image_path+'homepage/ditiefang.png'))
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'))
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'weizhi.png'),'无法找到提示')
        
        house_list=self.appiumClient.get_all_house_source_from_second_hand_house()
        for house in house_list:
            self.assertGreaterEqual(house.houseLabel.count(u'\u5730\u94c1\u623f'),1,'没有满五唯一标签')
        self.swipe_to_left_back().click()
     
class SecondHandHouseColumnSaleHouseLocationTest(SecondHandHouseColumnNewHouseLocationTest):
    '''二手房精品类目降价房源位置测试集'''
    def test_second_house_column_sale_house_location_area_baoshan(self):
        '''测试位置宝山区域筛选''' 
        logging.info('Step-2:Click second hand house')        
        self.swipe_to_sale_house()
        
        logging.info('测试筛选位置宝山')
        #过滤,dahua
        area_list=['dachang','gucun','gongkang','luodian','luojing','shangda','yuepu','yanghang','songbao',
                    'zhangmiao','gaojing','gongfu','songnan','tonghe','sitang']
        
        for item in area_list:
            self.appiumClient.app.click(self.image_path+'weizhi.png')
            if item=='dachang':
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu.png')
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/baoshan.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/baoshan/'+item+'.png')
            self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
            for i in self.appiumClient.get_all_house_source_from_second_hand_house():
                self.assertTrue(i.saleHouseTag,'不是降价房源')            
            listView=self.appiumClient.get_all_house_source_element_from_second_hand_house()    
            for i in listView:
                self.assertIsNotNone(self.appiumClient.wait_by_name(u'位置'),'无法找到位置')
                i.houseName.click()
                logging.info('Start to test the area:'+item)
                self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/weizhi/quyu/baoshan/baoshan'+item+'.png',30.0),'无法找到提示')
                self.appiumClient.click_by_id('com.fangdd.mobile.fddhouseownersell:id/left_btn')  

    
class SecondHandHouseColumnSaleHouseSortTest(SecondHandHouseColumnNewHouseLocationTest):
    '''二手房精品类目降价房源排序测试集'''
    def test_second_house_sort_by_unit_price(self):
        '''测试二手房根据单价排序'''
        self.swipe_to_sale_house().click()
        
        logging.info('测试单价从高到低')        
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        self.appiumClient.app.click(self.image_path+'secondhouse/paixu/danjiayougaodaodi.png')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'weizhi.png'))        
        for i in self.appiumClient.get_all_house_source_from_second_hand_house():
            self.assertTrue(i.saleHouseTag,'不是新上房源')
        houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
        self.assertTrue(self.appiumClient.compareUnitPirce(houseList,'down'),'比较失败')
        
        logging.info('测试单价从低到高')
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        self.appiumClient.app.click(self.image_path+'secondhouse/paixu/danjiayoudidaogao.png')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'weizhi.png'))
        for i in self.appiumClient.get_all_house_source_from_second_hand_house():
            self.assertTrue(i.saleHouseTag,'不是新上房源')       
        houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
        self.assertTrue(self.appiumClient.compareUnitPirce(houseList,'up'),'比较失败')
        self.swipe_to_left_back().click()
        
    def test_second_house_sort_by_total_price(self):
        '''测试二手房根据总价排序'''
        self.swipe_to_sale_house().click()
        
        logging.info('测试总价从高到低')        
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        self.appiumClient.app.click(self.image_path+'secondhouse/paixu/zongjiayougaodaodi.png')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'weizhi.png'))
        for i in self.appiumClient.get_all_house_source_from_second_hand_house():
            self.assertTrue(i.saleHouseTag,'不是新上房源')      
        houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
        self.assertTrue(self.appiumClient.compareHousePrice(houseList,'down'),'比较失败')
        
        logging.info('测试总价从低到高')
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        self.appiumClient.app.click(self.image_path+'secondhouse/paixu/zongjiayoudidaogao.png')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'weizhi.png'))
        for i in self.appiumClient.get_all_house_source_from_second_hand_house():
            self.assertTrue(i.saleHouseTag,'不是新上房源')       
        houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
        self.assertTrue(self.appiumClient.compareHousePrice(houseList,'up'),'比较失败')
        self.swipe_to_left_back().click()
        
    def test_second_house_sort_by_area(self):
        '''测试二手房根据面积排序'''
        self.swipe_to_sale_house().click()
        
        logging.info('测试面积从小到大')        
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        self.appiumClient.app.click(self.image_path+'secondhouse/paixu/mianjiyouxiaodaoda.png')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'weizhi.png'))
        for i in self.appiumClient.get_all_house_source_from_second_hand_house():
            self.assertTrue(i.saleHouseTag,'不是新上房源')     
        houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
        self.assertTrue(self.appiumClient.compareHouseArea(houseList,'down'),'比较失败')
        
        logging.info('测试单价从大到小')
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        self.appiumClient.app.click(self.image_path+'secondhouse/paixu/mianjiyoudadaoxiao.png')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'weizhi.png'))
        for i in self.appiumClient.get_all_house_source_from_second_hand_house():
            self.assertTrue(i.saleHouseTag,'不是新上房源')       
        houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
        self.assertTrue(self.appiumClient.compareHouseArea(houseList,'up'),'比较失败') 
        self.swipe_to_left_back().click()
    
class SecondHandHouseColumnSaleHouseFilterTest(SecondHandHouseColumnNewHouseLocationTest):
    '''二手房精品类目降价房源筛选测试集'''
    def test_second_house_list_page_filter(self):
        '''测试二手房列表页筛选户型'''
        self.swipe_to_sale_house().click()
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'shaixuan.png'), '')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/yishi.png'), u'点击一室按钮失败')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'), u'点击确定按钮失败')
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        house_list = self.appiumClient.get_all_house_source_from_second_hand_house()
        for h in house_list:
            self.assertEqual(h.houseLayout.find(u'1室'), 0, u'户型不匹配')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'shaixuan.png'), '')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/liangshi.png'), u'点击两室按钮失败')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'), u'点击确定按钮失败')
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        house_list = self.appiumClient.get_all_house_source_from_second_hand_house()
        for h in house_list:
            self.assertEqual(h.houseLayout.find(u'2室'), 0, u'户型不匹配')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'shaixuan.png'), '')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/sanshi.png'), u'点击三室按钮失败')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'), u'点击确定按钮失败')
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        house_list = self.appiumClient.get_all_house_source_from_second_hand_house()
        for h in house_list:
            self.assertEqual(h.houseLayout.find(u'3室'), 0, u'户型不匹配')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'shaixuan.png'), '')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/sishi.png'), u'点击四室按钮失败')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'), u'点击确定按钮失败')
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        house_list = self.appiumClient.get_all_house_source_from_second_hand_house()
        for h in house_list:
            self.assertEqual(h.houseLayout.find(u'4室'), 0, u'户型不匹配')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'shaixuan.png'), '')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/wushi.png'), u'点击五室以上按钮失败')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'), u'点击确定按钮失败')
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        house_list = self.appiumClient.get_all_house_source_from_second_hand_house()
        for h in house_list:
            flag = -1
            if int(h.houseLayout[0])>=5:
                flag = 0
            self.assertEqual(flag, 0, u'户型不匹配')
        logging.info('Step-4:同时选中多个户型进行筛选')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'shaixuan.png'), '')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/yishi.png'), u'点击一室按钮失败')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/liangshi.png'), u'点击两室按钮失败')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'), u'点击确定按钮失败')
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        house_list = self.appiumClient.get_all_house_source_from_second_hand_house()
        for h in house_list:
            flag = -1
            #print h.houseLayout
            #print h.houseLayout.find(u'1室')
            #print h.houseLayout.find(u'2室')
            if h.houseLayout.find(u'1室') == 0 or h.houseLayout.find(u'2室') == 0:
                flag = 0
            self.assertEqual(flag, 0, u'户型不匹配')
        self.swipe_to_left_back()
            
    def test_second_house_label_filter(self):
        '''测试二手房列表页筛选标签'''
        
        logging.info('Step1:点击上门实勘按钮')
        self.swipe_to_sale_house().click()
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'shaixuan.png'), '')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.appiumClient.swipe_to_picture(self.image_path+'homepage/shangmenshikan.png',times=2)
        self.appiumClient.click_by_image(self.image_path+'homepage/default.png')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path+'homepage/shangmenshikan.png'))
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'))
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        house_list=self.appiumClient.get_all_house_source_from_second_hand_house()
        for house in house_list:
            self.assertTrue(house.actualTag,'不是实勘房源')
        
        logging.info('Step2:点击满五唯一按钮')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'shaixuan.png'), '')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.appiumClient.swipe_to_picture(self.image_path+'homepage/manwuweiyi.png',times=2)
        self.assertTrue(self.appiumClient.click_by_image(self.image_path+'homepage/manwuweiyi.png'))
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'))
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        house_list=self.appiumClient.get_all_house_source_from_second_hand_house()
        for house in house_list:
            self.assertGreaterEqual(house.houseLabel.count(u'\u6ee1\u4e94\u552f\u4e00'),1,'没有满五唯一标签')
        
        logging.info('Step3:点击满两年按钮')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'shaixuan.png'), '')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.appiumClient.swipe_to_picture(self.image_path+'homepage/manliangnian.png',times=2)
        self.assertTrue(self.appiumClient.click_by_image(self.image_path+'homepage/manliangnian.png'))
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'))
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        house_list=self.appiumClient.get_all_house_source_from_second_hand_house()
        for house in house_list:
            self.assertGreaterEqual(house.houseLabel.count(u'\u6ee1\u4e94\u552f\u4e00') or house.houseLabel.count(u'\u6ee1\u4e24\u5e74') or house.houseLabel.count(u'\u6ee1\u4e94\u5e74'),1,'没有满五唯一标签')

        logging.info('Step4:点击电梯房按钮')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'shaixuan.png'), '')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.appiumClient.swipe_to_picture(self.image_path+'homepage/diantifang.png',times=2)
        self.assertTrue(self.appiumClient.click_by_image(self.image_path+'homepage/diantifang.png'))
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'))
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        house_list=self.appiumClient.get_all_house_source_from_second_hand_house()
        for house in house_list:
            self.assertGreaterEqual(house.houseLabel.count(u'\u7535\u68af\u623f'),1,'没有满五唯一标签')

        logging.info('Step5:点击地铁房按钮')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'shaixuan.png'), '')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.appiumClient.swipe_to_picture(self.image_path+'homepage/ditiefang.png',times=2)
        self.assertTrue(self.appiumClient.click_by_image(self.image_path+'homepage/ditiefang.png'))
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'))
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        
        house_list=self.appiumClient.get_all_house_source_from_second_hand_house()
        for house in house_list:
            self.assertGreaterEqual(house.houseLabel.count(u'\u5730\u94c1\u623f'),1,'没有满五唯一标签')
        self.swipe_to_left_back()
        
class SecondHandHouseColumnHotHouseLocationTest(SecondHandHouseColumnNewHouseLocationTest):
    '''二手房精品类目全城热卖房源位置测试集'''
    def test_second_house_column_hot_house_location_area_baoshan(self):
        '''测试位置宝山区域筛选''' 
        logging.info('Step-2:Click second hand house')
        self.assertTrue(self.appiumClient.swipe_and_click_picture(self.image_path+'quanchengremai.png'),'')

        logging.info('测试筛选位置宝山')
        #过滤,dahua
        area_list=['dachang','gucun','gongkang','luodian','luojing','shangda','yuepu','yanghang','songbao',
                    'zhangmiao','gaojing','gongfu','songnan','tonghe','sitang']
        
        for item in area_list:
            self.appiumClient.app.click(self.image_path+'weizhi.png')
            if item=='dachang':
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu.png')
                self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/baoshan.png')
            self.appiumClient.app.click(self.image_path+'secondhouse/weizhi/quyu/baoshan/'+item+'.png')
            self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
            listView=self.appiumClient.get_all_house_source_element_from_second_hand_house()    
            for i in listView:
                self.assertIsNotNone(self.appiumClient.wait_by_name(u'位置'),'无法找到位置')
                i.houseName.click()
                logging.info('Start to test the area:'+item)
                self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/weizhi/quyu/baoshan/baoshan'+item+'.png',30.0),'无法找到提示')
                self.appiumClient.click_by_id('com.fangdd.mobile.fddhouseownersell:id/left_btn')  


class SecondHandHouseColumnHotHouseSortTest(SecondHandHouseColumnNewHouseLocationTest):
    '''二手房精品类目热卖房源排序测试集'''
    def test_second_house_sort_by_unit_price(self):
        '''测试二手房根据单价排序'''        
        self.assertTrue(self.appiumClient.swipe_and_click_picture(self.image_path+'quanchengremai.png'),'')      
        logging.info('测试单价从高到低')        
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        self.appiumClient.app.click(self.image_path+'secondhouse/paixu/danjiayougaodaodi.png')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'weizhi.png'))        
        houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
        self.assertTrue(self.appiumClient.compareUnitPirce(houseList,'down'),'比较失败')
        
        logging.info('测试单价从低到高')
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        self.appiumClient.app.click(self.image_path+'secondhouse/paixu/danjiayoudidaogao.png')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'weizhi.png'))
        houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
        self.assertTrue(self.appiumClient.compareUnitPirce(houseList,'up'),'比较失败')

        
    def test_second_house_sort_by_total_price(self):
        '''测试二手房根据总价排序'''
        
        logging.info('测试总价从高到低')        
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        self.appiumClient.app.click(self.image_path+'secondhouse/paixu/zongjiayougaodaodi.png')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'weizhi.png'))
        houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
        self.assertTrue(self.appiumClient.compareHousePrice(houseList,'down'),'比较失败')
        
        logging.info('测试总价从低到高')
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        self.appiumClient.app.click(self.image_path+'secondhouse/paixu/zongjiayoudidaogao.png')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'weizhi.png'))
        houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
        self.assertTrue(self.appiumClient.compareHousePrice(houseList,'up'),'比较失败')
        
    def test_second_house_sort_by_area(self):
        '''测试二手房根据面积排序'''
        
        logging.info('测试面积从小到大')        
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        self.appiumClient.app.click(self.image_path+'secondhouse/paixu/mianjiyouxiaodaoda.png')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'weizhi.png'))
        houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
        self.assertTrue(self.appiumClient.compareHouseArea(houseList,'down'),'比较失败')
        
        logging.info('测试单价从大到小')
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        self.appiumClient.app.click(self.image_path+'secondhouse/paixu/mianjiyoudadaoxiao.png')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'weizhi.png'))
        houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
        self.assertTrue(self.appiumClient.compareHouseArea(houseList,'up'),'比较失败') 

    
class SecondHandHouseColumnHotHouseFilterTest(SecondHandHouseColumnNewHouseLocationTest):
    '''二手房精品类目热卖房源筛选测试集'''    
    def test_second_house_list_page_filter(self):
        '''测试二手房列表页筛选户型'''
        self.assertTrue(self.appiumClient.swipe_and_click_picture(self.image_path+'quanchengremai.png'),'')
        #debug
        #self.assertEqual(1,2,'test')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'paixu.png',40))
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'shaixuan.png'), '')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/yishi.png'), u'点击一室按钮失败')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'), u'点击确定按钮失败')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'paixu.png',40))
        house_list = self.appiumClient.get_all_house_source_from_second_hand_house()
        for h in house_list:
            self.assertEqual(h.houseLayout.find(u'1室'), 0, u'户型不匹配')
            
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'paixu.png',40))    
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'shaixuan.png'), '')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/liangshi.png'), u'点击两室按钮失败')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'), u'点击确定按钮失败')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'paixu.png',40))
        house_list = self.appiumClient.get_all_house_source_from_second_hand_house()
        for h in house_list:
            self.assertEqual(h.houseLayout.find(u'2室'), 0, u'户型不匹配')
        
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'paixu.png',40))
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'shaixuan.png'), '')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/sanshi.png'), u'点击三室按钮失败')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'), u'点击确定按钮失败')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'paixu.png',40))
        house_list = self.appiumClient.get_all_house_source_from_second_hand_house()
        for h in house_list:
            self.assertEqual(h.houseLayout.find(u'3室'), 0, u'户型不匹配')
        
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'paixu.png',40))
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'shaixuan.png'), '')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/sishi.png'), u'点击四室按钮失败')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'), u'点击确定按钮失败')
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        house_list = self.appiumClient.get_all_house_source_from_second_hand_house()
        for h in house_list:
            self.assertEqual(h.houseLayout.find(u'4室'), 0, u'户型不匹配')
        
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'paixu.png',40))
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'shaixuan.png'), '')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/wushi.png'), u'点击五室以上按钮失败')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'), u'点击确定按钮失败')
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        house_list = self.appiumClient.get_all_house_source_from_second_hand_house()
        for h in house_list:
            flag = -1
            if int(h.houseLayout[0])>=5:
                flag = 0
            self.assertEqual(flag, 0, u'户型不匹配')
        
        logging.info('Step-4:同时选中多个户型进行筛选')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'paixu.png',40))
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'shaixuan.png'), '')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/yishi.png'), u'点击一室按钮失败')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/liangshi.png'), u'点击两室按钮失败')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'), u'点击确定按钮失败')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'paixu.png',40))
        house_list = self.appiumClient.get_all_house_source_from_second_hand_house()
        for h in house_list:
            flag = -1
            #print h.houseLayout
            #print h.houseLayout.find(u'1室')
            #print h.houseLayout.find(u'2室')
            if h.houseLayout.find(u'1室') == 0 or h.houseLayout.find(u'2室') == 0:
                flag = 0
            self.assertEqual(flag, 0, u'户型不匹配')
            
    def test_second_house_label_filter(self):
        '''测试二手房列表页筛选标签'''
        
        logging.info('Step1:点击上门实勘按钮')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'shaixuan.png'), '')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.appiumClient.swipe_to_picture(self.image_path+'homepage/shangmenshikan.png',times=2)
        self.appiumClient.click_by_image(self.image_path+'homepage/default.png')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path+'homepage/shangmenshikan.png'))
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'))
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        house_list=self.appiumClient.get_all_house_source_from_second_hand_house()
        for house in house_list:
            self.assertTrue(house.actualTag,'不是实勘房源')
        
        logging.info('Step2:点击满五唯一按钮')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'shaixuan.png'), '')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.appiumClient.swipe_to_picture(self.image_path+'homepage/manwuweiyi.png',times=2)
        self.assertTrue(self.appiumClient.click_by_image(self.image_path+'homepage/manwuweiyi.png'))
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'))
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        house_list=self.appiumClient.get_all_house_source_from_second_hand_house()
        for house in house_list:
            self.assertGreaterEqual(house.houseLabel.count(u'\u6ee1\u4e94\u552f\u4e00'),1,'没有满五唯一标签')
        
        logging.info('Step3:点击满两年按钮')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'shaixuan.png'), '')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.appiumClient.swipe_to_picture(self.image_path+'homepage/manliangnian.png',times=2)
        self.assertTrue(self.appiumClient.click_by_image(self.image_path+'homepage/manliangnian.png'))
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'))
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        house_list=self.appiumClient.get_all_house_source_from_second_hand_house()
        for house in house_list:
            self.assertGreaterEqual(house.houseLabel.count(u'\u6ee1\u4e94\u552f\u4e00') or house.houseLabel.count(u'\u6ee1\u4e24\u5e74') or house.houseLabel.count(u'\u6ee1\u4e94\u5e74'),1,'没有满五唯一标签')

        logging.info('Step4:点击电梯房按钮')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'shaixuan.png'), '')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.appiumClient.swipe_to_picture(self.image_path+'homepage/diantifang.png',times=2)
        self.assertTrue(self.appiumClient.click_by_image(self.image_path+'homepage/diantifang.png'))
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'))
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        house_list=self.appiumClient.get_all_house_source_from_second_hand_house()
        for house in house_list:
            self.assertGreaterEqual(house.houseLabel.count(u'\u7535\u68af\u623f'),1,'没有满五唯一标签')

        logging.info('Step5:点击地铁房按钮')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'shaixuan.png'), '')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.appiumClient.swipe_to_picture(self.image_path+'homepage/ditiefang.png',times=2)
        self.assertTrue(self.appiumClient.click_by_image(self.image_path+'homepage/ditiefang.png'))
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'))
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        
        house_list=self.appiumClient.get_all_house_source_from_second_hand_house()
        for house in house_list:
            self.assertGreaterEqual(house.houseLabel.count(u'\u5730\u94c1\u623f'),1,'没有满五唯一标签')

    
if __name__ == '__main__':
    suite=unittest.TestSuite()
    
    #新上房源用例
    #suite.addTest(SecondHandHouseColumnNewHouseLocationTest('test_second_house_column_new_house_location_area_baoshan'))
    #suite.addTest(SecondHandHouseColumnNewHouseLocationTest('test_second_house_column_new_house_location_area_minhang'))
    #suite.addTest(SecondHandHouseColumnNewHouseLocationTest('test_second_house_column_new_house_location_area_pudong'))
    #suite.addTest(SecondHandHouseColumnNewHouseLocationTest('test_second_house_column_new_house_location_area_songjiang'))
    #suite.addTest(SecondHandHouseColumnNewHouseLocationTest('test_second_house_column_new_house_location_area_yangpu'))
    #suite.addTest(SecondHandHouseColumnNewHouseLocationTest('test_second_house_column_new_house_location_area_putuo'))
    #suite.addTest(SecondHandHouseColumnNewHouseLocationTest('test_second_house_column_new_house_location_area_jiading'))
    #suite.addTest(SecondHandHouseColumnNewHouseLocationTest('test_second_house_column_new_house_location_area_xuhui'))
    #suite.addTest(SecondHandHouseColumnNewHouseLocationTest('test_second_house_column_new_house_location_area_zhabei'))
    #suite.addTest(SecondHandHouseColumnNewHouseLocationTest('test_second_house_column_new_house_location_area_fengxian'))
    #suite.addTest(SecondHandHouseColumnNewHouseLocationTest('test_second_house_column_new_house_location_area_hongkou'))
    #suite.addTest(SecondHandHouseColumnNewHouseLocationTest('test_second_house_column_new_house_location_area_jinshan'))
    #suite.addTest(SecondHandHouseColumnNewHouseLocationTest('test_second_house_column_new_house_location_area_qingpu'))
    #suite.addTest(SecondHandHouseColumnNewHouseLocationTest('test_second_house_column_new_house_location_area_changning'))
    #suite.addTest(SecondHandHouseColumnNewHouseLocationTest('test_second_house_column_new_house_location_area_jingan'))
    #suite.addTest(SecondHandHouseColumnNewHouseLocationTest('test_second_house_column_new_house_location_area_chongming'))
    #suite.addTest(SecondHandHouseColumnNewHouseLocationTest('test_second_house_column_new_house_location_area_huangpu'))
    
    suite.addTest(SecondHandHouseColumnNewHouseSortTest('test_second_house_sort_by_unit_price'))
    suite.addTest(SecondHandHouseColumnNewHouseSortTest('test_second_house_sort_by_total_price'))
    suite.addTest(SecondHandHouseColumnNewHouseSortTest('test_second_house_sort_by_area'))
    suite.addTest(SecondHandHouseColumnNewHouseFilterTest('test_second_house_list_page_filter'))
    suite.addTest(SecondHandHouseColumnNewHouseFilterTest('test_second_house_label_filter'))
    
    #降价房源用例
    #suite.addTest(SecondHandHouseColumnSaleHouseLocationTest('test_second_house_column_new_house_location_area_baoshan'))
    
    #suite.addTest(SecondHandHouseColumnSaleHouseSortTest('test_second_house_sort_by_unit_price'))
    #suite.addTest(SecondHandHouseColumnSaleHouseSortTest('test_second_house_sort_by_total_price'))
    #suite.addTest(SecondHandHouseColumnSaleHouseSortTest('test_second_house_sort_by_area')) 
    #suite.addTest(SecondHandHouseColumnSaleHouseFilterTest('test_second_house_list_page_filter'))
    #suite.addTest(SecondHandHouseColumnSaleHouseFilterTest('test_second_house_label_filter'))
    
    #全城热卖用例
    #suite.addTest(SecondHandHouseColumnHotHouseLocationTest('test_second_house_column_hot_house_location_area_baoshan'))
    #suite.addTest(SecondHandHouseColumnHotHouseSortTest('test_second_house_sort_by_unit_price'))
    #suite.addTest(SecondHandHouseColumnHotHouseSortTest('test_second_house_sort_by_total_price'))
    #suite.addTest(SecondHandHouseColumnHotHouseSortTest('test_second_house_sort_by_area'))
    #suite.addTest(SecondHandHouseColumnHotHouseFilterTest('test_second_house_list_page_filter'))
    #suite.addTest(SecondHandHouseColumnHotHouseFilterTest('test_second_house_label_filter'))
    
    runner = lib.HTMLTestRunner(stream='TestReport.html',title="Test Result",description='Test Suite')
    runner.run(suite)
    if ((runner.failure_count !=0) or (runner.error_count!=0)):
        raise Exception('Test Suite execute finished,Test suite failed...')