#coding=utf8
import unittest
import os
import sys
import logging
import time
import traceback
import platform
sys.path.append('../../..')
import lib
from testCase.AndroidTestCaseBaseClass import AndroidTestCaseBaseClass

class SecondHandHouseSortTest(AndroidTestCaseBaseClass):
    '''二手房列表排序测试集'''
    #Author Huangfu
    #Date 2015/12/2
    #Program:
    #    Test second hand house
    # @classmethod
    # def classLoadConfig(cls):
    #     '''Integrate to jenkins,if exists the environment varible,set the config file with the value'''
    #     if os.environ.has_key('JENKINS_HOME'):
    #         cls.conf_name='android.cfg'
    #         cls.cf = lib.Config(cls.conf_name)
    #         logging.info('Version: '+ os.environ['JOB_NAME'])
    #     else:
    #         cls.conf_name='android.cfg'
    #         cls.cf = lib.Config(cls.conf_name)
    #
    # @classmethod
    # def InitAppiumClient(cls,apkPath=False):
    #     cls.classInit=True
    #     cls.classLoadConfig()
    #     if os.environ.has_key('JENKINS_HOME'):
    #         cls.appiumClient=lib.AppiumApi(deviceName=os.environ['deviceName'],platformVersion=os.environ['platformVersion'],serverPort=os.environ['serverPort'],apkPath=apkPath)
    #     else:
    #         cls.appiumClient=lib.AppiumApi(deviceName=cls.cf.device_name,platformVersion=cls.cf.platform_version,serverPort=cls.cf.server_port,apkPath=apkPath)
    #
    #     if cls.appiumClient.wait_by_name(u'发现新版本') is not None:
    #         cls.appiumClient.click_by_name(u'取消')
    
    @classmethod
    def setUpClass(cls):
        AndroidTestCaseBaseClass.classInitAppiumClient()
        
    @classmethod
    def tearDownClass(cls):  
        cls.appiumClient.stop_driver()
        
    def test_second_house_sort_by_unit_price(self):
        '''测试二手房根据单价排序'''
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'),'无法找到二手房')
        self.assertIsNotNone(self.appiumClient.wait_by_name(u'位置'),'无法找到位置')
        
        logging.info('测试单价从高到低')        
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        self.appiumClient.app.click(self.image_path+'secondhouse/paixu/danjiayougaodaodi.png')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'weizhi.png'))        
        houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
        self.assertTrue(self.appiumClient.compareUnitPirce(houseList,'down'),'比较失败')
        
        logging.info('测试单价从低到高')
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        self.appiumClient.app.click(self.image_path+'secondhouse/paixu/danjiayoudidaogao.png')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'weizhi.png'))
        houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
        self.assertTrue(self.appiumClient.compareUnitPirce(houseList,'up'),'比较失败')

        
    def test_second_house_sort_by_total_price(self):
        '''测试二手房根据总价排序'''
        
        logging.info('测试总价从高到低')        
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        self.appiumClient.app.click(self.image_path+'secondhouse/paixu/zongjiayougaodaodi.png')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'weizhi.png'))
        houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
        self.assertTrue(self.appiumClient.compareHousePrice(houseList,'down'),'比较失败')
        
        logging.info('测试总价从低到高')
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        self.appiumClient.app.click(self.image_path+'secondhouse/paixu/zongjiayoudidaogao.png')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'weizhi.png'))
        houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
        self.assertTrue(self.appiumClient.compareHousePrice(houseList,'up'),'比较失败')
        
    def test_second_house_sort_by_area(self):
        '''测试二手房根据面积排序'''
        
        logging.info('测试面积从小到大')        
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        self.appiumClient.app.click(self.image_path+'secondhouse/paixu/mianjiyouxiaodaoda.png')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'weizhi.png'))
        houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
        self.assertTrue(self.appiumClient.compareHouseArea(houseList,'down'),'比较失败')
        
        logging.info('测试单价从大到小')
        self.appiumClient.click_by_image(self.image_path + 'paixu.png')
        self.appiumClient.app.click(self.image_path+'secondhouse/paixu/mianjiyoudadaoxiao.png')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'weizhi.png'))
        houseList=self.appiumClient.get_all_house_source_from_second_hand_house()
        self.assertTrue(self.appiumClient.compareHouseArea(houseList,'up'),'比较失败')
        
if __name__ == '__main__':
    suite=unittest.TestSuite()
    suite.addTest(SecondHandHouseSortTest('test_second_house_sort_by_unit_price'))
    suite.addTest(SecondHandHouseSortTest('test_second_house_sort_by_total_price'))
    suite.addTest(SecondHandHouseSortTest('test_second_house_sort_by_area'))
    runner = lib.HTMLTestRunner(stream='TestReport.html',title="Test Result",description='Test Suite')
    runner.run(suite)
    if ((runner.failure_count !=0) or (runner.error_count!=0)):
        raise Exception('Test Suite execute finished,Test suite failed...')
    