#coding=utf8
import unittest
import os
import sys
import logging
import time
import traceback
import platform
sys.path.append('../../..')
import lib
from testCase.AndroidTestCaseBaseClass import AndroidTestCaseBaseClass

class SecondHandHouseFilterTest(AndroidTestCaseBaseClass):
    '''二手房列表排序测试集'''
    #Author Huangfu
    #Date 2015/12/2
    #Program:
    #    Test second hand house
    # @classmethod
    # def classLoadConfig(cls):
    #     '''Integrate to jenkins,if exists the environment varible,set the config file with the value'''
    #     if os.environ.has_key('JENKINS_HOME'):
    #         cls.conf_name='android.cfg'
    #         cls.cf = lib.Config(cls.conf_name)
    #         logging.info('Version: '+ os.environ['JOB_NAME'])
    #     else:
    #         cls.conf_name='android.cfg'
    #         cls.cf = lib.Config(cls.conf_name)
    #
    # @classmethod
    # def InitAppiumClient(cls,apkPath=False):
    #     cls.classInit=True
    #     cls.classLoadConfig()
    #     if os.environ.has_key('JENKINS_HOME'):
    #         cls.appiumClient=lib.AppiumApi(deviceName=os.environ['deviceName'],platformVersion=os.environ['platformVersion'],serverPort=os.environ['serverPort'],apkPath=apkPath)
    #     else:
    #         cls.appiumClient=lib.AppiumApi(deviceName=cls.cf.device_name,platformVersion=cls.cf.platform_version,serverPort=cls.cf.server_port,apkPath=apkPath)
    #
    #     if cls.appiumClient.wait_by_name(u'发现新版本') is not None:
    #         cls.appiumClient.click_by_name(u'取消')
    
    @classmethod
    def setUpClass(cls):
        AndroidTestCaseBaseClass.classInitAppiumClient()
        
    @classmethod
    def tearDownClass(cls):  
        cls.appiumClient.stop_driver()
        
if __name__ == '__main__':
    suite=unittest.TestSuite()
    suite.addTest(SecondHandHouseFilterTest('test_second_house_sort_by_area'))
    runner = lib.HTMLTestRunner(stream='TestReport.html',title="Test Result",description='Test Suite')
    runner.run(suite)
    if ((runner.failure_count !=0) or (runner.error_count!=0)):
        raise Exception('Test Suite execute finished,Test suite failed...')
    