#coding=utf8
import unittest
import os
import sys
import logging
import time
import traceback
import platform
sys.path.append('../../..')
import lib
from testCase.AndroidTestCaseBaseClass import AndroidTestCaseBaseClass

class SearchBoxTest(AndroidTestCaseBaseClass):
    '''搜索框测试'''
    def test_click_search_box(self):
        '''测试搜索框清除历史记录'''
        logging.info('Step-1:打开房多多app')
        self.InitAppiumClient()
        logging.info('Step-2:检查搜索框是否存在')
        self.assertIsNotNone(self.appiumClient.wait_by_name(u'请输入小区名、板块'),'can not found the element')
        logging.info('Step-3:点击搜索框，查看清楚搜索记录')
        self.assertTrue(self.appiumClient.click_by_name(u'请输入小区名、板块'),'click failed')
        #self.assertIsNotNone(self.appiumClient.wait_by_name(u'清楚历史记录'),'click failed')
        logging.info('Step-4:点击取消，回到主页')
        self.assertTrue(self.appiumClient.click_by_name(u'取消'),'click failed')
        self.assertIsNotNone(self.appiumClient.wait_by_name(u'二手房'),u'无法找到二手房')

    def test_search_box_with_swipe(self):
        '''测试屏幕滑动搜索框状态'''
        logging.info('Step-1:打开房多多app')
        self.InitAppiumClient()
        logging.info('Step-2:得到搜索框的坐标')
        location1=self.appiumClient.wait_by_name(u'上海').location
        location2=self.appiumClient.wait_by_name(u'请输入小区名、板块').location
        logging.info('Step-3:向上滑动一次')
        self.appiumClient.swipe_from_middle_to_top()
        locationNew1=self.appiumClient.wait_by_name(u'上海').location
        locationNew2=self.appiumClient.wait_by_name(u'请输入小区名、板块').location
        logging.info('Step-4:比较搜索框位置是否改变')        
        self.assertEqual(location1,locationNew1,'位置改变')
        self.assertEqual(location2,locationNew2,'位置改变')
        
    def test_location_in_search_box(self):
        '''测试搜索框定位城市'''
        logging.info('Step-1:打开房多多app')
        self.InitAppiumClient()
        logging.info('Step-2:点击定位城市上海')
        self.assertTrue(self.appiumClient.click_by_name(u'上海'),'click failed')
        logging.info('Step-3:点击定位城市苏州')
        self.assertTrue(self.appiumClient.click_by_name(u'苏州'),'click failed')
        self.assertTrue(self.appiumClient.click_by_name(u'苏州'),'click failed')
        logging.info('Step-4:点击定位城市杭州')        
        #self.assertTrue(self.appiumClient.click_by_name(u'杭州'),'click failed')
        #self.assertTrue(self.appiumClient.click_by_name(u'杭州'),'click failed')
        logging.info('Step-5:点击定位城市南京')        
        #self.assertTrue(self.appiumClient.click_by_name(u'南京'),'click failed')
        #self.assertTrue(self.appiumClient.click_by_name(u'南京'),'click failed')        
        logging.info('Step-5:点击定位城市白山')        
        self.assertTrue(self.appiumClient.click_by_name(u'白山'),'click failed')
        self.assertTrue(self.appiumClient.click_by_name(u'白山'),'click failed')        
        logging.info('Step-6:点击定位城市北京')
        self.assertTrue(self.appiumClient.click_by_name(u'北京'),'click failed')
        self.assertTrue(self.appiumClient.click_by_name(u'北京'),'click failed')
        self.assertTrue(self.appiumClient.click_by_name(u'上海'),'click failed')
        
    def test_click_letter_location_in_search_box(self):    
        '''测试搜索框字母按键'''
        logging.info('Step-1:打开房多多app')
        self.InitAppiumClient()
        logging.info('Step-2:点击上海进入定位选择')
        self.assertTrue(self.appiumClient.click_by_name(u'上海'),'click failed')
        logging.info('Step-3:点击各个城市查看结果')
        self.appiumClient.app.wait(self.image_path+'searchbox/remen.png',10.0)
        self.appiumClient.app.click(self.image_path+'searchbox/B.png')
        self.assertTrue(self.appiumClient.app.safeWait(self.image_path+'searchbox/clickB.png'),'图像错误')
        self.appiumClient.app.click(self.image_path+'searchbox/G.png')
        self.assertTrue(self.appiumClient.app.safeWait(self.image_path+'searchbox/clickG.png'),'图像错误')
        self.appiumClient.app.click(self.image_path+'searchbox/K.png')
        self.assertTrue(self.appiumClient.app.safeWait(self.image_path+'searchbox/clickK.png'),'图像错误')        
        self.appiumClient.app.click(self.image_path+'searchbox/T.png')
        self.assertTrue(self.appiumClient.app.safeWait(self.image_path+'searchbox/clickT.png'),'图像错误')        
        logging.info('Step-4:点击返回按钮,查看是否回到主页')
        self.appiumClient.app.click(self.image_path+'searchbox/back.png')
        self.assertIsNotNone(self.appiumClient.wait_by_name(u'二手房'),'未回到主页')
                        
if __name__ == '__main__':
    suite=unittest.TestSuite()
    suite.addTest(SearchBoxTest('test_location_in_search_box'))
    runner = lib.HTMLTestRunner(stream='TestReport.html',title="Test Result",description='Test Suite')
    runner.run(suite)        