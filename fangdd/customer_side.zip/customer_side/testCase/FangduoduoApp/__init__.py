#encoding=utf-8

'''app测试用例集'''
from HomePageTest.HomePageTest import HomePageTest
from LoginTest.LoginTest import LoginTest
from SearchBoxTest.SearchBoxTest import SearchBoxTest

'''app二手房测试用例集'''
from SecondHandHouseTest.SecondHandHouseTest import SecondHandHouseTest
from SecondHandHouseTest.SecondHandHouseSortTest import SecondHandHouseSortTest
from SecondHandHouseTest.SecondHandHouseLocationTest import SecondHandHouseLocationTest
from SecondHandHouseTest.SecondHandHouseLocationTest import SecondHandHouseLocationTestSubWay

'''app地铁房测试用例集'''
from SubwayHouseTest.SubwayHouseTest import SubwayHouseTest
from SubwayHouseTest.SubwayHouseLocationTest import SubwayHouseLocationTest

'''app二手房精品类目'''
from SecondHandHouseTest.SecondHandHouseColumnTest import *