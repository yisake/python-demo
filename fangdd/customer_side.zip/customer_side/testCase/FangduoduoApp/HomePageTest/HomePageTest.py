#coding=utf8
import unittest
import os
import sys
import logging
import time
import traceback
import platform
sys.path.append('../../..')
import lib
from testCase.AndroidTestCaseBaseClass import AndroidTestCaseBaseClass

class HomePageTest(AndroidTestCaseBaseClass):
    '''首页搜索功能测试'''
    def test_click_search_box(self):
        '''测试搜索框'''
        logging.info('Step-1:打开房多多app')
        self.InitAppiumClient()
        logging.info('Step-2:点击输入小区名')
        self.assertTrue(self.appiumClient.click_by_name(u'请输入小区名、板块'),'click failed')
        logging.info('Step-3:查看输入小区名称是否存在')
        self.assertTrue(self.appiumClient.wait_by_name(u'请输入小区名、板块'),'查找失败')
        logging.info('Step-4:查看暂无搜索记录是否存在')
        self.assertTrue(self.appiumClient.wait_by_name(u'暂无搜索记录'),'查找失败')
        self.assertTrue(self.appiumClient.click_by_name(u'取消'),'click failed')
        self.assertTrue(self.appiumClient.wait_by_name(u'二手房'),'查找失败')
        
    def test_search_history(self):
        '''测试搜索记录'''
        logging.info('Step-1:打开房多多app')
        self.InitAppiumClient()
        logging.info('Step-2:点击输入小区名')
        self.assertTrue(self.appiumClient.click_by_name(u'请输入小区名、板块'),'click failed')
        logging.info('Step-3:输入广中苑')
        ele=self.appiumClient.wait_by_name(u'请输入小区名、板块')
        self.assertTrue(self.appiumClient.enter(ele,u'广中苑'),'输入失败')
        location=self.appiumClient.app.wait(self.image_path+'homepage/guangzhongyuan.png')
        self.appiumClient.app.click(location)
        self.appiumClient.app.click(self.image_path+'back.png')
        logging.info('Step-4:输入佳宁花园')
        self.assertTrue(self.appiumClient.click_by_name(u'请输入小区名、板块'),'click failed')
        ele=self.appiumClient.wait_by_name(u'请输入小区名、板块')
        self.assertTrue(self.appiumClient.enter(ele,u'佳宁花园'),'输入失败')
        location=self.appiumClient.app.wait(self.image_path+'homepage/jianinghuayuan.png')
        self.appiumClient.app.click(location)        
        self.appiumClient.app.click(self.image_path+'back.png')

    def test_clear_search_history(self):
        """测试清空搜索记录"""
        logging.info('Step-1:打开房多多app')
        self.InitAppiumClient()
        logging.info('Step-2:点击输入小区名')
        self.assertTrue(self.appiumClient.click_by_name(u'请输入小区名、板块'), 'click failed')
        logging.info('Step-3:输入广中苑')
        ele = self.appiumClient.wait_by_name(u'请输入小区名、板块')
        self.assertTrue(self.appiumClient.enter(ele, u'广中苑'), '输入失败')
        self.appiumClient.click_by_image(self.image_path + 'homepage/guangzhongyuan.png')
        self.appiumClient.click_by_image(self.image_path + 'back.png')
        logging.info('Step-4:清空搜索记录')
        self.assertTrue(self.appiumClient.click_by_name(u'请输入小区名、板块'), 'ckick failed')
        self.assertIsNotNone(self.appiumClient.wait_by_name(u'搜索记录'), u'没有搜索记录')
        self.assertTrue(self.appiumClient.click_by_name(u'清除搜索记录'), u'清空搜索记录失败')
        self.assertIsNotNone(self.appiumClient.wait_by_name(u'暂无搜索记录'), u'没有清空搜索记录')

    def test_search_new_house(self):
        """测试搜索新房"""
        logging.info('Step-1:打开房多多app')
        self.InitAppiumClient()
        logging.info('Step-2:点击输入小区名')
        self.assertTrue(self.appiumClient.click_by_name(u'请输入小区名、板块'), 'click failed')
        logging.info('Step-3:输入一个新房楼盘万科有山')
        ele = self.appiumClient.wait_by_name(u'请输入小区名、板块')
        self.assertTrue(self.appiumClient.enter(ele, u'万科有山'), '输入失败')
        self.appiumClient.click_by_image(self.image_path + 'homepage/wankeyoushan.png')
        logging.info('Step-4:验证是否进入到新盘详情页面')
        self.assertIsNotNone(self.appiumClient.wait_by_name(u'万科有山'), u'没有进入楼盘详情页面')
        self.appiumClient.click_by_id('com.fangdd.mobile.fddhouseownersell:id/left_btn')

    def test_search_new_house_and_second_house(self):
        """测试同时搜索新房和二手房"""
        logging.info('Step-1:打开房多多app')
        self.InitAppiumClient()
        logging.info('Step-2:点击输入小区名')
        self.assertTrue(self.appiumClient.click_by_name(u'请输入小区名、板块'), 'click failed')
        logging.info('Step-3:输入关键词万科')
        ele = self.appiumClient.wait_by_id('com.fangdd.mobile.fddhouseownersell:id/edt_input')
        logging.info('Step-4:验证是否混合出现新房和二手房的楼盘')
        self.assertTrue(self.appiumClient.enter(ele, u'万科有山'), '输入失败')        
        self.assertTrue(self.appiumClient.wait_by_image(self.image_path + 'homepage/wankeyoushan.png'), u'没有出现二手房楼盘')
        ele.clear()
        ele.send_keys(u'广中苑')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/guangzhongyuan.png'), u'没有出现新房楼盘')
        self.appiumClient.click_by_id('com.fangdd.mobile.fddhouseownersell:id/back_button')
        
    def test_search_with_huxing(self):
        """测试使用户型筛选"""
        logging.info('Step-1:打开房多多app')
        self.InitAppiumClient()
        logging.info('Step-2:点击二手房')
        self.assertTrue(self.appiumClient.click_by_name(u'二手房'), 'click failed')
        logging.info('Step-3:选择单个户型进行筛选')
        self.appiumClient.wait_by_name(u'筛选')
        self.appiumClient.swipe_from_middle_to_top()
        self.appiumClient.click_by_name(u'筛选')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/yishi.png'), u'点击一室按钮失败')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'), u'点击确定按钮失败')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
        house_list = self.appiumClient.get_all_house_source_from_second_hand_house()
        for h in house_list:
            self.assertEqual(h.houseLayout.find(u'1室'), 0, u'户型不匹配')
        self.appiumClient.wait_by_name(u'筛选')
        self.appiumClient.swipe_from_middle_to_top()
        self.appiumClient.click_by_name(u'筛选')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/liangshi.png'), u'点击两室按钮失败')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'), u'点击确定按钮失败')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
        house_list = self.appiumClient.get_all_house_source_from_second_hand_house()
        for h in house_list:
            self.assertEqual(h.houseLayout.find(u'2室'), 0, u'户型不匹配')
        self.appiumClient.wait_by_name(u'筛选')
        self.appiumClient.swipe_from_middle_to_top()
        self.appiumClient.click_by_name(u'筛选')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/sanshi.png'), u'点击三室按钮失败')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'), u'点击确定按钮失败')
        house_list = self.appiumClient.get_all_house_source_from_second_hand_house()
        for h in house_list:
            self.assertEqual(h.houseLayout.find(u'3室'), 0, u'户型不匹配')
        self.appiumClient.wait_by_name(u'筛选')
        self.appiumClient.swipe_from_middle_to_top()
        self.appiumClient.click_by_name(u'筛选')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/sishi.png'), u'点击四室按钮失败')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'), u'点击确定按钮失败')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
        house_list = self.appiumClient.get_all_house_source_from_second_hand_house()
        for h in house_list:
            self.assertEqual(h.houseLayout.find(u'4室'), 0, u'户型不匹配')
        self.appiumClient.wait_by_name(u'筛选')
        self.appiumClient.swipe_from_middle_to_top()
        self.appiumClient.click_by_name(u'筛选')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/wushi.png'), u'点击五室以上按钮失败')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'), u'点击确定按钮失败')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
        house_list = self.appiumClient.get_all_house_source_from_second_hand_house()
        for h in house_list:
            flag = -1
            if int(h.houseLayout[0]) >=5 :
                flag = 0
            self.assertEqual(flag, 0, u'户型不匹配')
        logging.info('Step-4:同时选中多个户型进行筛选')
        self.appiumClient.wait_by_name(u'筛选')
        self.appiumClient.swipe_from_middle_to_top()
        self.appiumClient.click_by_name(u'筛选')
        self.appiumClient.click_by_image(self.image_path + 'homepage/default.png')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/yishi.png'), u'点击一室按钮失败')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/liangshi.png'), u'点击两室按钮失败')
        self.assertTrue(self.appiumClient.click_by_image(self.image_path + 'homepage/confirm.png'), u'点击确定按钮失败')
        self.assertIsNotNone(self.appiumClient.app.safeWait(self.image_path+'secondhouse/gongzhaodao.png'))
        house_list = self.appiumClient.get_all_house_source_from_second_hand_house()
        for h in house_list:
            flag = -1
            if h.houseLayout.find(u'1室') == 0 or h.houseLayout.find(u'2室') == 0:
                flag = 0
            self.assertEqual(flag, 0, u'户型不匹配')
        
if __name__ == '__main__':
    suite=unittest.TestSuite()
    suite.addTest(HomePageTest('test_search_history'))
    suite.addTest(HomePageTest('test_search_new_house'))
    suite.addTest(HomePageTest('test_search_new_house_and_second_house'))
    #suite.addTest(HomePageTest('test_search_new_house_and_second_house'))
    runner = lib.HTMLTestRunner(stream='TestReport.html',title="Test Result",description='Test Suite')
    runner.run(suite)