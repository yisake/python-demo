#coding=utf8
import unittest
import sys
sys.path.append('../..')
import lib
import binascii
import logging
from testCase.RestTestCaseBaseClass import RestTestCaseBaseClass

class RestChoice(RestTestCaseBaseClass):
    '''筛选用例接口测试 method:GET URL:search?'''    
    
    def test_choiceHouse1(self):
        '''测试筛选:Case1:价格选择350--850万 @Author:念念'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        response,content = self.buyerRestClient.get(self.buyerRestClient.url+'search?city_id=121&from=0&house_price=350-850&lat=31.284094&lng=121.446309',verify=False)
        for house in content['data']['records']:
            self.assertTrue(350<=house['house_price']<=850, '')
        
    def test_choiceHouse2(self):
        '''测试筛选:Case2:价格选择50--130平 @Author:念念'''
        self.InitRestClient( )
        self.buyerRestClient.login_in()
        response,content= self.buyerRestClient.get(self.buyerRestClient.url+'search?city_id=121&from=0&house_area=50-130&lat=31.284094&lng=121.446309',verify=False)
        for house in content['data']['records']:
            self.assertTrue(50<=house['house_area']<=130, '')    
    
    def test_choiceHouse3(self):
        '''测试筛选:Case3:户型选择“二室”@Author:念念'''
        self.InitRestClient( )
        self.buyerRestClient.login_in()
        payload={'city_id':'121','lat':'31.284094','lng':'121.446309','from':'0','room':'2'}
        response,content= self.buyerRestClient.get(self.buyerRestClient.url+'search'  ,verify=False,params=payload)
        for house in content['data']['records']:
            self.assertTrue(house['room_count']==2, '')

    def test_filter_with_shang_men_shi_kan(self):
        '''测试上门实勘筛选 @Author 皇甫'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        payload={
                 'city_id' :'121',
                 'lat' :'31.284094',
                 'lng' :'121.446309',
                 'from' :'0',
                 'size' :'10' ,
                 'tag' : '上门验真' ,
        }
        response,content= self.buyerRestClient.get(self.buyerRestClient.url+'search'  ,verify=False,params=payload)  
        
        for i in content['data']['records']:
            logging.info(i)
            self.assertTrue(i['verified'], '')
        
    def test_filter_with_wu_dai_kuan(self):
        '''测试无贷款筛选 @Author 皇甫'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        for i in range(0,11): 
            payload={
                     'city_id' :'121',
                     'lat' :'31.284094',
                     'lng' :'121.446309',
                     'from' :str(i),
                     'size' :'10' ,
                     'tag' : '无贷款' ,
            }
            response,content= self.buyerRestClient.get(self.buyerRestClient.url+'search'  ,verify=False,params=payload)
            for i in content['data']['records']:
                if i['tag'][0]==u'今日可看':
                    continue
                self.assertEqual(i['tag'][0], u'无贷款', '')
    
    def test_filter_with_man_wu_wei_yi(self):
        '''测试满五唯一搜索接口 @Author 皇甫'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        for i in range(0,1):
            payload={
                 'city_id' :'121',
                 'lat' :'31.284094',
                 'lng' :'121.446309',
                 'from' : str(i),
                 'size' :'10' ,
                 'tag' : ['满五年' ,'唯一住房' ] ,
            }
            response,content= self.buyerRestClient.get(self.buyerRestClient.url+'search'  ,verify=False,params=payload)
            for i in content['data']['records']:
                if i['tag'][0]==u'今日可看':
                    continue                
                logging.info(i)
                self.assertEqual(i['tag'][0], u'满五唯一', '')
                #num = bin(self.get_sql_info('select house_tag from fdd_second_house.t_second_house where house_id='+str(i['fangyuan_id' ]))[0][0])[2:]
                #self.assertEqual( num[-1],'1' , '' )
                #self.assertEqual( num[-2],'1' , '' )
    
    def test_filter_with_man_liang_nian(self):
        '''测试满两年过滤 @Author 皇甫'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        for i in range(0,1):
            payload={
                 'city_id' :'121',
                 'lat' :'31.284094',
                 'lng' :'121.446309',
                 'from' : str(i),
                 'size' :'10' ,
                 'tag' : '满两年' ,
            }
            response,content= self.buyerRestClient.get(self.buyerRestClient.url+'search'  ,verify=False,params=payload)
            for i in content['data']['records']:
                logging.info(i)
                if i['tag'][0]==u'今日可看':
                    continue                
                self.assertTrue(i['tag'][0]==u'满五唯一' or i['tag'][0]==u'满两年'  or i['tag'][0]==u'满五年', '' )
    
    def test_filter_with_dian_tie_fang(self):
        '''测试电梯房过滤 @Author 皇甫'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        for i in range(0,1):
            payload={
                 'city_id' :'121',
                 'lat' :'31.284094',
                 'lng' :'121.446309',
                 'from' : str(i),
                 'size' :'10' ,
                 'tag' : '地铁房' ,
            }
            response,content= self.buyerRestClient.get(self.buyerRestClient.url+'search'  ,verify=False,params=payload)
            for i in content['data']['records']:
                logging.info(i)
                if i['tag'][0]==u'今日可看':
                    continue                
                self.assertTrue(i['tag'][0]==u'地铁房' , '' )

    
    def test_filter_with_xue_qu_fang(self):
        '''测试学区房筛选 @Author 皇甫'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        for i in range(0,1):
            payload={
                 'city_id' :'121',
                 'lat' :'31.284094',
                 'lng' :'121.446309',
                 'from' : str(i),
                 'size' :'10' ,
                 'tag' : '学区房' ,
            }
            response,content= self.buyerRestClient.get(self.buyerRestClient.url+'search'  ,verify=False,params=payload)
            for i in content['data']['records']:
                logging.info(i)
                if i['tag'][0]==u'今日可看':
                    continue                
                self.assertTrue(i['tag'][0]==u'学区房' , '' )

    def test_filter_with_zongjia_100_yi_xia(self):
        '''测试学区房筛选 @Author 皇甫'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        for i in range(0,1):
            payload={
                 'city_id' :'121',
                 'lat' :'31.284094',
                 'lng' :'121.446309',
                 'from' : str(i),
                 'size' :'10' ,
                 'house_price' : '-100' ,
            }
            response,content= self.buyerRestClient.get(self.buyerRestClient.url+'search'  ,verify=False,params=payload)
            for i in content['data']['records']:
                logging.info(i)
                self.assertTrue(0<i['house_price']<=100 , '' )

    def test_filter_with_zongjia_100_150(self):
        '''测试总价100-150万筛选 @Author 皇甫'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        for i in range(0,1):
            payload={
                 'city_id' :'121',
                 'lat' :'31.284094',
                 'lng' :'121.446309',
                 'from' : str(i),
                 'size' :'10' ,
                 'house_price' : '100-150' ,
            }
            response,content= self.buyerRestClient.get(self.buyerRestClient.url+'search'  ,verify=False,params=payload)
            for i in content['data']['records']:
                logging.info(i)
                self.assertTrue(100<=i['house_price']<=150 , '' )
                
    def test_filter_with_zongjia_150_200(self):
        '''测试总价150-200万筛选 @Author 皇甫'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        for i in range(0,1):
            payload={
                 'city_id' :'121',
                 'lat' :'31.284094',
                 'lng' :'121.446309',
                 'from' : str(i),
                 'size' :'10' ,
                 'house_price' : '150-200' ,
            }
            response,content= self.buyerRestClient.get(self.buyerRestClient.url+'search'  ,verify=False,params=payload)
            for i in content['data']['records']:
                logging.info(i)
                self.assertTrue(150<=i['house_price']<=200 , '' )

    def test_filter_with_zongjia_200_300(self):
        '''测试总价200-300万筛选 @Author 皇甫'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        for i in range(0,1):
            payload={
                 'city_id' :'121',
                 'lat' :'31.284094',
                 'lng' :'121.446309',
                 'from' : str(i),
                 'size' :'10' ,
                 'house_price' : '200-300' ,
            }
            response,content= self.buyerRestClient.get(self.buyerRestClient.url+'search'  ,verify=False,params=payload)
            for i in content['data']['records']:
                logging.info(i)
                self.assertTrue(200<=i['house_price']<=300 , '' )

    def test_filter_with_zongjia_300_400(self):
        '''测试总价300-400万筛选 @Author 皇甫'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        for i in range(0,1):
            payload={
                 'city_id' :'121',
                 'lat' :'31.284094',
                 'lng' :'121.446309',
                 'from' : str(i),
                 'size' :'10' ,
                 'house_price' : '300-400' ,
            }
            response,content= self.buyerRestClient.get(self.buyerRestClient.url+'search'  ,verify=False,params=payload)
            for i in content['data']['records']:
                logging.info(i)
                self.assertTrue(300<=i['house_price']<=400 , '' )

    def test_filter_with_zongjia_400_500(self):
        '''测试总价400-500万筛选'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        for i in range(0,1):
            payload={
                 'city_id' :'121',
                 'lat' :'31.284094',
                 'lng' :'121.446309',
                 'from' : str(i),
                 'size' :'10' ,
                 'house_price' : '400-500' ,
            }
            response,content= self.buyerRestClient.get(self.buyerRestClient.url+'search'  ,verify=False,params=payload)
            for i in content['data']['records']:
                logging.info(i)
                self.assertTrue(400<=i['house_price']<=500 , '' )
                
    def test_filter_with_zongjia_500_700(self):
        '''测试总价500-700万筛选'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        for i in range(0,1):
            payload={
                 'city_id' :'121',
                 'lat' :'31.284094',
                 'lng' :'121.446309',
                 'from' : str(i),
                 'size' :'10' ,
                 'house_price' : '500-700' ,
            }
            response,content= self.buyerRestClient.get(self.buyerRestClient.url+'search'  ,verify=False,params=payload)
            for i in content['data']['records']:
                logging.info(i)
                self.assertTrue(500<=i['house_price']<=700 , '' )                

    def test_filter_with_zongjia_700_1000(self):
        '''测试总价700-1000万筛选 @Author 皇甫'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        for i in range(0,1):
            payload={
                 'city_id' :'121',
                 'lat' :'31.284094',
                 'lng' :'121.446309',
                 'from' : str(i),
                 'size' :'10' ,
                 'house_price' : '700-1000' ,
            }
            response,content= self.buyerRestClient.get(self.buyerRestClient.url+'search'  ,verify=False,params=payload)
            for i in content['data']['records']:
                logging.info(i)
                self.assertTrue(700<=i['house_price']<=1000 , '' )   
                
    def test_filter_with_zongjia_1000_up(self):
        '''测试总价500-700万筛选'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        for i in range(0,1):
            payload={
                 'city_id' :'121',
                 'lat' :'31.284094',
                 'lng' :'121.446309',
                 'from' : str(i),
                 'size' :'10' ,
                 'house_price' : '1000-' ,
            }
            response,content= self.buyerRestClient.get(self.buyerRestClient.url+'search'  ,verify=False,params=payload)
            for i in content['data']['records']:
                logging.info(i)
                self.assertTrue(i['house_price']>=1000 , '' )
                
    def test_filter_with_1_shi(self):
        '''测试接口搜索一室筛选 @Author 皇甫'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        for i in range(0,1):
            payload={
                 'city_id' :'121',
                 'lat' :'31.284094',
                 'lng' :'121.446309',
                 'from' : str(i),
                 'size' :'10' ,
                 'room' : '1' ,
            }
            response,content= self.buyerRestClient.get(self.buyerRestClient.url+'search'  ,verify=False,params=payload)
            for i in content['data']['records']:
                logging.info(i)
                self.assertTrue(i['room_count']==1 , '' )    
    
    def test_filter_with_2_shi(self):
        '''测试接口搜索两室筛选 @Author 皇甫'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        for i in range(0,1):
            payload={
                 'city_id' :'121',
                 'lat' :'31.284094',
                 'lng' :'121.446309',
                 'from' : str(i),
                 'size' :'10' ,
                 'room' : '2' ,
            }
            response,content= self.buyerRestClient.get(self.buyerRestClient.url+'search'  ,verify=False,params=payload)
            for i in content['data']['records']:
                logging.info(i)
                self.assertTrue(i['room_count']==2 , '' )

    def test_filter_with_3_shi(self):
        '''测试接口搜索两室筛选 @Author 皇甫'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        for i in range(0,1):
            payload={
                 'city_id' :'121',
                 'lat' :'31.284094',
                 'lng' :'121.446309',
                 'from' : str(i),
                 'size' :'10' ,
                 'room' : '3' ,
            }
            response,content= self.buyerRestClient.get(self.buyerRestClient.url+'search'  ,verify=False,params=payload)
            for i in content['data']['records']:
                logging.info(i)
                self.assertTrue(i['room_count']==3 , '' )

    def test_filter_with_4_shi(self):
        '''测试接口搜索两室筛选 @Author 皇甫'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        for i in range(0,1):
            payload={
                 'city_id' :'121',
                 'lat' :'31.284094',
                 'lng' :'121.446309',
                 'from' : str(i),
                 'size' :'10' ,
                 'room' : '4' ,
            }
            response,content= self.buyerRestClient.get(self.buyerRestClient.url+'search'  ,verify=False,params=payload)
            for i in content['data']['records']:
                logging.info(i)
                self.assertTrue(i['room_count']==4 , '' )

    def test_filter_with_5_shi(self):
        '''测试接口搜索两室筛选 @Author 皇甫'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        for i in range(0,1):
            payload={
                 'city_id' :'121',
                 'lat' :'31.284094',
                 'lng' :'121.446309',
                 'from' : str(i),
                 'size' :'10' ,
                 'room' : '5-' ,
            }
            response,content= self.buyerRestClient.get(self.buyerRestClient.url+'search'  ,verify=False,params=payload)
            for i in content['data']['records']:
                logging.info(i)
                self.assertTrue(i['room_count']>=5 , '' )


if __name__ == '__main__':
    suite=unittest.TestSuite()
    #suite.addTest(RestChoice('test_choiceHouse1'))
    #suite.addTest(RestChoice('test_choiceHouse2'))
    #suite.addTest(RestChoice('test_choiceHouse3'))
    #suite.addTest(RestChoice('test_filter_with_shang_men_shi_kan'))
    suite.addTest(RestChoice('test_filter_with_wu_dai_kuan'))
    #suite.addTest(RestChoice('test_filter_with_man_wu_wei_yi'))
    #suite.addTest(RestChoice('test_filter_with_man_liang_nian'))
    #suite.addTest(RestChoice('test_filter_with_dian_tie_fang'))
    #suite.addTest(RestChoice('test_filter_with_xue_qu_fang' ))
    #suite.addTest(RestChoice('test_filter_with_zongjia_100_yi_xia' ))
    #suite.addTest(RestChoice('test_filter_with_zongjia_100_150' ))
    #suite.addTest(RestChoice('test_filter_with_zongjia_150_200' ))
    #suite.addTest(RestChoice('test_filter_with_zongjia_200_300' ))
    #suite.addTest(RestChoice('test_filter_with_zongjia_300_400' ))
    #suite.addTest(RestChoice('test_filter_with_zongjia_400_500' ))
    #suite.addTest(RestChoice('test_filter_with_zongjia_500_700' ))
    #suite.addTest(RestChoice('test_filter_with_zongjia_700_1000' ))
    #suite.addTest(RestChoice('test_filter_with_zongjia_1000_up' ))
    #suite.addTest(RestChoice('test_filter_with_1_shi' ))
    #suite.addTest(RestChoice('test_filter_with_2_shi' ))
    #suite.addTest(RestChoice('test_filter_with_3_shi' ))
    #suite.addTest(RestChoice('test_filter_with_4_shi' ))
    #suite.addTest(RestChoice('test_filter_with_5_shi' ))
    
    runner = lib.HTMLTestRunner(stream='TestReport.html',title="Test Result",description='Test Suite')
    runner.run(suite)
    if ((runner.failure_count !=0) or (runner.error_count!=0)):
        raise Exception('Test Suite execute finished,Test suite failed...')
