#coding=utf8
import unittest
import os
import sys
import logging
import time
import traceback
import platform
sys.path.append('../..')
import lib
from testCase.RestTestCaseBaseClass import RestTestCaseBaseClass

class RestModifyPassword(RestTestCaseBaseClass):
    '''接口测试修改密码'''
    def test_modify_password_with_old_password(self):
        '''测试根据老密码修改密码'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        self.buyerRestClient.modify_user_password('654321')
        self.buyerRestClient.modify_user_password('123456','654321')
        
    def test_modify_password_with_auth_code(self):
        '''测试根据验证码修改密码'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        self.buyerRestClient.get_auth_code()
        self.buyerRestClient.modify_user_password_by_auth_code('654321')
        time.sleep(60)
        self.buyerRestClient.get_auth_code()
        self.buyerRestClient.modify_user_password_by_auth_code('123456')
        time.sleep(60)
        
