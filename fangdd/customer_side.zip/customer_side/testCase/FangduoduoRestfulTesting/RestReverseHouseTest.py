#coding=utf8
import unittest
import os
import sys
import logging
import time
import lib
import traceback
import platform
sys.path.append('../..')
import lib
from testCase.RestTestCaseBaseClass import RestTestCaseBaseClass

class RestReverseHouseTest(RestTestCaseBaseClass):
    '''接口预约房源操作'''
    def test_reverse_house_source(self):
        '''测试接口发起预约3.5'''    
        logging.info('Step1:预约房源')
        self.InitRestClient(userId=self.buyerRestClient.userId,token=self.buyerRestClient.token,userName=self.buyerRestClient.userName)
        if os.environ.has_key('JENKINS_HOME'):
            if os.environ['TEST_ENV']=='test' :
                    body={"house_id" : 524727,
                  "appointment_people_name" : u"皇甫" ,
                  "appointment_people_gender" : 1 ,
                  "match_appointment_time_period" : 1}
            else:
                    body={"house_id" : 1395263,
                  "appointment_people_name" : u"皇甫" ,
                  "appointment_people_gender" : 1 ,
                  "match_appointment_time_period" : 1}
        else:
            if self.cf.test_env=='test' :
                body={"house_id" : 524727,
                      "appointment_people_name" : u"皇甫" ,
                      "appointment_people_gender" : 1 ,
                      "match_appointment_time_period" : 1}
            else:
                body={"house_id" : 1395263,
                      "appointment_people_name" : u"皇甫" ,
                      "appointment_people_gender" : 1 ,
                      "match_appointment_time_period" : 1}
                
        #RestReverseHouseTest.response=self.buyerRestClient.reverse_house_source()
        RestReverseHouseTest.response=self.buyerRestClient.post(self.buyerRestClient.url+'appointments/',verify=False,dictBody=body)
        
    def test_buyer_get_reserve_list(self):
        '''测试接口买家获取预约房源列表'''    
        logging.info('Step1:查询预约列表')
        self.buyerRestClient.buyer_get_reserve_list('processing')
        self.buyerRestClient.buyer_get_reserve_list('completed')
        
    def test_buyer_get_reserve_detail(self):
        '''测试接口买家获取预约详情'''        
        logging.info('Step1:接口测试卖家获取预约详情')
        self.buyerRestClient.buyer_get_reserve_deail(RestReverseHouseTest.response[1]['data']['appointment_id'])
    
    def test_push_reversvation(self):
        '''测试接口催约'''
        logging.info('Step1:接口测试买家催约')
        self.buyerRestClient.push_reversvation(RestReverseHouseTest.response[1]['data']['appointment_id'])
        
    def test_seller_get_reserve_list(self):
        '''测试接口卖家获取预约列表'''
        self.sellerRestClient.seller_get_reserve_list()
    
    def test_seller_get_reserve_detail(self):
        '''测试接口卖家获取预约详情'''
        self.sellerRestClient.seller_get_reserve_detail(RestReverseHouseTest.response[1]['data']['appointment_id'])
    
    def test_seller_agree_reservation(self):
        '''卖家同意预约'''
        self.sellerRestClient.seller_handle_reservation(RestReverseHouseTest.response[1]['data']['appointment_id'],1,1,"",0)
    
    def test_confirm_to_see(self):
        '''测试接口确认待看'''
        self.sellerRestClient.confirm_to_see(RestReverseHouseTest.response[1]['data']['appointment_id'])
    
    def test_same_type_house_source_reverse(self):
        '''测试接口批量预约同类型房源'''
        self.buyerRestClient.same_type_house_source_reverse(RestReverseHouseTest.response[1]['data']['appointment_id'],[524727,524512])
        
    def test_cancel2_reservation(self):
        '''测试接口买家取消预约''' 
        self.buyerRestClient.cancel2_reservation(RestReverseHouseTest.response[1]['data']['appointment_id'])
        
    def test_buyer_remove_reservation(self):
        '''测试接口买家删除预约'''
        self.buyerRestClient.buyer_remove_reservation(RestReverseHouseTest.response[1]['data']['appointment_id'])
        
    def test_seller_remove_reservation(self):
        '''测试接口卖家删除预约'''
        self.sellerRestClient.seller_remove_reservation(RestReverseHouseTest.response[1]['data']['appointment_id'])


if __name__=='__main__' :
    suite=unittest.TestSuite()
    suite.addTest(RestReverseHouseTest('test_reverse_house_source' ))
    suite.addTest(RestReverseHouseTest('test_confirm_to_see' ))
    suite.addTest(RestReverseHouseTest('test_buyer_remove_reservation'))
    suite.addTest(RestReverseHouseTest('test_seller_remove_reservation'))
    runner = lib.HTMLTestRunner(stream='TestReport.html',title="Test Result",description='Test Suite')
    runner.run(suite)
    if ((runner.failure_count !=0) or (runner.error_count!=0)):
        raise Exception('Test Suite execute finished,Test suite failed...') 