#coding=utf8
import unittest
import sys
sys.path.append('../..')
import lib
import binascii
import logging
from testCase.RestTestCaseBaseClass import RestTestCaseBaseClass

class RestGetRecommandHouseSource(RestTestCaseBaseClass):
    '''接口测试推荐房源 method:GET URL:houses/recommend'''    
    
    def test_get_recommand_house_source(self):
        '''接口测试推荐房源 @Author:皇甫'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        params = {
                  'city_id' : '121' ,
                  'page_index' : '0' ,
                  'page_size' : '10' ,
                  }
        response,content = self.buyerRestClient.get(self.buyerRestClient.url+'houses/recommend' , params=params, verify=False)
        self.assertEqual(content['code'],'00000' , 'Get auth code failed' )
        
if __name__ == '__main__':
    suite=unittest.TestSuite()
    suite.addTest(RestGetRecommandHouseSource('test_get_recommand_house_source'))
    runner = lib.HTMLTestRunner(stream='TestReport.html',title="Test Result",description='Test Suite')
    runner.run(suite)
    if ((runner.failure_count !=0) or (runner.error_count!=0)):
        raise Exception('Test Suite execute finished,Test suite failed...')