#coding=utf8
import unittest
import sys
sys.path.append('../..')
import lib
import binascii
import logging
from testCase.RestTestCaseBaseClass import RestTestCaseBaseClass

class RestGetVoiceAuthCode(RestTestCaseBaseClass):
    '''接口获取语音验证码测试 method:POST URL:users/voice_auth_code'''    
    
    def test_get_voice_auth_code(self):
        '''测试接口获取语音验证码 @Author:皇甫'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        response,content = self.buyerRestClient.post(self.buyerRestClient.url+'/users/voice_auth_code',dictBody={"mobile":self.buyerRestClient.mobile,"type":"login"},verify=False)
        self.assertEqual(content['code'],'00000' , 'Get auth code failed' )

if __name__ == '__main__':
    suite=unittest.TestSuite()
    suite.addTest(RestGetVoiceAuthCode('test_get_voice_auth_code'))
    
    runner = lib.HTMLTestRunner(stream='TestReport.html',title="Test Result",description='Test Suite')
    runner.run(suite)
    if ((runner.failure_count !=0) or (runner.error_count!=0)):
        raise Exception('Test Suite execute finished,Test suite failed...')
