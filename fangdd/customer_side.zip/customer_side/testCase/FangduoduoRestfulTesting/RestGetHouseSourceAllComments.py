#coding=utf8
import unittest
import sys
sys.path.append('../..')
import lib
import binascii
import logging
from testCase.RestTestCaseBaseClass import RestTestCaseBaseClass

class RestGetHouseSourceAllComments(RestTestCaseBaseClass):
    '''接口获取房源基础信息 method:GET URL:houses/xxxx/comments'''    
    
    def test_get_house_source_all_comments(self):
        '''测试接口获取获取房源详情页 @Author:皇甫'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        params = {
                  'page_index' : '0' ,
                  'page_size' : '10' ,
                  }
        response,content = self.buyerRestClient.get(self.buyerRestClient.url+'houses/523972/comments' , params=params, verify=False)
        self.assertEqual(content['code'],'00000' , 'Get auth code failed' )
        
if __name__ == '__main__':
    suite=unittest.TestSuite()
    suite.addTest(RestGetHouseSourceAllComments('test_get_house_source_all_comments'))
    runner = lib.HTMLTestRunner(stream='TestReport.html',title="Test Result",description='Test Suite')
    runner.run(suite)
    if ((runner.failure_count !=0) or (runner.error_count!=0)):
        raise Exception('Test Suite execute finished,Test suite failed...')