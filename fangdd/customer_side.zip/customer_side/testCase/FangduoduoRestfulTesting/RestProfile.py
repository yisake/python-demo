#encoding=utf-8
import sys
import unittest
import time
import logging
#加入customer_side项目路径到sys.path,可以导入lib和testcase
sys.path.append('../..')
import lib
from testCase.RestTestCaseBaseClass import RestTestCaseBaseClass

##################
#
# 2016.7.14
# Author:皇甫    
#    Program:profile页接口测试
#
##################
class RestProfile(RestTestCaseBaseClass):
    '''测试Profile页接口用例 GET users/user_id/profile'''
    
    def request_profile( self  , type , appointment_id ):
        #payload = { "type"  : type , 'appointment_id' : appointment_id }
        payload = { "type"  : type }
        return self.buyerRestClient.get(self.buyerRestClient.url+'users/'  + self.buyerRestClient.userId + '/profile'   ,verify=False ,params=payload)
    
    def request_event(self  ,page_size , page_index ):
        payload = { 'page_size' : page_size , 'page_index' : page_index}
        return self.buyerRestClient.get(self.buyerRestClient.url +'users/'  + self.buyerRestClient.userId + '/profile/event/list'  ,verify=False ,params=payload)
    
    def request_all_events(self):
        all_content = []
        i = 0
        while (1) :
            response,content = self.request_event('10', str(i))
            all_content = all_content + content['data']
            if content['data'].__len__()<10:
                break
            i = i+1
        print all_content.__len__()
        return all_content.__len__()
    
    def test_basic_profile(self):
        '''测试profile注册时间，用户姓名，天数 @Author:皇甫 '''
        self.connet_to_mysql()
        self.InitRestClient()
        self.buyerRestClient.login_in()
        self.sellerRestClient.login_in()
        def check_basic_info( content ):
            self.assertEqual(content['data']['base_info']['username'] , self.get_sql_info('select owner_name from fdd_second_house.t_second_owner where owner_phone='+self.buyerRestClient.mobile+';' )[0][0] ,'' )
            self.assertEqual(content['data']['base_info']['user_id'], self.get_sql_info('select owner_id from fdd_second_house.t_second_owner where owner_phone='+self.buyerRestClient.mobile+';' )[0][0] ,'' )
        
            #获取数据库时间，转化为python long类型
            create_time = self.get_sql_info('select create_time from fdd_second_house.t_second_owner where owner_phone='+self.buyerRestClient.mobile+';' )[0][0]
            create_time = long(time.mktime(create_time.timetuple()))
            #print create_time
            #print type(create_time)
            #print type(content['data']['base_info']['create_time'])
            #print content['data']['base_info']['create_time']
            self.assertEqual(content['data']['base_info']['create_time'], create_time*1000, 'msg')
        
        logging.info('Start to test type 2')
        response , content = self.request_profile( '2'  , ' '  )
        check_basic_info(content)
        
        logging.info('Start to test type 1')
        response , content = self.request_profile( '1'  , ' '  )
        check_basic_info(content)
     
    def test_order_times(self):
        '''测试profile看房和爽约次数 @Author:皇甫'''
        self.connet_to_mysql()
        self.InitRestClient()
        self.buyerRestClient.login_in()
        pass

    def test_order_history(self):
        '''测试profile预约历史 @Author:皇甫'''
        self.connet_to_mysql()
        self.InitRestClient()
        self.buyerRestClient.login_in()
        self.assertEqual(self.request_all_events(), self.get_sql_info('select count(*) from fdd_esf_customer_center.cc_user_timeline where user_id='+self.buyerRestClient.userId+';' )[0][0] , '' )
     
    def test_order_detail(self):
        ''' 测试profile预约历史详情 @Author:皇甫'''
        self.connet_to_mysql()
        self.InitRestClient()
        self.buyerRestClient.login_in()
        response,content = self.request_event('10', '0' ) 
        for i in content['data' ] :
            self.assertTrue(i.has_key('event_detail' ),'' )
            if i['event_detail'].has_key('appointment' ):
                self.assertTrue(i['event_detail']['appointment'].has_key('appointment_id'  ),'' )
                self.assertTrue(i['event_detail']['appointment'].has_key('house' ),'' )
                self.assertTrue(i['event_detail']['appointment'].has_key('house_id' ),'' )
                self.assertTrue(i['event_detail']['appointment'].has_key('owner_id' ),'' )
                self.assertTrue(i['event_detail']['appointment'].has_key('owner_mobile'  ),'' )
                self.assertTrue(i['event_detail']['appointment'].has_key('status'  ),'' )
            elif i['event_detail'].has_key('topic'):
                self.assertTrue(i['event_detail']['topic'].has_key('create_time'  ),'' )
                self.assertTrue(i['event_detail']['topic'].has_key('group' ),'' )
                self.assertTrue(i['event_detail']['topic'].has_key('topic_id' ),'' )
            else:
                raise AssertionError('No appointment or topic json data...' )
            
    def test_order_detail_info(self ):
        ''' 测试profile预约历史数据库对比 @Author:皇甫'''   
        self.connet_to_mysql()
        self.InitRestClient()
        self.buyerRestClient.login_in()
        response,content = self.request_event('10', '0' ) 
        for i in content['data' ] :
            self.assertTrue(i.has_key('event_detail' ),'' )
            #if i['event_detail'].has_key('appointment' ):
                
                    
if __name__ == '__main__':
    suite=unittest.TestSuite()
    suite.addTest(RestProfile('test_basic_profile'))
    suite.addTest(RestProfile('test_order_history'))
    suite.addTest(RestProfile('test_order_detail' ))
    runner = lib.HTMLTestRunner(stream='TestReport.html',title="Test Result",description='Test Suite')
    runner.run(suite)
    if ((runner.failure_count !=0) or (runner.error_count!=0)):
        raise Exception('Test Suite execute finished,Test suite failed...')