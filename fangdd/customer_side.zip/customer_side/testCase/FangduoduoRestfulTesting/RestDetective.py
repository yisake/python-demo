#coding=utf8
import sys
import unittest
import time
import logging
import itertools
sys.path.append('../..')
import lib
from testCase.RestTestCaseBaseClass import RestTestCaseBaseClass

##################
#
# 2016.7.19
# Author:皇甫    
#    Program:profile页接口测试
#
##################
class RestDetective(RestTestCaseBaseClass):
    '''找房神探接口用例 method:GET URL:detective/houses?'''
    
    #{ 'dahua' : 1080,
    # 'gumei' : 5246,
    # '':''
    #}
    
    def get_sql_info( self , SQL):
        cur=self.conn.cursor()
        cur.execute(SQL)
        result=cur.fetchall()
        cur.close()
        return result
    
    def get_section_alias_dict_from_city(self,city_id):
        alias_dict={ }
        result = self.get_sql_info("select concat(alias_name,' ',section_id) from fdd_second_basic.t_second_section where city_id="+city_id+';')
        for item in result:
            alias_dict[item[0].split(' ' )[0]]=item[0].split(' ' )[1]
        print alias_dict
        return alias_dict
    
    def request_detective(self ,payload ):
        return self.buyerRestClient.get(self.buyerRestClient.url+'detective/houses'   ,verify=False ,params=payload)
    
    def test_detective_price(self):
        '''测试找房神探价格筛选 @Author:皇甫'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        price_list = [210,250,300]
        for price in price_list:
            logging.info('Start to test detective price test:' )
            payload = {'is_second':'true' ,
                       'page_index':'0' ,
                       'page_size':'10',
                       'max_price': str(price),
                       'city_id' :'121',
                       }
            response,content = self.request_detective(payload)
            logging.info('Start to test price'+str(price))
            self.assertNotEqual(content['data'].__len__(), 0, '' ) 
            for house in content['data']:
                self.assertTrue(price*0.9<=house['house_price']<=price*1.1, '' )
        
    def test_detective_layout(self):
        '''测试找房神探户型筛选 @Author:皇甫'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        #layout_list = [ 1,2,3,4,5,]
        layout_list = [ 1,2,3,4,]
        for layout in layout_list:
            logging.info('Start to test detective layout test:' +str(layout))
            payload = {'is_second':'true' ,
                       'page_index':'0' ,
                       'page_size':'10',
                       'max_price': '0',
                       'city_id' :'121',
                       'rooms': str(layout),
                       }
            response,content = self.request_detective(payload)
            self.assertNotEqual(content['data'].__len__(), 0, '' )
            for house in content['data']:
                #print house['fangyuan_name']
                #print type(house['fangyuan_name'])
                self.assertTrue( int(house['fangyuan_name'][0])==layout, '' )
    
    def test_detective_multiple_layout(self):
        '''测试找房神探多个户型筛选 @Author:皇甫''' 
        self.InitRestClient()
        self.buyerRestClient.login_in()
        layout_list = [ 1,2,3,4,5,]
        for i in itertools.product( layout_list , repeat = 3):
            payload = {'is_second':'true' ,
                       'page_index':'0' ,
                       'page_size':'10',
                       'max_price': '0',
                       'city_id' :'121',
                       'rooms': str(i[0])+','+str(i[1])+','+str(i[2]),
                       }
            response,content = self.request_detective(payload)
            self.assertNotEqual(content['data'].__len__(), 0, '' )
            for house in content['data']:
                #print house['fangyuan_name']
                #print type(house['fangyuan_name'])
                logging.info('Set the condition to')
                logging.info(str(i[0])+','+str(i[1])+','+str(i[2]))
                logging.info('Start to test house...')
                logging.info(house['fangyuan_name'])
                self.assertTrue( int(house['fangyuan_name'][0])==i[0] or 
                                        int(house['fangyuan_name'][0])==i[1] or
                                        int(house['fangyuan_name'][0])==i[2], '' )
            
    def test_detective_location(self):
        '''测试找房神探位置筛选 @Author:皇甫'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        self.connet_to_mysql()
        result = self.get_section_alias_dict_from_city('121')
        section_list = [u'大华' ,u'古美' , u'碧云' ,u'九亭' ,u'鞍山' ,u'长风' ,u'丰庄'  ,u'大宁'  ]
        for section in section_list:
                payload = {'is_second':'true' ,
                           'page_index':'0' ,
                           'page_size':'10',
                           'max_price': '0',
                           'city_id' :'121',
                           'block_ids' : str(result[section]),
                           }
                response,content = self.request_detective(payload)
                self.assertNotEqual(content['data'].__len__(), 0, '' )
                for item in content['data']:
                    logging.info(item)
                    self.assertEqual(str(item['location']['block_id']),str(result[section]),'' )
        
    def test_detective_multiple_location(self):
        '''测试找房神探位置筛选 @Author:皇甫'''
        pass
    
    def test_detective_price_and_layout(self):
        '''测试找房神探价格和户型筛选 @Author:皇甫'''
        price_list = [210 , 250 , 300 , 500 ,600]
        layout_list = [ 1,2,3,4,5,]
        for price in price_list:
            for layout in layout_list:
                logging.info('Start to test detective price test:' )
                payload = {'is_second':'true' ,
                           'page_index':'0' ,
                           'page_size':'10',
                           'max_price': price,
                           'city_id' :'121',
                           'rooms': str(layout),
                           }
                response,content = self.request_detective(payload)
                self.assertNotEqual(content['data'].__len__(), 0, '' )
                for house in content['data']:
                    #print house['fangyuan_name']
                    #print type(house['fangyuan_name'])
                    self.assertTrue( int(house['fangyuan_name'][0])==layout, '' )
                    self.assertTrue(price*0.9<=house['house_price']<=price*1.1, '' )
    
    def test_detective_price_and_location(self):
        '''测试找房神探价格和区域筛选'''
        
        pass 
        
if __name__ == '__main__':
    suite=unittest.TestSuite()
    suite.addTest(RestDetective('test_detective_price'))
    suite.addTest(RestDetective('test_detective_layout'))
    suite.addTest(RestDetective('test_detective_multiple_layout'))
    
    suite.addTest(RestDetective('test_detective_location'))
    #suite.addTest(RestDetective('test_detective_multiple_location')) #undo
    
    suite.addTest(RestDetective('test_detective_price_and_layout'))
    
    runner = lib.HTMLTestRunner(stream='TestReport.html',title="Test Result",description='Test Suite')
    runner.run(suite)
    if ((runner.failure_count !=0) or (runner.error_count!=0)):
        raise Exception('Test Suite execute finished,Test suite failed...')
