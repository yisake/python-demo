#coding=utf8
import unittest
import sys
sys.path.append('../..')
import lib
import binascii
import logging
from testCase.RestTestCaseBaseClass import RestTestCaseBaseClass

class RestGetSearchHints(RestTestCaseBaseClass):
    '''接口获取搜索提示 method:GET URL:search/hints/6.5'''    
    
    def test_get_search_hints(self):
        '''测试接口获取搜索提示 @Author:皇甫'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        params = {
                  'type' : '2' ,
                  'key_word' : '大宁'  ,
                  }
        response,content = self.buyerRestClient.get(self.buyerRestClient.url+'search/hints/6.5' , params=params ,headers={'City-Id' :'121' } ,verify=False)
        self.assertEqual(content['code'],'00000' , 'Get auth code failed' )
        
if __name__ == '__main__':
    suite=unittest.TestSuite()
    suite.addTest(RestGetSearchHints('test_get_search_hints'))
    runner = lib.HTMLTestRunner(stream='TestReport.html',title="Test Result",description='Test Suite')
    runner.run(suite)
    if ((runner.failure_count !=0) or (runner.error_count!=0)):
        raise Exception('Test Suite execute finished,Test suite failed...')