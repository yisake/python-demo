#coding=utf8
import unittest
import os
import sys
import logging
import time
sys.path.append('../..')
import lib
from testCase.RestTestCaseBaseClass import RestTestCaseBaseClass

class RestLoginTest(RestTestCaseBaseClass):
    '''接口登录测试'''
    def test_rest_login_and_log_out(self):
        '''测试接口登录登出'''    
        logging.info('Step1:接口登录')
        self.InitRestClient()
        (response,jsonDict)=self.buyerRestClient.login_in()
        self.assertEqual(response.status_code,200,'返回码错误')
        self.assertEqual(jsonDict['msg'],'success','返回码错误')        
        logging.info('Step2:接口登出')
        (response,jsonDict)=self.buyerRestClient.log_out()
        self.assertEqual(response.status_code,200,'返回码错误')
        self.assertEqual(jsonDict['msg'],'success','返回码错误')
        
class RestTestCase(RestTestCaseBaseClass):
    @classmethod
    def LoadConfig(cls):
        '''Integrate to jenkins,if exists the environment varible,set the config file with the value'''
        if os.environ.has_key('JENKINS_HOME'):
            cls.conf_name='rest.cfg'
            cls.cf = lib.Config(cls.conf_name)
            logging.info('Version: '+ os.environ['JOB_NAME'])     
        else:            
            cls.conf_name='rest.cfg'
            cls.cf = lib.Config(cls.conf_name)    
    
    @classmethod
    def InitRestClient(cls):
        cls.buyerRestClient=lib.restClient(cls.cf.server_ip,cls.cf.server_port,cls.cf.buyer_mobile,cls.cf.buyer_password)
        cls.sellerRestClient=lib.restClient(cls.cf.server_ip,cls.cf.server_port,cls.cf.buyer_mobile,cls.cf.buyer_password)
                   
    @classmethod
    def setUpClass(cls):
        logging.info('setUpClass-----接口登录')
        '''初始化配置文件'''
        cls.LoadConfig()
        '''初始化RestClient'''
        cls.InitRestClient()
        if cls.buyerRestClient.login_in()[1]['msg']!='success':
            logging.info('接口登录失败')
            raise Exception('LoginException:','login in failed in setUpClass')
        print cls.userId
        print cls.token
        
    @classmethod
    def tearDownClass(cls):
        logging.info('tearDownClass-------接口退出')
        if cls.buyerRestClient.log_out()[1]['msg']!='success':
            logging.info('接口登录失败')
            raise Exception('LogoutException:','log out in failed in tearDownClass')
        
    def test_get_auth_code(self):
        '''测试接口获取验证码'''
        logging.info('Step2:接口获取验证码')
        (response,jsonDict)=self.buyerRestClient.get_auth_code()
        self.assertEqual(response.status_code,200,'返回码错误')
        self.assertEqual(jsonDict['msg'],'success','返回码错误')
        
    def test_get_voice_auth_code(self):
        '''测试接口获取语音验证码'''      
        logging.info('Step2:接口获取语音验证码')
        time.sleep(60)
        (response,jsonDict)=self.buyerRestClient.get_voice_auth_code()
        self.assertEqual(response.status_code,200,'返回码错误')
        self.assertEqual(jsonDict['msg'],'success','返回码错误')
        
    def test_get_user_profile(self):
        '''测试接口获取用户信息'''      
        logging.info('Step2:接口获取用户信息')
        (response,jsonDict)=self.buyerRestClient.get_user_profile()
        self.assertEqual(response.status_code,200,'返回码错误')
        self.assertEqual(jsonDict['msg'],'success','返回码错误')        
    
    def test_check_current_mobile(self):
        '''测试接口获取当前手机'''
        (response,jsonDict)=self.buyerRestClient.check_current_mobile()
        self.assertEqual(response.status_code,200,'返回码错误')
        self.assertEqual(jsonDict['msg'],'success','返回码错误')
        
    def test_get_supported_city_list(self):
        '''测试支持城市列表'''  
        (response,jsonDict)=self.buyerRestClient.get_supported_city_list()
        self.assertEqual(response.status_code,200,'返回码错误')
        self.assertEqual(jsonDict['msg'],'success','返回码错误')        
    
    def test_get_message_list(self):
        '''测试获取消息列表'''
        (response,jsonDict)=self.buyerRestClient.get_message_list('1','2')
        self.assertEqual(response.status_code,200,'返回码错误')
        self.assertEqual(jsonDict['msg'],'success','返回码错误')          
        
    def test_get_message(self):
        '''测试获取消息'''
        (response,jsonDict)=self.buyerRestClient.get_message('1')
        self.assertEqual(response.status_code,200,'返回码错误')
        #self.assertEqual(jsonDict['msg'],'success','返回码错误')          
        
    def test_get_unread_message_number(self):
        '''测试未读获取消息数量'''
        (response,jsonDict)=self.buyerRestClient.get_unread_message_number()
        self.assertEqual(response.status_code,200,'返回码错误')
        self.assertEqual(jsonDict['msg'],'success','返回码错误')          
    
    def test_push_reverse(self):
        '''测试催约'''
        (response,jsonDict)=self.buyerRestClient.push_reverse()
        self.assertEqual(response.status_code,200,'返回码错误')
        self.assertEqual(jsonDict['msg'],'success','返回码错误')   