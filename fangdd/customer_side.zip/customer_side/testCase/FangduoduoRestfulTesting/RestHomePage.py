#coding=utf8
import unittest
import sys
sys.path.append('../..')
import lib
import binascii
import logging
from testCase.RestTestCaseBaseClass import RestTestCaseBaseClass

class RestHomePage(RestTestCaseBaseClass):
    '''接口测试6.0主页 method:GET URL:meta/home_page'''    
    
    def test_home_page(self):
        '''接口测试6.0主页 @Author:皇甫'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        response,content = self.buyerRestClient.get(self.buyerRestClient.url+'meta/home_page?city_id=121' , verify=False)
        self.assertEqual(content['code'],'00000' , 'Get auth code failed' )
        
if __name__ == '__main__':
    suite=unittest.TestSuite()
    suite.addTest(RestHomePage('test_home_page'))
    runner = lib.HTMLTestRunner(stream='TestReport.html',title="Test Result",description='Test Suite')
    runner.run(suite)
    if ((runner.failure_count !=0) or (runner.error_count!=0)):
        raise Exception('Test Suite execute finished,Test suite failed...')