#coding=utf8
import unittest
import sys
sys.path.append('../..')
import lib
import binascii
import logging
from testCase.RestTestCaseBaseClass import RestTestCaseBaseClass

class RestGetSellerHouseSourceDetailInformation(RestTestCaseBaseClass):
    '''测试接口获取业主房源详细信息 method:GET URL:owner/house/xxxx'''    
    
    def test_get_seller_house_source_detail_information(self):
        '''测试接口获取业主房源详细信息 @Author:皇甫'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        response,content = self.buyerRestClient.get(self.buyerRestClient.url+'owner/house/523972' , verify=False)
        self.assertEqual(content['code'],'00000' , 'Get auth code failed' )
        
if __name__ == '__main__':
    suite=unittest.TestSuite()
    suite.addTest(RestGetSellerHouseSourceDetailInformation('test_get_seller_house_source_detail_information'))
    runner = lib.HTMLTestRunner(stream='TestReport.html',title="Test Result",description='Test Suite')
    runner.run(suite)
    if ((runner.failure_count !=0) or (runner.error_count!=0)):
        raise Exception('Test Suite execute finished,Test suite failed...')