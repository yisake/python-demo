#coding=utf8
import unittest
import sys
sys.path.append('../..')
import lib
import binascii
import logging
from testCase.RestTestCaseBaseClass import RestTestCaseBaseClass

class RestGetMessage(RestTestCaseBaseClass):
    '''接口获取消息 method:GET URL:users/messages/0'''    
    
    def test_get_message(self):
        '''测试接口获取消息 @Author:皇甫'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        response,content = self.buyerRestClient.get(self.buyerRestClient.url+'users/messages/0',verify=False)
        self.assertEqual(content['code'],'00000' , 'Get auth code failed' )
        
if __name__ == '__main__':
    suite=unittest.TestSuite()
    suite.addTest(RestGetMessage('test_get_message'))
    runner = lib.HTMLTestRunner(stream='TestReport.html',title="Test Result",description='Test Suite')
    runner.run(suite)
    if ((runner.failure_count !=0) or (runner.error_count!=0)):
        raise Exception('Test Suite execute finished,Test suite failed...')