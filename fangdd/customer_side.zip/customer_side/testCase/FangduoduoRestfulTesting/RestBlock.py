#coding=utf8
import unittest
import sys
sys.path.append('../..')
import lib
import binascii
import logging
from testCase.RestTestCaseBaseClass import RestTestCaseBaseClass

class RestBlock(RestTestCaseBaseClass):
    '''板块接口测试用例 method: URL:'''    
    
    def test_block_content(self):
        '''测试板块地图基本信息 @Author:皇甫'''
        '''测试上海所有板块接口是否包含预约总数，平均价格，id，名字，在售套数参数'''
        self.InitRestClient()
        self.buyerRestClient.login_in( )
        self.connet_to_mysql()
        sections=self.get_sql_info('select section_id from fdd_second_basic.t_second_section where city_id=121;' )
        for block in sections:
            logging.info('Checking block id:'+str(block[0]))
            response,content = self.buyerRestClient.get(self.buyerRestClient.url+'block/'+str(block[0]),verify=False)
            for i in ["appoint_count","average_price","id","latitude","name","on_sale_count"]:
                logging.info('Checking key:'+i)
                self.assertTrue(content['data'].has_key(i))
    
    def test_block_detail(self):
        '''测试板块地图小区信息 @Author:皇甫'''
        '''测试板块信息，与数据库进行对比'''
        self.InitRestClient()
        self.buyerRestClient.login_in( )
        self.connet_to_mysql()
        sections=self.get_sql_info('select section_id from fdd_second_basic.t_second_section where city_id=121;' )
        for block in sections:
            logging.info('Checking block id:'+str(block[0]))
            response,content = self.buyerRestClient.get(self.buyerRestClient.url+'block/'+str(block[0])+'/detail' ,verify=False)
            average_price=self.get_sql_info('select thirty_days_price from fdd_esf_statistic.t_house_section_price_info where section_id=' + str(block[0]))
            self.assertEqual( average_price , content['data']['average_price'],'' )
            
if __name__ == '__main__':
    suite=unittest.TestSuite()
    #suite.addTest(RestBlock('test_block_content'))
    suite.addTest(RestBlock('test_block_detail'))
    #suite.addTest(RestBlock('test_choiceHouse3'))
    runner = lib.HTMLTestRunner(stream='TestReport.html',title="Test Result",description='Test Suite')
    runner.run(suite)
    if ((runner.failure_count !=0) or (runner.error_count!=0)):
        raise Exception('Test Suite execute finished,Test suite failed...')
