#encoding=utf-8
import os
filePath=__file__

'''
@author: 皇甫
@program: 自动导入当前文件夹下的所有*.py结尾的文件
@date: 2016.9.27
'''
#print filePath[:filePath.rfind('__init__.py')]
for pyFile in os.listdir(filePath[:filePath.rfind('__init__.py')]):
    exec('from '+pyFile[:pyFile.rfind('.')]+' import *' )
