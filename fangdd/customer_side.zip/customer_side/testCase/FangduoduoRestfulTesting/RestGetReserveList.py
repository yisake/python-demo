#coding=utf8
import unittest
import sys
sys.path.append('../..')
import lib
import binascii
import logging
from testCase.RestTestCaseBaseClass import RestTestCaseBaseClass

class RestGetReserveList(RestTestCaseBaseClass):
    '''接口获取预约列表 method:GET URL:calendar/list'''    
    
    def test_get_reserve_list(self):
        '''测试接口获取获取预约列表 @Author:皇甫'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        params = {
                  'customerID' : '748985' ,
                  'status' : 'completed' ,
                  'page_size' : '2' ,
                  'page_index': '0',
                  }
        response,content = self.buyerRestClient.get(self.buyerRestClient.url+'calendar/list' , params=params, verify=False)
        self.assertEqual(content['code'],'00000' , 'Get auth code failed' )
        
if __name__ == '__main__':
    suite=unittest.TestSuite()
    suite.addTest(RestGetReserveList('test_get_reserve_list'))
    runner = lib.HTMLTestRunner(stream='TestReport.html',title="Test Result",description='Test Suite')
    runner.run(suite)
    if ((runner.failure_count !=0) or (runner.error_count!=0)):
        raise Exception('Test Suite execute finished,Test suite failed...')