#coding=utf8
import unittest
import sys
sys.path.append('../..')
import lib
import binascii
import logging
from testCase.RestTestCaseBaseClass import RestTestCaseBaseClass

class RestReportUser(RestTestCaseBaseClass):
    '''接口获取房源基础信息 method:POST URL:meta/report_user'''    
    
    def test_report_user(self):
        '''测试接口获取获取房源详情页 @Author:皇甫'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        response,content = self.buyerRestClient.post(self.buyerRestClient.url+'meta/report_user' , dictBody={"user-id": 748985,"reportee_id":748985,"report_type":1} , verify=False)
        self.assertEqual(content['code'],'00000' , 'Get auth code failed' )
        
if __name__ == '__main__':
    suite=unittest.TestSuite()
    suite.addTest(RestReportUser('test_report_user'))
    runner = lib.HTMLTestRunner(stream='TestReport.html',title="Test Result",description='Test Suite')
    runner.run(suite)
    if ((runner.failure_count !=0) or (runner.error_count!=0)):
        raise Exception('Test Suite execute finished,Test suite failed...')