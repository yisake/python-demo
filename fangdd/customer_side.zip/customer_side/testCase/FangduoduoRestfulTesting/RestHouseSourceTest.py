#coding=utf8
import unittest
import sys
import logging
sys.path.append('../..')
import lib
from testCase.RestTestCaseBaseClass import RestTestCaseBaseClass

class RestHouseSourceTest(RestTestCaseBaseClass):
    '''接口房源操作'''
    def test_house_source(self):
        '''测试接口发布修改删除房源'''    
        logging.info('Step1:发布房源')
        self.InitRestClient(userId=self.buyerRestClient.userId,token=self.buyerRestClient.token,userName=self.buyerRestClient.userName)
        (response,jsonDict)=self.buyerRestClient.publish_house_source()
        logging.info('Step2:上下架房源')
        self.buyerRestClient.on_line_house_source(str(jsonDict['data']['house_id']))
        self.buyerRestClient.off_line_house_source(str(jsonDict['data']['house_id']))
        logging.info('Step3:修改房源价格')
        self.buyerRestClient.modify_house_price(str(jsonDict['data']['house_id']),"300")
        logging.info('Step4:编辑房源信息')
        self.buyerRestClient.get_ownver_house()
        logging.info('Step5:删除房源')
        self.buyerRestClient.delete_house_source(str(jsonDict['data']['house_id']))
        
    def test_publish_house_source(self):
        '''测试接口发布房源'''    
        logging.info('Step1:发布房源')
        #self.InitRestClient(userId=self.buyerRestClient.userId,token=self.buyerRestClient.token,userName=self.buyerRestClient.userName)
        RestHouseSourceTest.response=self.buyerRestClient.publish_house_source()
    
    def test_online_house_source(self):
        '''测试接口上架房源'''    
        logging.info('Step2:上架房源')
        self.buyerRestClient.on_line_house_source(str(RestHouseSourceTest.response[1]['data']['house_id']))

    def test_offline_house_source(self):
        '''测试接口下架房源'''
        logging.info('Step1:下架房源')
        self.buyerRestClient.off_line_house_source(str(RestHouseSourceTest.response[1]['data']['house_id']))
    
    def test_modify_house_price(self):
        '''测试接口修改房源价格'''    
        logging.info('Step3:修改房源价格')
        self.buyerRestClient.modify_house_price(str(RestHouseSourceTest.response[1]['data']['house_id']),"300")
    
    def test_edit_house_info(self):
        '''测试接口编辑房源信息''' 
        logging.info('Step4:编辑房源信息')
        payload = {
                   "shi" : 1,
                   "year_type" :2,
                   "is_only" :True,
                   "expect_price" :"222",
                   "is_south" : False,
                   "building_no" :"2",
                   "edit_type" : 1,
                   "all_floor" : 3,
                   "room_no" :"3",
                   "wei" : 0,
                   "house_direction" :u'南',
                   "ting" : 1,
                   "has_loan" :True,
                   "area" :"114",
                   "on_floor" : 2,
                   }
        self.buyerRestClient.edit_house_source(RestHouseSourceTest.response[1]['data']['house_id'],1,kargs=payload)
    
    def test_delete_house_source(self):
        '''测试接口删除房源''' 
        logging.info('Step5:删除房源')
        self.buyerRestClient.delete_house_source(str(RestHouseSourceTest.response[1]['data']['house_id']))

if __name__ == '__main__':
    suite=unittest.TestSuite()
    suite.addTest(RestHouseSourceTest('test_publish_house_source'))
    suite.addTest(RestHouseSourceTest('test_edit_house_info'))
    suite.addTest(RestHouseSourceTest('test_delete_house_source'))
    runner = lib.HTMLTestRunner(stream='TestReport.html',title="Test Result",description='Test Suite')
    runner.run(suite)
    if ((runner.failure_count !=0) or (runner.error_count!=0)):
        raise Exception('Test Suite execute finished,Test suite failed...')
