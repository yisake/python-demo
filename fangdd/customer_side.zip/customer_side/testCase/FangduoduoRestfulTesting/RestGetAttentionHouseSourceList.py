#coding=utf8
import unittest
import sys
sys.path.append('../..')
import lib
import binascii
import logging
from testCase.RestTestCaseBaseClass import RestTestCaseBaseClass

class RestGetAttentionHouseSourceList(RestTestCaseBaseClass):
    '''接口获取房源关注列表 method:GET URL:users/collects'''    
    
    def test_get_attention_house_source_list(self):
        '''测试接口关注房源 @Author:皇甫'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        response,content = self.buyerRestClient.get(self.buyerRestClient.url+'users/collects' ,verify=False)
        self.assertEqual(content['code'],'00000' , 'Get auth code failed' )
        
if __name__ == '__main__':
    suite=unittest.TestSuite()
    suite.addTest(RestGetAttentionHouseSourceList('test_get_attention_house_source_list'))
    runner = lib.HTMLTestRunner(stream='TestReport.html',title="Test Result",description='Test Suite')
    runner.run(suite)
    if ((runner.failure_count !=0) or (runner.error_count!=0)):
        raise Exception('Test Suite execute finished,Test suite failed...')