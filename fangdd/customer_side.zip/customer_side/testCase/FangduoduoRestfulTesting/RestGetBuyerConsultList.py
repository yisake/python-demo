#coding=utf8
import unittest
import sys
sys.path.append('../..')
import lib
import binascii
import logging
from testCase.RestTestCaseBaseClass import RestTestCaseBaseClass

class RestGetBuyerConsultList(RestTestCaseBaseClass):
    '''接口测试买家咨询列表 method:GET URL:appointments/buyer_chat_list'''    
    
    def test_get_buyer_consult_list(self):
        '''接口测试买家咨询列表 @Author:皇甫'''
        self.InitRestClient()
        self.buyerRestClient.login_in()
        response,content = self.buyerRestClient.get(self.buyerRestClient.url+'appointments/buyer_chat_list?page_size=10&page_index=0' , verify=False)
        self.assertEqual(content['code'],'00000' , 'Get auth code failed' )
        
if __name__ == '__main__':
    suite=unittest.TestSuite()
    suite.addTest(RestGetBuyerConsultList('test_get_buyer_consult_list'))
    runner = lib.HTMLTestRunner(stream='TestReport.html',title="Test Result",description='Test Suite')
    runner.run(suite)
    if ((runner.failure_count !=0) or (runner.error_count!=0)):
        raise Exception('Test Suite execute finished,Test suite failed...')