#coding=utf-8
from gevent import monkey; monkey.patch_all
import gevent
import time

def f():

    while 1:
        current = time.time()
        current_time = time.strftime('%Y-%m-%d %H:%M:%S')    
        with open('D:/log.txt', 'a') as f:
            f.write('[debug] %s %f search ms:16 params:{"query":"None"}\n' % (current_time, current))


gevent.joinall([gevent.spawn(f) for j in range(10000)])