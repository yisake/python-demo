#encoding=utf-8
from locust import HttpLocust, TaskSet, task , events
import grequests
import time

class WebsiteTasks(TaskSet):
        
    @task
    def test_1(self):
        start_time = time.time()
        try:
            request = grequests.get('http://10.12.21.145:8000/')
            request.send()
        except Exception,e:
            total_time = int((time.time() - start_time) * 1000)
            events.request_failure.fire(request_type="GET", name="10.12.21.145", response_time=total_time, exception=e)
        else:
            total_time = request.response.elapsed.microseconds
            events.request_success.fire(request_type="GET", name="10.12.21.145", response_time=total_time, response_length=0)

        
class WebsiteUser(HttpLocust):
    
    host = ''
    task_set = WebsiteTasks
    min_wait = 0
    max_wait = 0