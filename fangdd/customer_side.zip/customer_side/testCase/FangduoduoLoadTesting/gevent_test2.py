#coding=utf-8
import requests
import gevent.monkey
gevent.monkey.patch_all()
gevent.monkey.patch_socket()
import urllib2

def foo():
    s=requests.Session()
    while 1:
        s.get('http://10.12.21.145:8000/')
        #urllib2.urlopen('http://10.12.21.145:8000/')
        #conn.request('GET','/')
        #conn.close()

gevent.joinall([gevent.spawn(foo) for i in range(10)])