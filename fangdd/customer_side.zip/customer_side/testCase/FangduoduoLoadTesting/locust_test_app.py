#encoding=utf-8
from locust import HttpLocust, TaskSet, task , events
import sys
import unittest
import time
sys.path.append('../..')
from lib import restClient


restClient=restClient('a.esf.fangdd.net','60006','18300000001','123456',deviceType='iOS', appVersion='6.9.0',logFlag=False)
restClient.login_in()


class WebsiteTasks(TaskSet,unittest.TestCase):
    
    def on_start(self):
        self.buyerRestClient=restClient
    
    @task
    def test_1(self):
        start_time = time.time()
        try:
            response,content = self.buyerRestClient.get(self.buyerRestClient.url+'search?city_id=121&from=0&house_price=350-850&lat=31.284094&lng=121.446309',verify=False)
            for house in content['data']['records']:
                self.assertTrue(350<=house['house_price']<=850, '')
        except Exception,e:
            total_time = int((time.time() - start_time) * 1000)
            events.request_failure.fire(request_type="测试筛选房源价格等于100万", name='GET : '+self.buyerRestClient.url, response_time=total_time, exception=e)
        else:
            total_time = response.elapsed.microseconds
            events.request_success.fire(request_type="测试筛选房源价格等于100万", name='GET : '+self.buyerRestClient.url, response_time=total_time, response_length=0)
            
    @task
    def test_2(self):
        start_time = time.time()
        try:
            response,content = self.buyerRestClient.get(self.buyerRestClient.url+'search?city_id=121&from=0&house_price=350-850&lat=31.284094&lng=121.446309',verify=False)
            for house in content['data']['records']:
                self.assertTrue(house['house_price']==850, '')
        except Exception,e:
            total_time = int((time.time() - start_time) * 1000)
            events.request_failure.fire(request_type="测试筛选房源价格等于200万", name="GET : https://a.esf.fangdd.net:60006/search", response_time=total_time, exception=e)
        else:
            total_time = response.elapsed.microseconds
            events.request_success.fire(request_type="测试筛选房源价格等于200万", name="GET : https://a.esf.fangdd.net:60006/search", response_time=total_time, response_length=0)
    
    @task
    def test_3(self):
        start_time = time.time()
        try:
            response,content = self.buyerRestClient.get(self.buyerRestClient.url+'block/1058/detail',verify=False)
            self.assertTrue(content['code']=='00000',u'返回码错误')
        except Exception,e:
            total_time = int((time.time() - start_time) * 1000)
            events.request_failure.fire(request_type="测试大宁板块详情接口", name="GET : https://a.esf.fangdd.net:60006/block/1058/detail", response_time=total_time, exception=e)
        else:
            total_time = response.elapsed.microseconds
            events.request_success.fire(request_type="测试大宁板块详情接口", name="GET : https://a.esf.fangdd.net:60006/block/1058/detail", response_time=total_time, response_length=0)

    
        
class WebsiteUser(HttpLocust):
    
    host = ''
    task_set = WebsiteTasks
    min_wait = 0
    max_wait = 0