#coding=utf-8
import requests
import gevent
#import gevent.monkey
import grequests
#gevent.monkey.patch_all()
#s=requests.session()
s2=grequests.Session()

def foo(): 
    re=s2.get('http://10.12.21.145:8000/')
    #requests.get('http://10.12.21.145:8000/')

gevent.joinall([gevent.spawn(foo) for i in range(1000)])
#while True:
#    gevent.joinall([gevent.spawn(foo) for i in range(1000)])

    
#tasks = [gevent.spawn(foo) for i in range(0,1000)]
#while 1:
#    gevent.joinall(tasks)