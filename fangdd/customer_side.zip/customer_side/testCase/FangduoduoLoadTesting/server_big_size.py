#coding=utf-8
from gevent.pywsgi import WSGIServer
import logging
logger=logging.getLogger('error')
file_handler = logging.FileHandler("D:/server_error.log") 


def application(environ, start_response):
    
    if environ['PATH_INFO'] =='/':
    
        status = '200 OK'

        headers = [
            ('Content-Type', 'text/html')
        ]

        start_response(status, headers)
        
        yield "<p>Hello"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        yield "World</p>"
        
    else:
        start_response('404 Not Found', [('Content-Type', 'text/html')])
        yield [b'<h1>Not Found</h1>']
        #headers = [
        #   ('Content-Type', 'text/html')
        #]

        #start_response(status, headers)
        #yield "<p>Test"
        #yield "Hf!!</p>"

WSGIServer(('', 8000), application,log=None).serve_forever()