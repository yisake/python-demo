#encoding=utf-8
from locust import HttpLocust, TaskSet, task , events
import urllib
import random

class WebsiteTasks(TaskSet):
    district=['广中苑','大宁花园',]
    
    def on_start(self):
       print '#'*10+'on start:'       
       
    
    @task
    def index(self):
        #http://10.12.21.119:65127/map/search/%E5%B9%BF%E4%B8%AD%E8%8B%91?city_id=121
        
        district=['广中苑','大宁花园','']        
        name=urllib.quote(district[random.randint(0, 1)])
        self.client.get("http://10.12.21.119:65127/map/search/"+name+'?city_id=121')

        
class WebsiteUser(HttpLocust):
    
    host=''
    task_set = WebsiteTasks
    min_wait = 0
    max_wait = 0