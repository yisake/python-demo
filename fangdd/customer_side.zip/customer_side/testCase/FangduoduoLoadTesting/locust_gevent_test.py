#encoding=utf-8
from locust import HttpLocust, TaskSet, task , events
import requests
print 'init'+'#'*10

class WebsiteTasks(TaskSet):
    
    def on_start(self):
       print '#'*10+'on start:'
       #self.client.post("/login", {
       #     "username": "test_user",
       #     "password": ""
       # })
    
    @task
    def index(self):
        self.client.get("index")
        
class WebsiteUser(HttpLocust):
    
    host = 'http://10.12.21.145:8000/'
    task_set = WebsiteTasks
    min_wait = 0
    max_wait = 0