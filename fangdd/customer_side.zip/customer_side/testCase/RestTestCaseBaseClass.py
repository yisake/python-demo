#coding=utf8
import unittest
import os
import sys
import logging
import time
import traceback
import warnings
sys.path.append('..')
import lib
from . import AndroidTestCaseBaseClass

class RestTestCaseBaseClass(AndroidTestCaseBaseClass.AndroidTestCaseBaseClass): 
    rest_flag = True;
    city_list = {u'上海' : '121' ,u'苏州' :'3' , u'杭州': '2316' , u'南京' :'267'  ,u'广州' : '852' ,u'深圳': '1337' } 
    
    @classmethod
    def ClassLoadConfig(cls):
        '''Integrate to jenkins,if exists the environment varible,set the config file with the value'''
        if os.environ.has_key('JENKINS_HOME'):
            cls.conf_name='rest.cfg'
            cls.cf = lib.Config(cls.conf_name)
            logging.info('Version: '+ os.environ['JOB_NAME'])
        else:
            cls.conf_name='rest.cfg'
            cls.cf = lib.Config(cls.conf_name)
    
    @classmethod
    def ClassInitRestClient(cls):
        if os.environ.has_key('JENKINS_HOME'):
            if os.environ['TEST_ENV'] =='test' :              
                cls.server_ip = 'a.esf.fangdd.net'
                cls.server_port = '60006'
            elif os.environ['TEST_ENV'] =='prePublish':
                cls.server_ip = 'a.esf.fangdd.com.cn'
                cls.server_port = '443' 
            #买家、卖家用户名密码                
            cls.buyer_mobile = os.environ['BUYER_MOBILE' ]
            cls.buyer_password = os.environ['BUYER_PASSWORD' ]
            cls.seller_mobile = os.environ['SELLER_MOBILE' ]
            cls.seller_password = os.environ['SELLER_PASSWORD' ]
            #买家、卖家设备类型和app版本            
            cls.buyer_device_type = os.environ['BUYER_DEVICE_TYPE']
            cls.buyer_app_version = os.environ['BUYER_APP_VERSION']
            cls.seller_device_type = os.environ['SELLER_DEVICE_TYPE']
            cls.seller_app_version= os.environ['SELLER_APP_VERSION']
        else:
            if cls.cf.test_env =='test':
                cls.server_ip = 'a.esf.fangdd.net'
                cls.server_port = '60006'
            elif cls.cf.test_env=='prePublish':
                cls.server_ip = 'a.esf.fangdd.com.cn'
                cls.server_port = '443' 
            
            #买家、卖家用户名密码
            cls.buyer_mobile = cls.cf.buyer_mobile
            cls.buyer_password = cls.cf.buyer_password
            cls.seller_mobile = cls.cf.seller_mobile
            cls.seller_password = cls.cf.seller_password
            
            #买家、卖家设备类型和app版本
            cls.buyer_device_type = cls.cf.buyer_device_type
            cls.buyer_app_version = cls.cf.buyer_app_version
            cls.seller_device_type = cls.cf.seller_device_type
            cls.seller_app_version = cls.cf.seller_app_version
        
        #初始化买家、卖家账号
        cls.buyerRestClient=lib.restClient(cls.server_ip,cls.server_port,cls.buyer_mobile,cls.buyer_password,appVersion=cls.buyer_app_version, deviceType=cls.buyer_device_type)
        cls.sellerRestClient=lib.restClient(cls.server_ip,cls.server_port,cls.seller_mobile,cls.seller_password,appVersion=cls.seller_app_version,deviceType=cls.seller_device_type)
    
    @classmethod
    def ClassLogin(cls):
        if cls.buyerRestClient.login_in()[1]['msg']!='success':
            logging.info('接口登录失败')
            raise Exception('LoginException:','login in failed in setUpClass')       
        if cls.sellerRestClient.login_in()[1]['msg']!='success':
            logging.info('接口登录失败')
            raise Exception('LoginException:','login in failed in setUpClass')
    
    @classmethod
    def ClassLogout(cls):
        if cls.buyerRestClient.log_out()[1]['msg']!='success':
            logging.info('接口登录失败')
            raise Exception('LogoutException:','log out in failed in setUpClass')
        if cls.sellerRestClient.log_out()[1]['msg']!='success':
            logging.info('接口登录失败')
            raise Exception('LogoutException:','log out in failed in setUpClass')         
        
    @classmethod
    def setUpClass(cls):
        logging.info('setUpClass-----接口登录')
        '''初始化配置文件'''
        cls.ClassLoadConfig()
        '''初始化RestClient'''
        cls.ClassInitRestClient()
        ''''''
        cls.ClassLogin()
                
    @classmethod
    def tearDownClass(cls):
        logging.info('tearDownClass-------接口退出')  
        cls.ClassLogout()

    def setUp(self):
        #time.sleep(5)
        self.InitialTest('rest.cfg')
        #self.buyerRestClient=lib.restClient(self.cf.server_ip,self.cf.server_port,self.cf.buyer_mobile,self.cf.buyer_password,self.log_path+'/user.log',userId=self.buyerRestClient.userId,token=self.buyerRestClient.token,userName=self.buyerRestClient.userName,appVersion=self.cf.buyer_app_version,deviceVersion=self.cf.buyer_device_version)
        #self.sellerRestClient=lib.restClient(self.cf.server_ip,self.cf.server_port,self.cf.seller_mobile,self.cf.seller_password,userId=self.sellerRestClient.userId,token=self.sellerRestClient.token,userName=self.sellerRestClient.userName,appVersion=self.cf.seller_app_version,deviceVersion=self.cf.seller_device_version)    
    
    def tearDown(self):
        AndroidTestCaseBaseClass.AndroidTestCaseBaseClass.tearDown(self)
    
    def run(self, result=None):
        orig_result = result
        if result is None:
            result = self.defaultTestResult()
            startTestRun = getattr(result, 'startTestRun', None)
            if startTestRun is not None:
                startTestRun()

        self._resultForDoCleanups = result
        result.startTest(self)

        testMethod = getattr(self, self._testMethodName)
        if (getattr(self.__class__, "__unittest_skip__", False) or
            getattr(testMethod, "__unittest_skip__", False)):
            # If the class or method was skipped.
            try:
                skip_why = (getattr(self.__class__, '__unittest_skip_why__', '')
                            or getattr(testMethod, '__unittest_skip_why__', ''))
                self._addSkip(result, skip_why)
            finally:
                result.stopTest(self)
            return
        try:
            success = False
            try:
                self.setUp()
            except unittest.case.SkipTest as e:
                self._addSkip(result, str(e))
            except KeyboardInterrupt:
                raise
            except:
                result.addError(self, sys.exc_info())
            else:
                try:
                    #重写unittest.TestCase run方法，失败重跑两次,i取值范围0~repeat_time-1
                    for i in range(0,self.repeat_time):
                        #用来存储当前运行的i次数
                        self.repeat_index=i
                        try:
                            logging.info('########start to test for '+str(i)+' times')                            
                            if i!=0:
                                logging.info('****Class setUpClass method init****')
                                setUpClass = getattr(self.__class__, 'setUpClass', None)
                                if setUpClass is not None:
                                    setUpClass()
                            testMethod()
                            break
                        except Exception,e:
                            self.close_mysql()                      
                            if i==self.repeat_time-1:                                
                                logging.info(traceback.format_exc())
                                raise e
                            else:                                
                                logging.info(traceback.format_exc())
                            continue
                except KeyboardInterrupt:
                    raise
                except self.failureException:
                    result.addFailure(self, sys.exc_info())
                except unittest.case._ExpectedFailure as e:
                    addExpectedFailure = getattr(result, 'addExpectedFailure', None)
                    if addExpectedFailure is not None:
                        addExpectedFailure(self, e.exc_info)
                    else:
                        warnings.warn("TestResult has no addExpectedFailure method, reporting as passes",
                                      RuntimeWarning)
                        result.addSuccess(self)
                except unittest.case._UnexpectedSuccess:
                    addUnexpectedSuccess = getattr(result, 'addUnexpectedSuccess', None)
                    if addUnexpectedSuccess is not None:
                        addUnexpectedSuccess(self)
                    else:
                        warnings.warn("TestResult has no addUnexpectedSuccess method, reporting as failures",
                                      RuntimeWarning)
                        result.addFailure(self, sys.exc_info())
                except unittest.case.SkipTest as e:
                    self._addSkip(result, str(e))
                except:
                    result.addError(self, sys.exc_info())
                else:
                    success = True

                try:
                    self.tearDown()
                except KeyboardInterrupt:
                    raise
                except:
                    result.addError(self, sys.exc_info())
                    success = False

            cleanUpSuccess = self.doCleanups()
            success = success and cleanUpSuccess
            if success:
                result.addSuccess(self)
        finally:
            result.stopTest(self)
            if orig_result is None:
                stopTestRun = getattr(result, 'stopTestRun', None)
                if stopTestRun is not None:
                    stopTestRun()    
    
    def InitRestClient(self,userId='',token='',userName=''):
        #判断是否根据jenkins传入环境变量
        if os.environ.has_key('JENKINS_HOME'):
            if os.environ['TEST_ENV'] =='test' :              
                self.server_ip = 'a.esf.fangdd.net'
                self.server_port = '60006'
            elif os.environ['TEST_ENV'] =='prePublish':
                self.server_ip = 'a.esf.fangdd.com.cn'
                self.server_port = '443' 
            
            #买家、卖家手机号/密码
            self.buyer_mobile = os.environ['BUYER_MOBILE' ]
            self.buyer_password = os.environ['BUYER_PASSWORD' ]
            self.seller_mobile = os.environ['SELLER_MOBILE' ]
            self.seller_password = os.environ['SELLER_PASSWORD' ]
            #买家、卖家设备类型和app版本            
            self.buyer_device_type = os.environ['BUYER_DEVICE_TYPE']
            self.buyer_app_version = os.environ['BUYER_APP_VERSION']
            self.seller_device_type = os.environ['SELLER_DEVICE_TYPE']
            self.seller_app_version= os.environ['SELLER_APP_VERSION']
            
        else:
            if self.cf.test_env =='test':
                self.server_ip = 'a.esf.fangdd.net'
                self.server_port = '60006'
            elif self.cf.test_env=='prePublish':
                self.server_ip = 'a.esf.fangdd.com.cn'
                self.server_port = '443' 
                
            #买家、卖家手机号/密码
            self.buyer_mobile = self.cf.buyer_mobile
            self.buyer_password = self.cf.buyer_password
            self.seller_mobile = self.cf.seller_mobile
            self.seller_password = self.cf.seller_password
            #买家、卖家设备类型和app版本
            self.buyer_device_type = self.cf.buyer_device_type
            self.buyer_app_version = self.cf.buyer_app_version
            self.seller_device_type = self.cf.seller_device_type
            self.seller_app_version = self.cf.seller_app_version
        
        #初始化restclient客户端                
        self.buyerRestClient=lib.restClient(self.server_ip,
                                            self.server_port,
                                            self.buyer_mobile,
                                            self.buyer_password,
                                            appVersion=self.buyer_app_version, 
                                            deviceType=self.buyer_device_type,
                                            interfaceLog=self.log_path+'/user.log',
                                            userId=userId,
                                            token=token,
                                            userName=userName)
        self.sellerRestClient=lib.restClient(self.server_ip,
                                            self.server_port,
                                            self.seller_mobile,
                                            self.seller_password,
                                            appVersion=self.buyer_app_version, 
                                            deviceType=self.buyer_device_type,
                                            interfaceLog=self.log_path+'/user.log',
                                            userId=userId,
                                            token=token,
                                            userName=userName)
                
    def SetTestResultFlag(self):
        logging.info('Setting test result flag...')
        if os.path.exists(self.logs_path+self.test_name+'_interface.txt'):
            self.resultFlag=True
            logging.info('Setting test result flag to true')
        else:
            self.resultFlag=False       
            logging.info('Setting test result flag to false')
            
    def CheckTestResultFlag(self):
        logging.info('Checking test result flag...')
        
        #commit by春峰:2016.7.13,暂时不对比文件
        #if self.resultFlag:
        #    import filecmp
        #    if filecmp.cmp(self.logs_path+self.test_name+'_interface.txt',self.log_path+'/user.log')==False:
        #        raise AssertionError('Compare file failed...')
        #else:
        #    if os.path.exists(self.log_path+'/user.log'):
        #        shutil.copyfile(self.log_path+'/user.log',self.logs_path+self.test_name+'_interface.txt')
        #    else:
        #        pass
