'''
Created on Nov 28, 2015
Huangfu chunfeng
'''
import os
import traceback
import ctypes
import win32con
import win32api
import common
import sys
reload(sys)
sys.setdefaultencoding('gb18030')
from jpype import *
scriptPath=os.path.abspath(os.path.join(os.path.dirname(os.path.realpath(__file__)))).replace('\\','/').replace('/lib','')
sikuliapiPath=scriptPath+'/utils/sikuliLibs/sikuli-script.jar'
os.environ['CLASSPATH']+=sikuliapiPath
os.environ['PATH']+='C:/Program Files (x86)/Java/jre6/bin;'
os.environ['PATH']+=scriptPath+'/utils/sikuliLibs;'
print 'Get default JVM path:'+getDefaultJVMPath()
startJVM(getDefaultJVMPath(),'-ea','-Djava.class.path='+sikuliapiPath)

class SikuliAPI:  
    ##add sikuli/lib,C:\Program Files (x86)\Java\jre6\bin; to the Path,
    def __init__(self):
        Screen=JClass('org.sikuli.script.Screen')
        self.screen = Screen()  
        self.AppDict={}
        self.adbStr=common.exec_local('adb devices')
        
    def sikuli_open(self,appName,binPath,imgFile,win32Type=False):
        if win32Type:
            win32api.ShellExecute(0,'open',binPath,'','',1)
            hWnd=self.get_window_handle(imgFile)
            bin=''
            self.AppDict[appName]=bin,hWnd
        else:
            App=JClass('org.sikuli.script.App')
            bin=App(binPath)
            bin.open()
            hWnd=self.get_window_handle(imgFile)
            self.AppDict[appName]=bin,hWnd
    
    def get_window_handle(self,imgFile):
        self.sikuli_wait(imgFile)
        return ctypes.windll.user32.GetForegroundWindow()        
        
    def max_window(self,appName):
        ctypes.windll.user32.ShowWindow(self.AppDict[appName][1],win32con.SW_MAXIMIZE)
        
    def min_window(self,appName):    
        ctypes.windll.user32.ShowWindow(self.AppDict[appName][1],win32con.SW_MINIMIZE)
        
    def sikuli_close(self,appName,win32Type=False):
        if win32Type:
            win32api.PostMessage(self.AppDict[appName][1],win32con.WM_CLOSE,0,0)
        else:    
            self.AppDict[appName][0].close()
    
    def sikuli_focus(self,appName):
        App=JClass('org.sikuli.script.App')
        App.focus(self.AppDict[appName][0])
    
    def sikuli_active(self,appName):
        ctypes.windll.user32.SwitchToThisWindow(self.AppDict[appName][1],False)
    
    def sikuli_type(self,string):
        self.screen.type(string)
    
    def sikuli_wait(self,imgFile, timeOut=10000, similarity=0.9):
        try:  
            Pattern=JClass('org.sikuli.script.Pattern')
            self.PT = Pattern(imgFile)  
            self.PT = self.PT.similar(float(similarity))  
            self.screen.wait(self.PT, float(timeOut))
            return self.PT
        except Exception, err:
            print traceback.format_exc()
            raise Exception("Cannot click [" + imgFile + "]")

    def sikuli_click(self, imgFile, timeOut=10000, similarity=0.9):
        try:  
            self.screen.click(self.sikuli_wait(imgFile, timeOut, similarity))  
        except Exception, err:  
            print traceback.format_exc()
            raise Exception("Cannot click [" + imgFile + "]")          
        
    def sikuli_double_click(self, imgFile, timeOut=10000, similarity=0.9):
        try:             
            self.screen.doubleClick(self.sikuli_wait(imgFile, timeOut, similarity))  
        except Exception, err:  
            print traceback.format_exc()
            raise Exception("Cannot click [" + imgFile + "]")            

