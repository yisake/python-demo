#coding=utf-8
import json

class SeatMap(object):

    ROBOT_LIBRARY_SCOPE = 'GLOBAL'
    ROBOT_LIBRARY_VERSION = '0.1'

    def __init__(self):
        pass

    def create_seatMap(self, name, password):

        dict1 = {"name": name,
                 "password": password}
        self.name=name
        self.password=password
        dict2 = {"type": "login"}
        dict1.update(dict2)
        return self
    
    def get_name(self):
        return self.name
