combinations()
创建一个迭代器，返回iterable中所有长度为r的子序列，返回的子序列中的项按输入iterable中的顺序排序
note:不带重复
from itertools import *
for i in combinations([1, 2, 3], 2):
    print i
(1, 2)
(1, 3)
(2, 3)

combinations_with_replacement()
note:带重复
from itertools import *
for i in combinations_with_replacement([1, 2, 3], 2):
    print i
(1, 1)
(1, 2)
(1, 3)
(2, 2)
(2, 3)
(3, 3)

product遍历n个元素的方法
import itertools
for i in itertools.product([1,2,3], repeat = 3):
    print i

(1, 1, 1)
(1, 1, 2)
(1, 1, 3)
(1, 2, 1)
(1, 2, 2)
(1, 2, 3)
(1, 3, 1)
(1, 3, 2)
(1, 3, 3)
(2, 1, 1)
(2, 1, 2)
(2, 1, 3)
(2, 2, 1)
(2, 2, 2)
(2, 2, 3)
(2, 3, 1)
(2, 3, 2)
(2, 3, 3)
(3, 1, 1)
(3, 1, 2)
(3, 1, 3)
(3, 2, 1)
(3, 2, 2)
(3, 2, 3)
(3, 3, 1)
(3, 3, 2)
(3, 3, 3)

product(iter1, iter2, ... iterN, [repeat=1])
创建一个迭代器，生成表示item1，item2等中的项目的笛卡尔积的元组，repeat是一个关键字参数，指定重复生成序列的次数
for i in itertools.product([1, 2, 3], [4, 5], [6, 7]):
    print i
输出:
(1, 4, 6)
(1, 4, 7)
(1, 5, 6)
(1, 5, 7)
(2, 4, 6)
(2, 4, 7)
(2, 5, 6)
(2, 5, 7)
(3, 4, 6)
(3, 4, 7)
(3, 5, 6)
(3, 5, 7)

