##server.py
import SimpleXMLRPCServer
 
class MyObject:
    def sayHello(self):
        return "hello xmlprc"
 
obj = MyObject()
server = SimpleXMLRPCServer.SimpleXMLRPCServer(("localhost", 8001))
server.register_instance(obj)
 
print "Listening on port 80"
server.serve_forever()
 
client.py
import xmlrpclib
server = xmlrpclib.ServerProxy("http://localhost:8001")
words = server.sayHello()
