import airtest
import time
app=airtest.Device('windows://C:\\Windows\\System32\\cmd.exe')
app.globalSet(threshold=0.9)
#app.click('C:/Users/Administrator/Desktop/5.jpg')
tiaozhan='C:/Users/Administrator/Desktop/3.jpg'
zhunbei='C:/Users/Administrator/Desktop/4.jpg'
jieshu='C:/Users/Administrator/Desktop/6.jpg'
#app.click(tiaozhan)
while True:
    if app.exists(tiaozhan):
        app.click(tiaozhan)
        while True:
            if app.exists(zhunbei):
                app.click(zhunbei)
                break
            time.sleep(3)
    if app.exists(jieshu):
        app.click(jieshu)
    time.sleep(3)
