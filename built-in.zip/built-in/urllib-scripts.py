import urllib
import urllib2
req = urllib2.Request('http://www.voidspace.org.uk')
response = urllib2.urlopen(req)
the_page = response.read()

build_opener([handler1 [ handler2, ... ]])
参数handler是Handler实例，常用的有HTTPBasicAuthHandler、HTTPCookieProcessor、ProxyHandler等。
build_opener ()返回的对象具有open()方法，与urlopen()函数的功能相同。

# 1. GET方法
# !/usr/bin/env python
# -*- coding:utf-8 -*-
# File: http_get.p
def http_get():
    url='http://192.168.1.13:9999/test'   #页面的地址
    response = urllib2.urlopen(url)         #调用urllib2向服务器发送get请求
    return response.read()                     #获取服务器返回的页面信息
   
ret = http_get()
print("RET %r" % (ret))

# 2. POST方法
# !/usr/bin/env python
#  -*- coding:utf-8 -*-
# File http_post.py
def http_post():
    url = 'http://192.168.1.13:9999/test'
    values = {'user': 'Smith', 'passwd': '123456}
    jdata = json.dumps(values)             # 对数据进行JSON格式化编码
    req = urllib2.Request(url, jdata)       # 生成页面请求的完整数据
    response = urllib2.urlopen(req)       # 发送页面请求
    return response.read()                    # 获取服务器返回的页面信息


resp = http_post()
print resp

# 3. PUT方法
# !/usr/bin/env python
# -*- coding:utf-8 -*-
# File: http_put.py 
def http_put():
    url='http://192.168.1.13:9999/test'
    values={'':''}
 
    jdata = json.dumps(values)                  # 对数据进行JSON格式化编码
    request = urllib2.Request(url, jdata)
    request.add_header('Content-Type', 'your/conntenttype')
    request.get_method = lambda:'PUT'           # 设置HTTP的访问方式
    request = urllib2.urlopen(request)
    return request.read()
 
resp = http_put()
print resp

# 4. DELETE方法
# !/usr/bin/env python
# -*- coding:utf-8 -*-
# File: http_delete.py
def http_delete():
    url='http://192.168.1.13:9999/test'
    values={'user':'Smith'}
    jdata = json.dumps(values)
    request = urllib2.Request(url, jdata)
    request.add_header('Content-Type', 'your/conntenttype')
    request.get_method = lambda:'DELETE'        # 设置HTTP的访问方式
    request = urllib2.urlopen(request)
    return request.read()

resp = http_delete()
print resp


# url编码
print urllib.quote("http://192.168.10.105:8080/media/activities/上海/ad/1515043837.jpg")
print urllib.unquote('http://192.168.10.105:8080/media/activities/%E4%B8%8A%E6%B5%B7/ad/1515043837.jpg')
