##################################
# 知识点整理，內建函数
# Program:
# Author:
# Date:
##################################
# 基本数据类型Number,String,List,Dictionary,Tuple,Set
# int,float,bool,
#
# 相对导入
# from . import
# from .. import
#
# 函数默认参数
# param1 = 'value1'
#
# 函数可变参数
# * 在一个tuple中存储
# ** 在一个dict中存储

##################################
# python lambda
# Program:
# Author:
# Date:
##################################
# 普通函数
# 定义函数（普通方式）
def func(arg):
    return arg + 1
# 执行函数
result = func(123)
# lambda
# 定义函数（lambda表达式）
my_lambda = lambda arg: arg + 1
# 执行函数
result = my_lambda(123)


##################################
# string字符串方法
# Program:
# Author:
# Date:
##################################
# 声明
string = 'hello_world'
string.count('substring')
string.find('substring')# find返回S中出现substr的第一个字母的标号如果S中没有substr则返回-1
string.rfind('core')# 返回S中最后出现的substr的第一个字母的标号，如果S中没有substr则返回-1
''.join(['1', '2', '3'])# join 用字符串将list拼接起来
string.replace('word', 'python')# replace 把S中的oldstar替换为newstr，count为替换次数。
string.lstrip()# str.strip()删除首尾字符
string.rstrip()# str.rstrip()删除首尾字符

##################################
# dict字典方法
# Program:
# Author:
# Date:
##################################
dic1 = {"a": "apple", "b": "banana", "g": "grape", "o": "orange"}# dict添加
dic1["w"] = "watermelon"# dict新增或设置某个key值
dic1.update()# dict更新（组合字典）
# dict遍历
d = {"name": "nico", "age": 23}
for key in d:
    print "key=%s, value=%s" % (key, d[key])
for key in d.iterkeys():
    print "key=%s, value=%s" % (key, d[key])
for key in d.keys():
    print "key=%s, value=%s" % (key, d[key])
for key in iter(d):
    print "key=%s, value=%s" % (key, d[key])
for key, item in d.items():
    print "key=%s, value=%s" % (key, item)
# 转换json字符串为dict
user = "{'name' : 'jim', 'sex' : 'male', 'age': 18}"
b = eval(user)

##################################
# typle元祖方法
# Program:
# Author:
# Date:
##################################
a=(1,2,3,4)
a.index(value, )

##################################
# list列表方法
# Program:
# Author:
# Date:
##################################
list1 = [1, 2, 3, 1, 1, 1, 5]
list2 = ['xyz', 'abc']
list1[0] = 3  # 设置list值
list1.append(1)  # 追加元素
list1.count(1)  # 返回元素出现次数
list1.extend(list2)  # 增加list
list1.index(2)  # 从列表中找出某个值第一个匹配项的索引位置
list1.insert(0, 'insert')  # 将对象插入列表
list1.remove(2)  # 删除该元素
list1.pop([-1])  # 删除元素，默认最后一个,并且返回该元素的值
list1.reverse()  # 反向列表中元素
list1.sort([func])  # 对原列表进行排序
list1.__len__
list1.__str__
list1.__doc__
# 1、cmp(list1, list2)：比较两个列表的元素
# 2、len(list)：列表元素个数
# 3、max(list)：返回列表元素最大值
# 4、min(list)：返回列表元素最小值
# 5、list(seq)：将元组转换为列表

##################################
# set集合方法
# Program:
# Author:
# Date:
##################################
a = {1, 2, 3, 4}
a.add(3)
a.copy()
a.pop() #依次取出第一个元素，队列
a.remove()#删除某个元素
a.union()
set([1,2,3,4])#转化list为set

# 字符串格式化
# %s     字符串
# %c     字符
# %d     十进制（整数）
# %i     整数
# %u    无符号整数
# %o     八进制整数
# %x    十六进制整数
# %X     十六进制整数大写
# %e     浮点数格式1
# %E     浮点数格式2
# %f     浮点数格式3
# %g    浮点数格式4
# %G    浮点数格式5
# %%     文字%
# 一、使用%
print "My name is %s, i'm %d years old" % ('hf', 24)
# 二、使用format {}
# 1.正常使用
print "My name is {}, i'm {} years old".format('hf', 24)
# 2.还可以通过在括号里填写数字，修改格式化的顺序
print "我叫{1}，今年{0}岁了".format("小李", 20)
# 3.通过key取变量
print "我叫{name}，今年{age}岁了".format(name="小李", age=20)
# 4.传入对象
class Person:
    def __init__(self, name, age):
            self.name, self.age = name, age

    def __str__(self):
            return '我叫{self.name}, 今年{self.age}岁了'.format(self=self)


print str(Person('小李', 20))
# '我叫小李, 今年20岁了'
# 5、通过下标
person = ['小李', 20]
'我叫{0[0]}, 今年{0[1]}岁了'.format(person)
'我叫小李, 今年20岁了'
# 6、填充与对齐
# 格式限定符，语法是{}中带:号
# 填充常跟对齐一起使用
# ^、<、>分别是居中、左对齐、右对齐，后面带宽度
# :号后面带填充的字符，只能是一个字符，不指定的话默认是用空格填充
print '{:>8}'.format('189')
print '{:>8}'.format('189')
print '{:0>8}'.format('189')
print '{:a>8}'.format('189')
# 7、精度与类型f
print '{:.2f}'.format(321.33345)
# 8、其他类型
# 主要就是进制了，b、d、o、x分别是二进制、十进制、八进制、十六进制。
print '{:b}'.format(17)
print '{:d}'.format(17)
print '{:o}'.format(17)
print '{:x}'.format(17)