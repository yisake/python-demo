import smtplib
from email.mime.text import MIMEText
from email.header import Header
sender = 'huangfucf@yintong.com.cn'
receivers = ['huangfucf@yintong.com.cn']  # 接收邮件，可设置为你的QQ邮箱或者其他邮箱
# 三个参数：第一个为文本内容，第二个 plain 设置文本格式，第三个 utf-8 设置编码
message = MIMEText(u'Python 邮件发送测试...', 'plain', 'utf-8')
message['From'] = Header(u"菜鸟教程", 'utf-8')
message['To'] =  Header(u"测试", 'utf-8')
subject = u'Python SMTP 邮件测试'
message['Subject'] = Header(subject, 'utf-8')

try:
server = smtplib.SMTP('192.168.211.13',port=25)
server.login('huangfucf', 'Fghjkl147@')
server.sendmail(sender, receivers, message.as_string())
    print "邮件发送成功"
except smtplib.SMTPException:
    print "Error: 无法发送邮件"  
    
    
    
    
import smtplib  
from email.mime.text import MIMEText  
mailto_list=[YYY@YYY.com] 
mail_host="smtp.qq.com"  #设置服务器
mail_user="840850160"    #用户名
mail_pass="XXXXXX"   #口令 
mail_postfix="XXX.com"  #发件箱的后缀

def send_mail(to_list,sub,content):  
    me="hello"+"<"+mail_user+"@"+mail_postfix+">"  
    msg = MIMEText(content,_subtype='plain',_charset='gb2312')  
    msg['Subject'] = sub  
    msg['From'] = me  
    msg['To'] = ";".join(to_list)  
    try:  
        server = smtplib.SMTP()  
        server.connect(mail_host)  
        server.login(mail_user,mail_pass)  
        server.sendmail(me, to_list, msg.as_string())  
        server.close()  
        return True  
    except Exception, e:  
        print str(e)  
        return False  
if __name__ == '__main__':  
    if send_mail(mailto_list,"hello","hello world！"):  
        print "发送成功"  
    else:  
        print "发送失败" 
