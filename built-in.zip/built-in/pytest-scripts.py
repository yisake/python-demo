# 1. Pytest Marker 机制
# 对于Pytest的测试用例，可以在每一个测试用例加一个marker，比如pytest运行的时就只运行带有该marker的测试用例，比如下面的@pytest.mark.webtest。
# 在我们的实际项目中，我们通常把为每个feature建立相应的marker，用于测试时进行不同条件的挑选。
# Pytest还支持一个测试用例有多个marker，这个在后续会把相应的实践加入进来。
# 测试结果如下，只挑选了测试用例带有webtest marker的运行。

# 作者：Yating_Yang
# 链接：https://www.jianshu.com/p/60ef272911a5
# 來源：简书
# 简书著作权归作者所有，任何形式的转载都请联系作者获得授权并注明出处。

#Below are test_pytest_markers.py 
# content of test_server.py

import pytest

@pytest.mark.webtest

def test_send_http():
    pass # perform some webtest test for your app

def test_something_quick():
    pass

def test_another():
    pass

class TestClass:

    def test_method(self):
        pass

# C:\Users\yatyang\PycharmProjects\pytest_example>pytest -v -m "webtest" test_pytest_markers.py
# ============================= test session starts =============================
# platform win32 -- Python 2.7.13, pytest-3.0.6, py-1.4.32, pluggy-0.4.0 -- C:\Python27\python.exe
# cachedir: .cache
# rootdir: C:\Users\yatyang\PycharmProjects\pytest_example, inifile:
# collected 4 items 

# test_pytest_markers.py::test_send_http PASSED

# ============================= 3 tests deselected ==============================
# =================== 1 passed, 3 deselected in 0.04 seconds ====================

# 作者：Yating_Yang
# 链接：https://www.jianshu.com/p/60ef272911a5
# 來源：简书
# 简书著作权归作者所有，任何形式的转载都请联系作者获得授权并注明出处。




# C:\Users\yatyang\PycharmProjects\pytest_example>pytest -v -m "not webtest" test_pytest_markers.py
# ============================= test session starts =============================
# platform win32 -- Python 2.7.13, pytest-3.0.6, py-1.4.32, pluggy-0.4.0 -- C:\Python27\python.exe
# cachedir: .cache
# rootdir: C:\Users\yatyang\PycharmProjects\pytest_example, inifile:
# collected 4 items 

# test_pytest_markers.py::test_something_quick PASSED
# test_pytest_markers.py::test_another PASSED
# test_pytest_markers.py::TestClass::test_method PASSED

# ============================= 1 tests deselected ==============================

# 作者：Yating_Yang
# 链接：https://www.jianshu.com/p/60ef272911a5
# 來源：简书
# 简书著作权归作者所有，任何形式的转载都请联系作者获得授权并注明出处。




# 2. 选择运行特定的某个测试用例
# 你可以按照某个测试用例的的模块，类或函数来选择你要运行的case，比如下面的方式就适合一开始在调试单个测试用例的时候。

# C:\Users\yatyang\PycharmProjects\pytest_example>pytest -v test_pytest_markers.py::TestClass::test_method
# ============================= test session starts =============================
# platform win32 -- Python 2.7.13, pytest-3.0.6, py-1.4.32, pluggy-0.4.0 -- C:\Python27\python.exe
# cachedir: .cache
# rootdir: C:\Users\yatyang\PycharmProjects\pytest_example, inifile:
# collected 5 items 

# test_pytest_markers.py::TestClass::test_method PASSED

# ========================== 1 passed in 0.03 seconds ===========================

# 作者：Yating_Yang
# 链接：https://www.jianshu.com/p/60ef272911a5
# 來源：简书
# 简书著作权归作者所有，任何形式的转载都请联系作者获得授权并注明出处。



# 3. 选择运行特定的某个类
# 比如你想单独运行下某个类的所有测试用例，可以按照如下操作。


# C:\Users\yatyang\PycharmProjects\pytest_example>pytest -v test_pytest_markers.py::TestClass
# ============================= test session starts =============================
# platform win32 -- Python 2.7.13, pytest-3.0.6, py-1.4.32, pluggy-0.4.0 -- C:\Python27\python.exe
# cachedir: .cache
# rootdir: C:\Users\yatyang\PycharmProjects\pytest_example, inifile:
# collected 4 items 

# test_pytest_markers.py::TestClass::test_method PASSED

# ========================== 1 passed in 0.04 seconds ===========================

# 作者：Yating_Yang
# 链接：https://www.jianshu.com/p/60ef272911a5
# 來源：简书
# 简书著作权归作者所有，任何形式的转载都请联系作者获得授权并注明出处。


# 4 多种组合
# 比如下面，你可以进行以上两种方式的组合挑选你需要运行的测试用例。C:\Users\yatyang\PycharmProjects\pytest_example>pytest -v test_pytest_markers.py::TestClass test_pytest_markers.py::test_send_http
# ============================= test session starts =============================
# platform win32 -- Python 2.7.13, pytest-3.0.6, py-1.4.32, pluggy-0.4.0 -- C:\Python27\python.exe
# cachedir: .cache
# rootdir: C:\Users\yatyang\PycharmProjects\pytest_example, inifile:
# collected 8 items 

# test_pytest_markers.py::TestClass::test_method PASSED
# test_pytest_markers.py::test_send_http PASSED

# ========================== 2 passed in 0.06 seconds ===========================

# 作者：Yating_Yang
# 链接：https://www.jianshu.com/p/60ef272911a5
# 來源：简书
# 简书著作权归作者所有，任何形式的转载都请联系作者获得授权并注明出处。


# 5 用-k进行关键字匹配来运行测试用例名字子串
# 比如用-k选择测试用例的名字中只带有http关键字的运行。

# C:\Users\yatyang\PycharmProjects\pytest_example>pytest -v -k http test_pytest_markers.py
# ============================= test session starts =============================
# platform win32 -- Python 2.7.13, pytest-3.0.6, py-1.4.32, pluggy-0.4.0 -- C:\Python27\python.exe
# cachedir: .cache
# rootdir: C:\Users\yatyang\PycharmProjects\pytest_example, inifile:
# collected 4 items 

# test_pytest_markers.py::test_send_http PASSED

# ============================= 3 tests deselected ==============================
# =================== 1 passed, 3 deselected in 0.12 seconds ====================

# 作者：Yating_Yang
# 链接：https://www.jianshu.com/p/60ef272911a5
# 來源：简书
# 简书著作权归作者所有，任何形式的转载都请联系作者获得授权并注明出处。


# 1. 生成JunitXML 格式的测试报告
# JunitXML报告是一种很常用的测试报告，比如可以和Jenkins进行集成，在Jenkins的GUI上显示Pytest的运行结果，非常便利。
# 运行完case后可以到report路径下去查看相应的xml文件，也可以在PyCharm打开该xml文件查看。
# 运行

# 作者：Yating_Yang
# 链接：https://www.jianshu.com/p/4fa39eb52d8e
# 來源：简书
# 简书著作权归作者所有，任何形式的转载都请联系作者获得授权并注明出处。


# pytest --junitxml=path
# #绝对路径：
# pytest -v test_one_func.py --junitxml=C:\Users\yatyang\PycharmProjects\pytest_example\report\test_one_func.xml
# #相对路径
# pytest -v test_one_func.py --junitxml=report\test_one_func.xml

# 作者：Yating_Yang
# 链接：https://www.jianshu.com/p/4fa39eb52d8e
# 來源：简书
# 简书著作权归作者所有，任何形式的转载都请联系作者获得授权并注明出处。



# 2. 生成result log格式的测试报告
# txt也是最简单的一种测试报告，实例如下。运行完case后可以到report路径下去查看相应的txt文件，也可以在PyCharm打开该txt文件查看。

# pytest -v test_one_func.py  --resultlog=report\log.txt

# 作者：Yating_Yang
# 链接：https://www.jianshu.com/p/4fa39eb52d8e
# 來源：简书
# 简书著作权归作者所有，任何形式的转载都请联系作者获得授权并注明出处。



# 3. 生成Html格式的测试报告
# html格式的测试报告在浏览器观看效果很好，还可以把这些测试报告放在Web服务器上。
# 首先，需要安装pytest-html插件。

# pip install pytest-html

# pytest -v test_one_func.py --html=report\test_one_func.html
# 这个report的格式还是很漂亮的，有Environment，Summary和Report，非常友好。



# import time
# import pytest

# @pytest.fixture(scope="module", autouse=True)
# def mod_header(request):
    # print('\n-----------------')
    # print('module      : %s' % request.module.__name__)
    # print('-----------------')

# @pytest.fixture(scope="function", autouse=True)
# def func_header(request):
    # print('\n-----------------')
    # print('function    : %s' % request.function.__name__)
    # print('time        : %s' % time.asctime())
    # print('-----------------')

# def test_one():
    # print('in test_one()')

# def test_two():
    # print('in test_two()')

# 作者：Yating_Yang
# 链接：https://www.jianshu.com/p/54b0f4016300
# 來源：简书
# 简书著作权归作者所有，任何形式的转载都请联系作者获得授权并注明出处。



# 类似于testng dataprovider
# import pytest

# @pytest.fixture(params=[1, 2, 3])
# def test_data(request):
    # return request.param

# def test_not_2(test_data):
    # print('test_data: %s' % test_data)
    # assert test_data != 2

# 作者：Yating_Yang
# 链接：https://www.jianshu.com/p/54b0f4016300
# 來源：简书
# 简书著作权归作者所有，任何形式的转载都请联系作者获得授权并注明出处。









