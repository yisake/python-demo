#Hashlib
#HMAC-SHA1
import hmac
import hashlib
import base64
hmac.new(Token,data,hashlib.sha1).digest().encode('base64').rstrip()
 
#MD5 sha1 sha224 sha256
a = "a test string"
print 'md5 = %s' % (hashlib.md5(a).hexdigest(),)
print 'sha1 = %s' % (hashlib.sha1(a).hexdigest(),)
print 'sha224 = %s' % (hashlib.sha224(a).hexdigest(),)
print 'sha256 = %s' % (hashlib.sha256(a).hexdigest(),)
print 'sha384 = %s' % (hashlib.sha384(a).hexdigest(),)
print 'sha512 = %s' % (hashlib.sha512(a).hexdigest(),)


#导入hashlib模块
import hashlib

#python可用的加密函数
hashlib.algorithms_available
{'sha384', 'DSA', 'SHA224', 'sha1','sha224', 'SHA384', 'ripemd160', 'MD5', 'whirlpool', 'SHA', 'MD4', 'SHA512','ecdsa-with-SHA1', 'dsaWithSHA', 'md5', 'sha256', 'DSA-SHA', 'SHA1', 'RIPEMD160','sha', 'md4', 'SHA256', 'dsaEncryption',
'sha512'}

hashlib.algorithms_guaranteed
{'md5', 'sha256', 'sha384', 'sha1','sha224', 'sha512'}

#创建一个加密函数对象
m = hashlib.md5()
m.update(b'python isinteresting')
m.hexdigest()
'f00243cac6d9aa2d320ed5603061483b'

mySha1 = hashlib.sha1()
mySha1.update(b'python is interesting')
mySha1.hexdigest()
'6ad9d2ccb5fe1d5324092bdac233b4ee49d71cb8'

#如果有中文的话，使用gb2312编码
myMd5 = hashlib.md5('python 真好玩'.encode('gb2312'))
myMd5.hexdigest()
'6c0f33c5f4b96f1aa771bf432ba53002'14663207.40068

hmac用法如下：
import hmac
myhmac = hmac.new(b'mykey')
myhmac.update(b'mymessage')
myhmac.hexdigest()
'd811630c4e62c6ef90d1bfe540212aaf'

