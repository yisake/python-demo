#encoding=utf-8
import click

@click.command()
@click.option('--count', default=1, help='Number of greetings.')
@click.option('--name', prompt='Your name',
              help='The person to greet.')

def hello(count, name):
    """Simple program that greets NAME for a total of COUNT times."""
    for x in range(count):
        click.echo('Hello %s!' % name)

if __name__ == '__main__':
    hello()

# 运行：
# $ python hello.py --count=3
# Your name: John
# Hello John!
# Hello John!
# Hello John!

# 查看帮助信息：
# $ python hello.py --help
# Usage: hello.py [OPTIONS]

  # Simple program that greets NAME for a total of COUNT times.

# Options:
  # --count INTEGER  Number of greetings.
  # --name TEXT      The person to greet.
  # --help           Show this message and exit.
