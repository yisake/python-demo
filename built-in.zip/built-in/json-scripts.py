# json.loads遇到中文之后
import json
a = '''
{
    "errorNo": "0",
    "results": {
        "data": [
            {
                "id": "1",
                "name": "北京"
            },
            {
                "id": "2",
                "name": "安徽"
            },
            {
                "id": "3",
                "name": "福建"
            }
        ]
    }
}'''
b = a.decode('gbk')

# json.loads判断是否是json格式
def is_json(myjson):
    try:
        json.loads(myjson)
    except ValueError:
        return False
    return True

data5 = {'a': 123, 'b': 789, 'c': 456}
json_str = json.dumps(data5)
not_json_str = 'name'
print is_json(json_str)
print is_json(not_json_str)

# json.loads()将unicode字符串转化为python对象
json.loads
a = '中文json字符串'
b = a.decode('gbk')
c = json.loads(b)
print type(c)  # <type 'dict'>

# json.dump()将python对象转换为json字符串
obj = [[1, 2, 3], 123, 123.123, 'abc', {'key1': (1, 2, 3), 'key2': (4, 5, 6)}]
json.dumps(obj)
data1 = {'b': 789, 'c': 456, 'a': 123}
d1 = json.dumps(data1, sort_keys=True, indent=4)
print d1

data = {'b': 789, 'c': 456, (1, 2): 123}
# json.dump separators 去除空格
json.dumps(data, separators=(',', ':'))
# json.dump skipkeys 数据类型
print json.dumps(data, skipkeys=True)
# 输出：
# {"c": 456, "b": 789}

# json.dumps格式化输出打印
data = {u'versions': [{u'status': u'CURRENT', u'id': u'v2.3', u'links': [{u'href': u'http://controller:9292/v2/', u'rel': u'self'}]}, {u'status': u'SUPPORTED', u'id': u'v2.2', u'links': [{u'href': u'http://controller:9292/v2/', u'rel': u'self'}]}, {u'status': u'SUPPORTED', u'id': u'v2.1', u'links': [{u'href': u'http://controller:9292/v2/', u'rel': u'self'}]}, {u'status': u'SUPPORTED', u'id': u'v2.0', u'links': [{u'href': u'http://controller:9292/v2/', u'rel': u'self'}]}, {u'status': u'SUPPORTED', u'id': u'v1.1', u'links': [{u'href': u'http://controller:9292/v1/', u'rel': u'self'}]}, {u'status': u'SUPPORTED', u'id': u'v1.0', u'links': [{u'href': u'http://controller:9292/v1/', u'rel': u'self'}]}]}
print json.dumps(data, sort_keys=True, indent=4)  # 排序并且缩进两个字符输出
data1 = {'b': 789, 'c': 456, 'a': 123}
data2 = {'a': 123, 'b': 789, 'c': 456}
d1 = json.dumps(data1, sort_keys=True)
d2 = json.dumps(data2)
d3 = json.dumps(data2, sort_keys=True)
print d1
print d2
print d3
print d1 == d2
print d1 == d3

