import datetime
#计算时间间隔
a=datetime.datetime.now()
b=datetime.datetime.now()
print str(b-a)
c=b-a
c
datetime.timedelta(0, 4, 240000)
c.total_seconds()
#4.24
c.microseconds
#240000

datetime.datetime转化为时间戳
create_time=datetime.datetime()
long(time.mktime(create_time.timetuple()))