import re
m = re.match(r'^(https|http)://([0-9a-zA-Z:\.]*)([0-9a-zA-Z/_\-?=&]*)', url)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'url' is not defined

url='https://a.esf.fangdd.net:60006/user/message?page_size=20&page_index=1'
m = re.match(r'^(https|http)://([0-9a-zA-Z:\.]*)([0-9a-zA-Z/_\-?=&]*)', url)
m
<_sre.SRE_Match object at 0x003F0AC0>
dir(m)
['__class__', '__copy__', '__deepcopy__', '__delattr__', '__doc__', '__format__', '__getattribute__'
, '__hash__', '__init__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__setattr__', '__si
zeof__', '__str__', '__subclasshook__', 'end', 'endpos', 'expand', 'group', 'groupdict', 'groups', '
lastgroup', 'lastindex', 'pos', 're', 'regs', 'span', 'start', 'string']


m.groups
<built-in method groups of _sre.SRE_Match object at 0x003F0AC0>
m.groups()
('https', 'a.esf.fangdd.net:60006', '/user/message?page_size=20&page_index=1')
m.group(0)
'https://a.esf.fangdd.net:60006/user/message?page_size=20&page_index=1'
m.group(1)
'https'
m.group(2)
'a.esf.fangdd.net:60006'
m.group(3)
'/user/message?page_size=20&page_index=1'

