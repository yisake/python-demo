# 1.基本的读取配置文件
# -read(filename) 直接读取ini文件内容
# -sections() 得到所有的section，并以列表的形式返回
# -options(section) 得到该section的所有option
# -items(section) 得到该section的所有键值对
# -get(section,option) 得到section中option的值，返回为string类型
# -getint(section,option) 得到section中option的值，返回为int类型，还有相应的getboolean()和getfloat() 函数。
 
# 2.基本的写入配置文件
# -add_section(section) 添加一个新的section
# -set( section, option, value) 对section中的option进行设置，需要调用write将内容写入配置文件。

# 3.ConfigParser对象中的方法
# ConfigParser类扩展了RawConfigParser的一些接口方法，添加了一些可选参数。
# get(section, option [, raw[, vars]])
# 获取给定section下的option的值，所以“%”占位符在返回值中被填补，基于构造时传递的默认值，就像option，vars也被提供，除非raw参数为true。
# items(section, [, raw[, vars]])
# 返回给定section下的所以option的（name, value）对列表。可选参数同get方法，2.3版本新增。
# SafeConfigParser对象中的方法
# SafeConfigParser类实现了ConfigParser相同的接口，新增如下方法：
# set(section, option, value)
# 如果给定的section存在，给option赋值；否则抛出NoSectionError异常。Value值必须是字符串（str或unicode）；如果不是，抛出TypeError异常，2.4版本新增。转载：

##读取配置文件
import ConfigParser 
config = ConfigParser.ConfigParser() 
config.read("analy.conf") 
if config.has_option("analysis", "timeout"): 
    print config.get("analysis", "timeout")    
print config.sections() 
print config.get("analysis", "package") 
print config.getint("analysis", "id") 

##读取中文配置文件
[test]
a = 中文
import ConfigParser 
config = ConfigParser.ConfigParser()
with codecs.open('test.cfg.txt', encoding="utf-8-sig" ) as f:
config.readfp(f)

##写入文件
import ConfigParser 
import time  
config = ConfigParser.RawConfigParser() 
task = {} 
task["id"] = 1 
task["package"] = "exe" 
task["timeout"] = 150 
task["dst_filename"] = "1.exe" 
task["custom"] = "" 
config.add_section("analysis")#增加section 
config.set("analysis", "id", task["id"])#增加option 
config.set("analysis", "target", task["dst_filename"]) 
config.set("analysis", "package", task["package"]) 
config.set("analysis", "timeout", task["timeout"]) 
config.set("analysis", "started", time.asctime()) 
fp = open("analy.conf", "w")
config.write(fp)#写入文件中 

##写入中文数据
open()