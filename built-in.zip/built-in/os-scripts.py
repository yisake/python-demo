import os
os.environ()
os.getcwd()
os.getpid()
os.listdir('')
os.rename()
os.remove()
os.path.exists()#文件/目录是否存在
os.path.getcwd()#获取当前目录
os.path.getsiez()#获取文件大小
os.path.join()#将分离的各部分组合成一个路径名
os.path.isDir()#是否是目录
os.path.isFile()#是否是文件
os.path.walk()#遍历文件夹
os.path.rename()#重名名文件
os.path.remove()#删除文件
os.path.abspath('test.csv')
os.path.split('C:\\test.csv')
#('C:\\','test.csv')
os.path.dirname()
os.path.exists('')
os.path.isfile('')
os.path.join('C:\\','csv','test.csv')
#'C:\\csv\\test.csv'
os.walk
os.access
os.chdir()

import shutil
shutil.rmtree(filePath,True)
shutil.copyfile("oldfile","newfile")
shutil.copytree("olddir","newdir")#olddir和newdir都只能是目录，且newdir必须不存在
shutil.rmtree("dir")#遍历删除