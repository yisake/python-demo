# encoding=utf-8
# 10进制转2进制
bin(10)
# 十进制 to 八进制: 
oct()
# 十进制 to 十六进制: 
hex()
# 二进制 to 十六进制 : 
hex(int(str,2))
# 十六进制 to 二进制: 
bin(int(str,16))

# 三目运算
# 是先输出结果，再判定条件
# 输出1，如果5大于3，否则输出0
print 1 if 5>3 else 0

# bool() 返回bool类型，例如bool(-2) bool(0) bool('string')
bool(-2)
bool(0)
bool('string')

# eval()
data = ['1', '3.2', '2']
data = map(eval, data)
print data

# filter()

# dir()查看模块方法，类 dir(__builtins__)查看内建异常 函数
dir()

# input
input()  # input要求制定输入类型，int或者str
raw_input()  # raw_input指定输入类型为str

# is、==以及id()函数
# Python中的对象包含三要素：id、type、value
# 其中id用来唯一标识一个对象，type标识对象的类型，value是对象的值
# is判断的是a对象是否就是b对象，是通过id来判断的
# ==判断的是a对象的值是否和b对象的值相等，是通过value来判断的
a = 1
b = 1.0
a is b
a == b
id(a)
id(b)
a = 1
b = 1
a is b
a == b
id(a)
id(b)

##map
#对于map()它的原型是：map(function,sequence)，就是对序列sequence中每个元素都执行函数function操作。
#比如之前的a,b,c = map(int,raw_input().split())，意思就是说把输入的a，b，c转化为整数。再比如：
#把列表内的数字变为字符串
a = ['1','2','3','4']
print map(int,a)

##zip
#而对于zip()，原型是zip(*list)，list是一个列表，zip(*list)返回的是一个元组，比如：
list = [[1,2,3],[4,5,6],[7,8,9]]
t = zip(*list)
print t
map(str, [1, 2, 3])
li = [11, 22, 33]
new_list = map(lambda a: a + 100, li)
li = [11, 22, 33]
sl = [1, 2, 3]
new_list = map(lambda a, b: a + b, li, sl)
li = [11, 22, 33]
new_list = filter(lambda arg: arg > 22, li)

# filter第一个参数为空，将获取原来序列
# 三、reduce
# 对于序列内所有元素进行累计操作
li = [11, 22, 33]
result = reduce(lambda arg1, arg2: arg1 + arg2, li)
# reduce的第一个参数，函数必须要有两个参数
# reduce的第二个参数，要循环的序列
# reduce的第三个参数，初始值
# 不要让懒惰占据你的大脑，不让要妥协拖跨你的人生。青春就是一张票，能不能赶上时代的快车，你的步伐掌握在你的脚下，good luck

# type判断对象类型
type(object)
