import requests
import json

"""一、GET"""
# GET传递字典参数
payload = {'key1': 'value1', 'key2': ['value2', 'value3']}
r = requests.get('http://httpbin.org/get', params=payload)
print(r.url)  # http://httpbin.org/get?key1=value1&key2=value2&key2=value3

# GET参数中包含中文，自动转码
# 有时候我们需要在URL中传递参数，比如在采集百度搜索结果时，我们wd参数（搜索词）和rn参数（搜素结果数量），你可以手工组成URL，requests也提供了一种看起来很NB的方法：
payload = {'wd': '张亚楠', 'rn': '100'}
r = requests.get("http://www.baidu.com/s", params=payload)
print r.url
# u'http://www.baidu.com/s?rn=100&wd=%E5%BC%A0%E4%BA%9A%E6%A5%A0'
# 上面wd=的乱码就是“张亚楠”的转码形式。（好像参数按照首字母进行了排序。）

# 多个相同的key
payload = {'key1': 'value1', 'key2': ['value2', 'value3']}
r = requests.get('http://httpbin.org/get', params=payload)
print(r.url)
# http://httpbin.org/get?key1=value1&key2=value2&key2=value3

"""二、POST"""
# POST form表单
url = 'http://httpbin.org/post'
d = {'key1': 'value1', 'key2': 'value2'}
r = requests.post(url, data=d)
print r.text

# POST json数据
url = 'http://httpbin.org/post'
s = json.dumps({'key1': 'value1', 'key2': 'value2'})
r = requests.post(url, data=s)
print r.text

"""代理"""
proxies = {
  "http": "http://10.10.1.10:3128",
  "https": "http://10.10.1.10:1080",
}
requests.get("http://example.org", proxies=proxies)

"""https"""
url = "https://www.qlchat.com/login.html"
ret = requests.get(url, verify="/Test/ssl_address/qlchat.com.crt")
print ret.status_code
