# encoding=utf-8
import codecs
b = codecs.open('1.xml', 'w', 'utf-8')
b.write("测试")
b.close()
