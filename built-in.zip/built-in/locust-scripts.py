



##0.8.1 启动
python -m locust.main -f lo.py --host=http://127.0.0.1:5000 --web-host=127.0.0.1