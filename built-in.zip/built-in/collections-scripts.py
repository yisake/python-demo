# encoding=utf-8
import collections
lst = [1, 2, 3, 4, 5, 6, 7, 1, 1]    # lst存放所谓的100万个元素
counter = collections.Counter(lst)
print counter
print counter.get(1)  # 返回某个元素匹配的次数
print counter.keys()  # 不重复的key值
