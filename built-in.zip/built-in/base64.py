#base64
#Python中进行Base64编码和解码
import base64
s = '我是字符串'
a = base64.b64encode(s)
print a
#ztLKx9fWt/u0rg==
print base64.b64decode(a)
