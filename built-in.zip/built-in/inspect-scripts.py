import os
import inspect
print inspect(os)

#  获取文件绝对路径
inspect.getfile(inspect.currentframe)
